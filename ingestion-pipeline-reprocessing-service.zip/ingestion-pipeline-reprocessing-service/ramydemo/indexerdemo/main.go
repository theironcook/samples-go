package main

import (
	"context"
	"fmt"
	"log/slog"
	"math/rand/v2"
	"strconv"
	"time"

	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/ingestion-pipeline-reprocessing-service/pipeline"
	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/protobuf-definitions/pkg/services/ingest"
	"go.temporal.io/sdk/client"
)

type docStoreClientStub struct {
}

func (d *docStoreClientStub) ReadDocument(ctx context.Context, naturalId string) (*ingest.IngestDocument, error) {
	i := ingest.IngestDocument{}
	i.Source = "test"
	return &i, nil
}

func main() {
	c, err := client.Dial(client.Options{})
	if err != nil {
		panic("Unable to create Temporal client")
	}
	defer c.Close()
	n := rand.IntN(1000000) // random batch
	opts := client.StartWorkflowOptions{TaskQueue: "batch-queue", ID: strconv.FormatInt(int64(n), 10)}

	start := time.Date(2023, 5, 1, 0, 0, 0, 0, time.UTC).Local()
	end := time.Date(2023, 8, 1, 0, 0, 0, 0, time.UTC).Local()

	params := pipeline.IndexerWorkflowParams{
		ContentProviderURL: "https://hazel.clarabridge.net",
		//ProjectId:          "6196577", // this is test project
		ProjectID: 6196577, // this is enterprise fdbk loop main
		AccountID: 100,
		StartDate: &start,
		EndDate:   &end,
		BatchID:   strconv.Itoa(n),
	}

	c.ExecuteWorkflow(context.Background(), opts, pipeline.IndexerWorkflow, params)
	slog.Default().Info(fmt.Sprintf("exporting %s", strconv.Itoa(n)))
	//_, err := m.Index(context.Background(), req)

	//if err != nil {
	//	slog.Default().Info(fmt.Sprintf("error is: %s", err.Error()))
	//}
}
