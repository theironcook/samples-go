package main

import (
	"context"
	"fmt"
	"net/http"
	"time"

	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/ingestion-pipeline-reprocessing-service/pipeline"
	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/protobuf-definitions/pkg/services/ingest"
	"go.temporal.io/sdk/client"
	"go.temporal.io/sdk/worker"
	"golang.org/x/sync/errgroup"
)

type docStoreClientStub struct {
}

func (d *docStoreClientStub) ReadDocument(ctx context.Context, naturalId string) (*ingest.IngestDocument, error) {
	i := ingest.IngestDocument{}
	i.Source = "test"
	return &i, nil
}

func main() {
	c, err := client.Dial(client.Options{})
	if err != nil {
		panic("Unable to create Temporal client")
	}
	defer c.Close()

	w := worker.New(c, "batch-queue", worker.Options{})

	w.RegisterWorkflow(pipeline.IndexerWorkflow)

	bc, _ := pipeline.NewBatchClient(
		context.Background(),
		"postgres://postgres:postgres@localhost:5432/postgres",
		time.Second*10,
	)

	oob := pipeline.OOBClient{
		HTTPCli: http.Client{Timeout: 30 * time.Second},
		URL:     "http://localhost:8002/api/v1/storage",
	}

	cmpClient := pipeline.CMPClient{
		HTTPCli: http.Client{Timeout: 30 * time.Second},
		AuthConfig: pipeline.CMPOauth{
			AuthUrl:      "https://secure.clarabridge.net/oauth/token",
			AuthUser:     "nlp-research-export",
			AuthPassword: "-a*obretumechu6+C_i=",
		},
	}

	exportClient := pipeline.ExportApiClient{
		URL:     "https://export-na.clarabridge.net/api/v2/export",
		HTTPCli: http.Client{Timeout: 30 * time.Second},
		CMPCli:  cmpClient,
	}

	m := pipeline.IndexerActivities{
		ExpCli: exportClient,
		BatCli: bc,
		OOBCli: oob,
	}

	w.RegisterActivity(&m)
	//dw := worker.New(c, "single-doc-task-queue", worker.Options{})
	//dw.RegisterWorkflow(pipeline.ReprocessingWorkflowStub)
	//dw.RegisterActivity(singleDocStub)

	var g errgroup.Group
	g.Go(func() error { return w.Run(worker.InterruptCh()) })
	//g.Go(func() error { return dw.Run(worker.InterruptCh()) })
	// Wait for all goroutines to finish
	if err := g.Wait(); err != nil {
		// Handle the error
		fmt.Printf("An error occurred: %v\n", err)
	} else {
		fmt.Println("All goroutines finished successfully")
	}

}
