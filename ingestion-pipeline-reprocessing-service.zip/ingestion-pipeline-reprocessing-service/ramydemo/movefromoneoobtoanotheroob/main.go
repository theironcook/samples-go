package main

import (
	"context"
	"fmt"

	"gitlab-app.eng.qops.net/golang/http"
	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/ingestion-pipeline-reprocessing-service/pipeline"
)

func main() {
	prd := pipeline.OOBClient{HTTPCli: *http.NewClient(), URL: "http://localhost:8083/api/v1/storage"}
	stg := pipeline.OOBClient{HTTPCli: *http.NewClient(), URL: "https://discover-pipelines-orchestration.staging.qualtrics.io/oobservice"}
	_ = stg

	docs := []string{

		"Audio;9e29f004-27c1-477f-8ac1-0bd4992222c3_40-1723517036465",
		"Audio;02d4044b-c5b7-48b8-bc4c-71fa41be2fe0_4-1723526385101",
		"Audio;051b000d-afc7-45ef-999e-7d26851f8f9e_5-1719615030249",
		"Audio;097420b7-7de4-4cef-bf4e-e4c7fdb32c1c_25-1721102160083",
	}
	d2 := []string{
		"Audio;9e29f004-27c1-477f-8ac1-0bd4992222c3_40",
		"Audio;02d4044b-c5b7-48b8-bc4c-71fa41be2fe0_4",
		"Audio;051b000d-afc7-45ef-999e-7d26851f8f9e_5",
		"Audio;097420b7-7de4-4cef-bf4e-e4c7fdb32c1c_25",
	}

	for i, _ := range docs {
		d, err := prd.FetchDoc(context.Background(), pipeline.DocIdentifier{Instance: "cmp-hazel", AccountID: 100, ProjectID: 21651, NaturalID: docs[i]})
		if err != nil {
			fmt.Println("error " + err.Error())
		}
		err = stg.SaveDoc(context.Background(), pipeline.DocIdentifier{Instance: "cmp-staging03", AccountID: 100, ProjectID: 11621157, NaturalID: d2[i]}, d)
		if err != nil {
			fmt.Println("error saving " + err.Error())
		}
		d2, err := stg.FetchDoc(context.Background(), pipeline.DocIdentifier{Instance: "cmp-staging03", AccountID: 100, ProjectID: 11621157, NaturalID: d2[i]})
		if err != nil {
			fmt.Println("error fetching after save!! " + string(i))
		}
		fmt.Println("GREAT")
		fmt.Println(d2)

		//fmt.Println(d)
		//fmt.Print("OK " + docId + "\n")
	}

}
