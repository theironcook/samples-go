package main

import (
	"context"
	"fmt"
	"net/http"

	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/ingestion-pipeline-reprocessing-service/config"
	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/ingestion-pipeline-reprocessing-service/pipeline"
)

func main() {

	err := config.AppConfig.Load("config.yaml")
	if err != nil {
		fmt.Print(err)
		panic("failed to load config")
	}
	appConfig := config.AppConfig

	// claims will be used for this specific request, overwriting the signer's default claims
	instance := "cmp-staging03"
	projectId := 11983
	documentId := "dialog-gen-37374-rz3"

	cmpC := pipeline.CMPClient{
		HTTPCli: *http.DefaultClient,
		BasicAuth: &pipeline.CMPBasicAuth{
			Username: appConfig.CMPClient.BasicAuth.User,
			Password: appConfig.CMPClient.BasicAuth.Password,
		},
	}
	docStore := pipeline.DiscoverDocumentStoreClient{
		JWTKey: appConfig.DocumentStoreClient.JWT,
		URL:    appConfig.DocumentStoreClient.URL,
	}

	id2 := pipeline.DocIdentifier{Instance: instance, AccountID: 100, ProjectID: int64(projectId), NaturalID: documentId}

	d, err := docStore.FetchDoc(context.Background(), id2)
	if err != nil {
		fmt.Println("error fetching", err)
	}
	fmt.Println("feteched document")
	d.NaturalId = d.NaturalId + "new"

	contentProviderUrl := "http://localhost:8083"
	delResp, err := cmpC.Delete(context.Background(), pipeline.CMPDeleteRequest{DocumentID: d.DocumentId, ContentProviderUrl: contentProviderUrl, ProjectID: int64(projectId)})
	if err != nil {
		fmt.Println("error deleting", err)
	}
	fmt.Println("delete response", delResp)

	err = cmpC.UploadDocument(context.Background(), pipeline.CMPUploadRequest{ContentProviderUrl: contentProviderUrl, Doc: d})
	if err != nil {
		fmt.Println("error inserting", err)
	}
	//fmt.Println(d)
}
