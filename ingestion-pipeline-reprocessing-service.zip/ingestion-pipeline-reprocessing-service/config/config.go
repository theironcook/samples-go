package config

import (
	"fmt"
	"log/slog"
	"net/url"
	"os"
	"time"

	"go.temporal.io/api/enums/v1"
	"go.temporal.io/sdk/temporal"
	"go.temporal.io/sdk/workflow"
	"gopkg.in/yaml.v3"
)

var AppConfig = Config{}

// Mirror the Temporal workflow.ActivityOptions struct BUT with the yaml struct tags for unmarshalling from config yaml files
type ActivityOptionsConfig struct {
	TaskQueue              string        `yaml:"TaskQueue"`
	ScheduleToCloseTimeout time.Duration `yaml:"ScheduleToCloseTimeout"`
	ScheduleToStartTimeout time.Duration `yaml:"ScheduleToStartTimeout"`
	StartToCloseTimeout    time.Duration `yaml:"StartToCloseTimeout"`
	HeartbeatTimeout       time.Duration `yaml:"HeartbeatTimeout"`
	WaitForCancellation    bool          `yaml:"WaitForCancellation"`
	// ActivityID             string        `yaml:"ActivityID,omitempty"` // Devs really aren't supposed to use this field
	DisableEagerExecution bool                      `yaml:"DisableEagerExecution"`
	VersioningIntent      temporal.VersioningIntent `yaml:"VersioningIntent"`
	RetryPolCfg           *RetryPolicyConfig        `yaml:"RetryPolCfg,omitempty"`
}

func (c *ActivityOptionsConfig) ToWFCtx(wfctx workflow.Context) workflow.Context {
	actOpts := workflow.ActivityOptions{
		TaskQueue:              c.TaskQueue,
		ScheduleToCloseTimeout: c.ScheduleToCloseTimeout,
		ScheduleToStartTimeout: c.ScheduleToStartTimeout,
		StartToCloseTimeout:    c.StartToCloseTimeout,
		HeartbeatTimeout:       c.HeartbeatTimeout,
		WaitForCancellation:    c.WaitForCancellation,
		DisableEagerExecution:  c.DisableEagerExecution,
		VersioningIntent:       c.VersioningIntent,
		RetryPolicy:            c.RetryPolCfg.ToRetryPolicy(),
	}

	return workflow.WithActivityOptions(wfctx, actOpts)
}

func (c *ActivityOptionsConfig) Validate(cfgName string) error {
	if c.StartToCloseTimeout == 0 && c.ScheduleToCloseTimeout == 0 {
		// Somewhat mirrors the runtime error Temporal returns (that error in Temporal source is not reusable)
		return fmt.Errorf("a valid StartToCloseTimeout or ScheduleToCloseTimeout was not set for %s", cfgName)
	}

	return nil
}

type LocalActivityOptionsConfig struct {
	ScheduleToCloseTimeout time.Duration      `yaml:"ScheduleToCloseTimeout"`
	StartToCloseTimeout    time.Duration      `yaml:"StartToCloseTimeout"`
	RetryPolCfg            *RetryPolicyConfig `yaml:"RetryPolCfg,omitempty"`
}

func (c *LocalActivityOptionsConfig) ToWFCtx(wfctx workflow.Context) workflow.Context {
	actOpts := workflow.LocalActivityOptions{
		ScheduleToCloseTimeout: c.ScheduleToCloseTimeout,
		StartToCloseTimeout:    c.StartToCloseTimeout,
		RetryPolicy:            c.RetryPolCfg.ToRetryPolicy(),
	}

	return workflow.WithLocalActivityOptions(wfctx, actOpts)
}

func (c *LocalActivityOptionsConfig) Validate(cfgName string) error {
	if c.StartToCloseTimeout == 0 && c.ScheduleToCloseTimeout == 0 {
		// Somewhat mirrors the runtime error Temporal returns (that error in Temporal source is not reusable)
		return fmt.Errorf("a valid StartToCloseTimeout or ScheduleToCloseTimeout was not set for %s", cfgName)
	}

	return nil
}

type RetryPolicyConfig struct {
	InitialInterval        time.Duration `yaml:"InitialInterval"`
	BackoffCoefficient     float64       `yaml:"BackoffCoefficient"`
	MaximumInterval        time.Duration `yaml:"MaximumInterval"`
	MaximumAttempts        int32         `yaml:"MaximumAttempts"`
	NonRetryableErrorTypes []string      `yaml:"NonRetryableErrorTypes"`
}

func (c *RetryPolicyConfig) ToRetryPolicy() *temporal.RetryPolicy {
	if c == nil {
		return nil
	}

	return &temporal.RetryPolicy{
		InitialInterval:        c.InitialInterval,
		BackoffCoefficient:     c.BackoffCoefficient,
		MaximumInterval:        c.MaximumInterval,
		MaximumAttempts:        c.MaximumAttempts,
		NonRetryableErrorTypes: c.NonRetryableErrorTypes,
	}
}

type Config struct {
	LogLevel           slog.Level `yaml:"LogLevel"`
	CollectPerfMetrics bool       `yaml:"CollectPerfMetrics"`

	BatchWorkflow struct {
		WorkflowIDReusePolicy      enums.WorkflowIdReusePolicy `yaml:"WorkflowIDReusePolicy"`
		BatchPollDelay             time.Duration               `yaml:"BatchPollDelay"`
		BatchActOptCfg             ActivityOptionsConfig       `yaml:"BatchActOptCfg"`
		TriggerProcessingActOptCfg ActivityOptionsConfig       `yaml:"TriggerProcessingActOptCfg"`
		RetryPolCfg                *RetryPolicyConfig          `yaml:"RetryPolCfg,omitempty"`
	} `yaml:"BatchWorkflow"`

	IndexerWorkflow struct {
		WorkflowIDReusePolicy enums.WorkflowIdReusePolicy `yaml:"WorkflowIDReusePolicy"`
		Concurrency           int64                       `yaml:"Concurrency"`
		PageSize              int                         `yaml:"PageSize"`
		BatchActOptCfg        ActivityOptionsConfig       `yaml:"BatchActOptCfg"`
		InsertIDsActOptCfg    ActivityOptionsConfig       `yaml:"InsertIDsActOptCfg"`
	} `yaml:"IndexerWorkflow"`

	ReprocessingWorkflow struct {
		WorkflowIDReusePolicy enums.WorkflowIdReusePolicy `yaml:"WorkflowIDReusePolicy"`
		ScrubActOptCfg        ActivityOptionsConfig       `yaml:"ScrubActOptCfg"`
		NLPFacade             struct {
			URL         string                `yaml:"URL"`
			HTTPTimeout time.Duration         `yaml:"HTTPTimeout"`
			ActOptCfg   ActivityOptionsConfig `yaml:"ActOptCfg"`
		} `yaml:"NLPFacade"`
		DerivedAttribute struct {
			URL         string                `yaml:"URL"`
			HTTPTimeout time.Duration         `yaml:"HTTPTimeout"`
			ActOptCfg   ActivityOptionsConfig `yaml:"ActOptCfg"`
		} `yaml:"DerivedAttribute"`
		Sentiment struct {
			URL         string                `yaml:"URL"`
			HTTPTimeout time.Duration         `yaml:"HTTPTimeout"`
			ActOptCfg   ActivityOptionsConfig `yaml:"ActOptCfg"`
		} `yaml:"Sentiment"`
		Classification struct {
			URL         string                `yaml:"URL"`
			HTTPTimeout time.Duration         `yaml:"HTTPTimeout"`
			ActOptCfg   ActivityOptionsConfig `yaml:"ActOptCfg"`
		} `yaml:"Classification"`
		IntelligentScoring struct {
			URL         string                `yaml:"URL"`
			HTTPTimeout time.Duration         `yaml:"HTTPTimeout"`
			ActOptCfg   ActivityOptionsConfig `yaml:"ActOptCfg"`
		} `yaml:"IntelligentScoring"`
		DeleteRecordActOptCfg ActivityOptionsConfig      `yaml:"DeleteRecordActOptCfg"`
		InsertRecordActOptCfg ActivityOptionsConfig      `yaml:"InsertRecordActOptCfg"`
		BatchActOptCfg        ActivityOptionsConfig      `yaml:"BatchActOptCfg"`
		PerfMetricsActOptCfg  LocalActivityOptionsConfig `yaml:"PerfMetricsActOptCfg"`
	} `yaml:"ReprocessingWorkflow"`

	Temporal struct {
		Client struct {
			HostPort  string `yaml:"HostPort"`
			Namespace string `yaml:"Namespace"`
		} `yaml:"Client"`
		Worker struct {
			DefaultTaskQueue                 string `yaml:"DefaultTaskQueue"`
			MaxConcurrentWorkflowTaskPollers int    `yaml:"MaxConcurrentWorkflowTaskPollers"`
			MaxConcurrentActivityTaskPollers int    `yaml:"MaxConcurrentActivityTaskPollers"`
		} `yaml:"Worker"`
		ReprocessingWorkflowWorker struct {
			TaskQueue                        string  `yaml:"TaskQueue"`
			TaskQueueActivitiesPerSecond     float64 `yaml:"TaskQueueActivitiesPerSecond"`
			MaxConcurrentWorkflowTaskPollers int     `yaml:"MaxConcurrentWorkflowTaskPollers"`
			MaxConcurrentActivityTaskPollers int     `yaml:"MaxConcurrentActivityTaskPollers"`
		} `yaml:"ReprocessingWorkflowWorker"`
	} `yaml:"Temporal"`

	HTTPService struct {
		Name    string `yaml:"Name"`
		Address string `yaml:"Address"`
	} `yaml:"HTTPService"`

	OOBService struct {
		URL         string        `yaml:"URL"`
		HTTPTimeout time.Duration `yaml:"HTTPTimeout"`
	} `yaml:"OOBService"`

	ExportAPIClient struct {
		URL  string `yaml:"URL"`
		Auth struct {
			URL      string `yaml:"URL"`
			User     string `yaml:"User"`
			Password string `yaml:"Password"`
		} `yaml:"Auth"`
		HTTPTimeout time.Duration `yaml:"HTTPTimeout"`
	} `yaml:"ExportAPIClient"`

	BatchClient struct {
		URL            string        `yaml:"URL"`
		ConnectTimeout time.Duration `yaml:"ConnectTimeout"`
	} `yaml:"BatchClient"`

	CMPClient struct {
		BasicAuth struct {
			User     string `yaml:"User"`
			Password string `yaml:"Password"`
		} `yaml:"BasicAuth"`
		OAuth struct {
			URL      string `yaml:"URL"`
			User     string `yaml:"User"`
			Password string `yaml:"Password"`
		} `yaml:"OAuth"`
		HTTPTimeout time.Duration `yaml:"HTTPTimeout"`
	} `yaml:"CMPClient"`

	DocumentStoreClient struct {
		URL         string        `yaml:"URL"`
		JWT         string        `yaml:"JWT"`
		HTTPTimeout time.Duration `yaml:"HTTPTimeout"`
	} `yaml:"DocumentStoreClient"`
}

func (c *Config) Load(file string) error {
	f, err := os.Open(file)
	if err != nil {
		return fmt.Errorf("failed to config file (%s): %w", file, err)
	}

	if err := yaml.NewDecoder(f).Decode(c); err != nil {
		return fmt.Errorf("failed to decode config file (%s): %w", file, err)
	}

	return nil
}

func (c *Config) Validate() error {
	if err := c.BatchWorkflow.BatchActOptCfg.Validate("BatchWorkflow.BatchActOptCfg"); err != nil {
		return err
	}
	if err := c.BatchWorkflow.TriggerProcessingActOptCfg.Validate("BatchWorkflow.TriggerProcessingActOptCfg"); err != nil {
		return err
	}
	if err := c.IndexerWorkflow.BatchActOptCfg.Validate("IndexerWorkflow.BatchActOptCfg"); err != nil {
		return err
	}
	if err := c.IndexerWorkflow.InsertIDsActOptCfg.Validate("IndexerWorkflow.InsertIDsActOptCfg"); err != nil {
		return err
	}
	if err := c.ReprocessingWorkflow.NLPFacade.ActOptCfg.Validate("ReprocessingWorkflow.NLPFacade.ActOptCfg"); err != nil {
		return err
	}
	if err := c.ReprocessingWorkflow.DerivedAttribute.ActOptCfg.Validate("ReprocessingWorkflow.DerivedAttribute.ActOptCfg"); err != nil {
		return err
	}
	if err := c.ReprocessingWorkflow.Sentiment.ActOptCfg.Validate("ReprocessingWorkflow.Sentiment.ActOptCfg"); err != nil {
		return err
	}
	if err := c.ReprocessingWorkflow.Classification.ActOptCfg.Validate("ReprocessingWorkflow.Classification.ActOptCfg"); err != nil {
		return err
	}
	if err := c.ReprocessingWorkflow.IntelligentScoring.ActOptCfg.Validate("ReprocessingWorkflow.IntelligentScoring.ActOptCfg"); err != nil {
		return err
	}
	if err := c.ReprocessingWorkflow.DeleteRecordActOptCfg.Validate("ReprocessingWorkflow.DeleteRecordActOptCfg"); err != nil {
		return err
	}
	if err := c.ReprocessingWorkflow.InsertRecordActOptCfg.Validate("ReprocessingWorkflow.InsertRecordActOptCfg"); err != nil {
		return err
	}
	if err := c.ReprocessingWorkflow.BatchActOptCfg.Validate("ReprocessingWorkflow.BatchActOptCfg"); err != nil {
		return err
	}
	if err := c.ReprocessingWorkflow.PerfMetricsActOptCfg.Validate("ReprocessingWorkflow.PerfMetricsActOptCfg"); err != nil {
		return err
	}

	if c.HTTPService.Name == "" {
		return fmt.Errorf("HTTPService.Name is an empty string")
	}
	if c.HTTPService.Address == "" {
		return fmt.Errorf("HTTPService.Address is an empty string")
	}
	if _, err := url.ParseRequestURI(c.HTTPService.Address); err != nil {
		return fmt.Errorf("HTTPService.Address is not a valid url %w", err)
	}
	if c.OOBService.URL == "" {
		return fmt.Errorf("OOBService.URL is an empty string")
	}
	if c.OOBService.HTTPTimeout < 0 {
		return fmt.Errorf("OOBService.HTTPTimeout cannot be negative")
	}
	if _, err := url.ParseRequestURI(c.OOBService.URL); err != nil {
		return fmt.Errorf("OOBService.URL is not a valid url %w", err)
	}
	if c.BatchClient.URL == "" {
		return fmt.Errorf("BatchClient.URL is an empty string")
	}
	if _, err := url.ParseRequestURI(c.BatchClient.URL); err != nil {
		return fmt.Errorf("BatchClient.URL is not a valid url %w", err)
	}
	if c.BatchClient.ConnectTimeout < 0 {
		return fmt.Errorf("BatchClient.ConnectTimeout cannot be negative")
	}
	if c.ExportAPIClient.URL == "" {
		return fmt.Errorf("ExportAPI.URL is an empty string")
	}
	if _, err := url.ParseRequestURI(c.ExportAPIClient.URL); err != nil {
		return fmt.Errorf("ExportAPI.URL is not a valid url %w", err)
	}
	if c.ExportAPIClient.HTTPTimeout < 0 {
		return fmt.Errorf("ExportAPI.HTTPTimeout cannot be negative")
	}

	if c.IndexerWorkflow.Concurrency <= 0 || c.IndexerWorkflow.Concurrency > 50 {
		return fmt.Errorf("Indexer.Concurrency must be greater than 0 and less than 50")
	}
	if c.IndexerWorkflow.PageSize <= 0 || c.IndexerWorkflow.PageSize > 10_000 {
		return fmt.Errorf("IndexerWorkflow.PageSize must be greater than 0 and less than 10,000")
	}
	if c.DocumentStoreClient.JWT == "" {
		return fmt.Errorf("DocumentStoreClient.JWT is an empty string")
	}
	if c.DocumentStoreClient.URL == "" {
		return fmt.Errorf("DocumentStoreClient.URL is an empty string")
	}
	if _, err := url.ParseRequestURI(c.DocumentStoreClient.URL); err != nil {
		return fmt.Errorf("DocumentStoreClient.URL is not a valid url %w", err)
	}
	if c.DocumentStoreClient.HTTPTimeout < 0 {
		return fmt.Errorf("cfg.DocumentStoreClient.HTTPTimeout cannot be negative")
	}
	cmpBasicAuthOK := c.CMPClient.BasicAuth.User != "" && c.CMPClient.BasicAuth.Password != ""
	cmpOAuthOK := c.CMPClient.OAuth.URL != "" && c.CMPClient.OAuth.User != "" && c.CMPClient.OAuth.Password != ""
	if !cmpBasicAuthOK && !cmpOAuthOK {
		return fmt.Errorf("CMPClient.BasicAuth or CMPClient.OAuth must be set")
	}
	if c.CMPClient.HTTPTimeout < 0 {
		return fmt.Errorf("Indexer.CMPClient.HTTPTimeout cannot be negative")
	}
	if c.Temporal.Client.HostPort == "" {
		return fmt.Errorf("Temporal.Client.HostPort is an empty string")
	}
	if _, err := url.ParseRequestURI(c.Temporal.Client.HostPort); err != nil {
		return fmt.Errorf("Temporal.Client.HostPort is not a valid url %w", err)
	}
	if c.Temporal.Client.Namespace == "" {
		return fmt.Errorf("Temporal.Client.Namespace is an empty string")
	}
	if c.Temporal.Worker.DefaultTaskQueue == "" {
		return fmt.Errorf("Temporal.Worker.DefaultTaskQueue is an empty string")
	}
	if c.Temporal.ReprocessingWorkflowWorker.TaskQueue == "" {
		return fmt.Errorf("Temporal.ReprocessingWorkflowWorker.TaskQueue is an empty string")
	}
	if c.Temporal.ReprocessingWorkflowWorker.TaskQueueActivitiesPerSecond < 0 {
		return fmt.Errorf("Temporal.ReprocessingWorkflowWorker.TaskQueueActivitiesPerSecond cannot be negative")
	}

	if c.ReprocessingWorkflow.NLPFacade.URL == "" {
		return fmt.Errorf("ReprocessingWorkflow.NLPFacade.URL is an empty string")
	}
	if _, err := url.ParseRequestURI(c.ReprocessingWorkflow.NLPFacade.URL); err != nil {
		return fmt.Errorf("ReprocessingWorkflow.NLPFacade.URL is not a valid url %w", err)
	}
	if c.ReprocessingWorkflow.NLPFacade.HTTPTimeout < 0 {
		return fmt.Errorf("ReprocessingWorkflow.NLPFacade.HTTPTimeout cannot be negative")
	}
	if c.ReprocessingWorkflow.NLPFacade.ActOptCfg.StartToCloseTimeout < 0 {
		return fmt.Errorf("Indexer.ActivityOptionsConfig.HeartbeatTimeout cannot be negative")
	}
	if c.ReprocessingWorkflow.DerivedAttribute.URL == "" {
		return fmt.Errorf("ReprocessingWorkflow.DerivedAttribute.URL is an empty string")
	}
	if _, err := url.ParseRequestURI(c.ReprocessingWorkflow.DerivedAttribute.URL); err != nil {
		return fmt.Errorf("ReprocessingWorkflow.DerivedAttribute.URL is not a valid url %w", err)
	}
	if c.ReprocessingWorkflow.DerivedAttribute.HTTPTimeout < 0 {
		return fmt.Errorf("ReprocessingWorkflow.DerivedAttribute.HTTPTimeout cannot be negative")
	}
	if c.ReprocessingWorkflow.Sentiment.URL == "" {
		return fmt.Errorf("ReprocessingWorkflow.Sentiment.URL is an empty string")
	}
	if _, err := url.ParseRequestURI(c.ReprocessingWorkflow.Sentiment.URL); err != nil {
		return fmt.Errorf("ReprocessingWorkflow.Sentiment.URL is not a valid url %w", err)
	}
	if c.ReprocessingWorkflow.Sentiment.HTTPTimeout < 0 {
		return fmt.Errorf("ReprocessingWorkflow.Sentiment.HTTPTimeout cannot be negative")
	}
	if c.ReprocessingWorkflow.Classification.URL == "" {
		return fmt.Errorf("ReprocessingWorkflow.Classification.URL is an empty string")
	}
	if _, err := url.ParseRequestURI(c.ReprocessingWorkflow.Classification.URL); err != nil {
		return fmt.Errorf("ReprocessingWorkflow.Classification.URL is not a valid url %w", err)
	}
	if c.ReprocessingWorkflow.Classification.HTTPTimeout < 0 {
		return fmt.Errorf("ReprocessingWorkflow.Classification.HTTPTimeout cannot be negative")
	}
	if c.ReprocessingWorkflow.IntelligentScoring.URL == "" {
		return fmt.Errorf("ReprocessingWorkflow.IntelligentScoring.URL is an empty string")
	}
	if _, err := url.ParseRequestURI(c.ReprocessingWorkflow.IntelligentScoring.URL); err != nil {
		return fmt.Errorf("ReprocessingWorkflow.IntelligentScoring.URL is not a valid url %w", err)
	}
	if c.ReprocessingWorkflow.IntelligentScoring.HTTPTimeout < 0 {
		return fmt.Errorf("ReprocessingWorkflow.IntelligentScoring.HTTPTimeout cannot be negative")
	}

	return nil
}
