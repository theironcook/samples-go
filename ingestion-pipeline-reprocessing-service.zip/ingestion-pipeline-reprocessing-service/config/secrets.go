package config

import (
	"crypto/tls"
	"encoding/base64"
	"fmt"
	"log/slog"
	"os"

	"gopkg.in/yaml.v3"
)

const (
	TEMPORAL_CERT = "TEMPORAL_CERT"
	TEMPORAL_KEY  = "TEMPORAL_KEY"
)

var AppSecrets = Secrets{}

type Secrets struct {
	// Values from a yaml file
	Cert string `yaml:"certificate"`
	Key  string `yaml:"key"`
	// Values used by Validate()
	TLSCert tls.Certificate
}

func (s *Secrets) Load(file string) error {
	// env vars take precedence if they exist
	if os.Getenv(TEMPORAL_CERT) != "" && os.Getenv(TEMPORAL_KEY) != "" {
		slog.Info("using env vars for secrets")
		cert := os.Getenv(TEMPORAL_CERT)
		key := os.Getenv(TEMPORAL_KEY)
		s.Cert = cert
		s.Key = key
	} else {
		f, err := os.Open(file)
		if err != nil {
			return fmt.Errorf("failed to open secrets file (%s) : %w", file, err)
		}

		if err := yaml.NewDecoder(f).Decode(s); err != nil {
			return fmt.Errorf("failed to decode secrets: %w", err)
		}
	}

	return nil
}

func (s *Secrets) Validate() error {
	if s.Cert == "" {
		return fmt.Errorf("temporal cert is the empty string")
	}

	if s.Key == "" {
		return fmt.Errorf("temporal key is the empty string")
	}

	// assumes base64 encoded secrets in the json
	cert, err := base64.StdEncoding.DecodeString(s.Cert)
	if err != nil {
		return fmt.Errorf("cannot base 64 decode temporal cert")
	}

	key, err := base64.StdEncoding.DecodeString(s.Key)
	if err != nil {
		return fmt.Errorf("cannot base 64 decode temporal key")
	}

	tlsCert, err := tls.X509KeyPair(cert, key)
	if err != nil {
		return fmt.Errorf("creating temporal certificate: %w", err)
	}

	s.TLSCert = tlsCert
	return nil
}
