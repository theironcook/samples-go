

Background:

This service is used to reprocess enrichments.  An enrichment is supplemental meta data that describes source data.  For example, my source data could be “I hate your business” and the supplemental enrichment could be sentiment=0 (meaning the customer is not happy).

Source data + enrichments == a doc

The Enrichments teams own several services that compute enrichments based on the source data (sentiment=0, etc) that are appended to docs.  
This service helps coordinate the enricher services (but doesn’t actually compute enrichments itself)

The initial use case for this service was to fix faulty historical enrichments by reprocessing source docs and recomputing enrichments (Fall 2024).  
But this service should also provide the foundation for future pipeline modernization via Temporal across the Enrichment teams.

The service leverages Temporal for service orchestration, durable execution and some observability (still need other observability like Grafana, etc).  
All reprocessing steps described below are orchestrated via Temporal as Workflows and Activities (google Temporal docs).

Initial doc reprocessing use case:
Accept an http request to reprocess a batch of docs. 
A batch of docs is defined with a query like this:

"ProjectID":                11983,
"AccountID":                100,
"StartDate":                "2020-03-15T02:10:00.000000-00:00",
"EndDate":                  "2020-03-15T02:20:00.000000-00:00"

This service uses the existing Export API to fetch docs via a query.  This service creates a Postgres table for the new batch and creates table row for each doc id found via the Export API query.  The batch table of doc ids helps to keep track of which docs have been reprocessed / failed etc (for humans and programmatic behavior).

The service loops through each doc row in a batch table and executes a Temporal reprocessing workflow to compute enrichments for the doc.

The reprocessing workflow uses:
  Document Storage Service (for doc retrieval and eventually for updates)
  Out of Band Storage Service for doc persistence between enricher steps (if a executing container fails, Temporal will restart the workflow and continue from the last step)
  Enrichment services (sentiment, etc)

To run this service:
Verify you have created a Postgres database locally (ask Ramy) or use a shared one
Verify you have a correct config.yaml file.  Copy the config_example.yaml file and update the required passwords, urls etc accordingly.

>go run . | jq
You can see output in the terminal as well as the /log/ files

To test, use Postman to create a POST request to http://localhost:8080/batch to start a batch.

