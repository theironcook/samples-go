package main

import (
	"context"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"

	goprom "github.com/prometheus/client_golang/prometheus"
	"github.com/uber-go/tally/v4"
	"github.com/uber-go/tally/v4/prometheus"
	"gitlab-app.eng.qops.net/golang/app"
	qhttp "gitlab-app.eng.qops.net/golang/app/server/http"
	"gitlab-app.eng.qops.net/golang/http/accesslog"
	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/ingestion-pipeline-reprocessing-service/api"
	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/ingestion-pipeline-reprocessing-service/config"
	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/ingestion-pipeline-reprocessing-service/pipeline"
	"go.temporal.io/sdk/client"
	temtally "go.temporal.io/sdk/contrib/tally"
)

const (
	accessLogPath = "log/http_access.json"
)

func main() {
	slog.Info("starting app", "pid", os.Getpid())
	ctx, stopApp := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGINT, syscall.SIGTERM)
	defer stopApp()
	ctx = context.WithValue(ctx, stopAppWGKey{}, &sync.WaitGroup{})

	logFile, err := initLogging()
	if err != nil {
		slog.Error(fmt.Errorf("failed to initialize logging: %w", err).Error())
		stopApp()
	}

	if err := initConfigs(); err != nil {
		slog.Error(fmt.Errorf("failed to initialize configs: %w", err).Error())
		stopApp()
	}

	batCli, err := pipeline.NewBatchClient(
		ctx,
		config.AppConfig.BatchClient.URL,
		config.AppConfig.BatchClient.ConnectTimeout,
	)
	if err != nil {
		slog.Error(fmt.Errorf("failed to create the batch client: %w", err).Error())
		stopApp()
	}

	temCli, err := initPipeline(ctx, batCli)
	if err != nil {
		slog.Error(fmt.Errorf("failed to initialize the pipeline: %w", err).Error())
		stopApp()
	}

	serveMux := api.NewServeMux(config.AppConfig, temCli, batCli)
	go app.New(
		app.WithName(config.AppConfig.HTTPService.Name),
		app.WithServer(config.AppConfig.HTTPService.Address, qhttp.New(qhttp.WithHandler(serveMux), qhttp.WithAccessLog(accesslog.MustOpenWriter(accessLogPath)))),
	).Run()

	slog.Info("app started")

	// Don't change the order of the following lines
	<-ctx.Done()
	slog.Info("closing app. cleaning up resources")
	StopAppWG(ctx).Wait()
	slog.Info("app closed")
	logFile.Close()
}

type stopAppWGKey struct{}

// When stopping the app, this allows us to wait for resource cleanup to complete
func StopAppWG(ctx context.Context) *sync.WaitGroup {
	stopWG, ok := ctx.Value(stopAppWGKey{}).(*sync.WaitGroup)
	if !ok {
		panic("programmer error. Missing stop app wait group in the context")
	}
	return stopWG
}

var (
	logPath  = "log/output.json"
	logLevel = new(slog.LevelVar)
)

func initLogging() (*os.File, error) {
	logLevel.Set(slog.LevelDebug)
	slog.Info("initializing logging", "logPath", logPath)
	defer slog.Info("logging initialized")

	logFile, err := os.OpenFile(logPath, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return nil, fmt.Errorf("failed to open log file: %w", err)
	}

	logger := slog.New(slog.NewJSONHandler(io.MultiWriter(os.Stdout, logFile), &slog.HandlerOptions{AddSource: true, Level: logLevel}))
	slog.SetDefault(logger)

	return logFile, nil
}

const (
	configFile  = "./config.yaml"
	secretsFile = "./secrets.yaml"
)

func initConfigs() error {
	slog.Info("initializing configs", "configFile", configFile, "secretsFile", secretsFile)
	defer slog.Info("configs initialized")

	if err := config.AppConfig.Load(configFile); err != nil {
		return fmt.Errorf("failed loading config file: %w", err)
	}
	if err := config.AppConfig.Validate(); err != nil {
		return fmt.Errorf("failed validating config file: %w", err)
	}

	logLevel.Set(config.AppConfig.LogLevel)

	if err := config.AppSecrets.Load(secretsFile); err != nil {
		return fmt.Errorf("failed loading secrets: %w", err)
	}
	if err := config.AppSecrets.Validate(); err != nil {
		return fmt.Errorf("failed validating secrets: %w", err)
	}

	return nil
}

func initPipeline(ctx context.Context, batchClient pipeline.BatchClient) (client.Client, error) {
	slog.Info("initializing pipeline")
	defer slog.Info("pipeline initialized")

	promConfig := prometheus.Configuration{
		ListenAddress: "0.0.0.0:9090",
		TimerType:     "histogram",
	}

	reporter, err := promConfig.NewReporter(
		prometheus.ConfigurationOptions{
			Registry: goprom.NewRegistry(),
			OnError: func(err error) {
				slog.Error(fmt.Errorf("failed to report prometheus metrics: %w", err).Error())
			},
		},
	)
	if err != nil {
		return nil, fmt.Errorf("failed to create the prometheus reporter: %w", err)
	}
	scopeOpts := tally.ScopeOptions{
		CachedReporter:  reporter,
		Separator:       prometheus.DefaultSeparator,
		SanitizeOptions: &temtally.PrometheusSanitizeOptions,
		Prefix:          "reprocess",
	}
	scope, metCloser := tally.NewRootScope(scopeOpts, time.Second)
	metScope := temtally.NewPrometheusNamingScope(scope)

	StopAppWG(ctx).Add(1)
	go func() {
		<-ctx.Done()
		slog.Info("closing metrics scope")
		err := metCloser.Close()

		if err != nil {
			slog.Warn(fmt.Errorf("failed to close the metrics scope: %w", err).Error())
		}

		StopAppWG(ctx).Done()
	}()

	tmpCli, err := pipeline.NewTemporalClient(metScope)
	if err != nil {
		return nil, fmt.Errorf("failed to create the Temporal client: %w", err)
	}

	// TODO: basic auth is for v0 for humana
	cmpClient := pipeline.CMPClient{
		HTTPCli: http.Client{Timeout: config.AppConfig.CMPClient.HTTPTimeout},
		BasicAuth: &pipeline.CMPBasicAuth{
			Username: config.AppConfig.CMPClient.BasicAuth.User,
			Password: config.AppConfig.CMPClient.BasicAuth.Password,
		},
		AuthConfig: pipeline.CMPOauth{
			AuthUrl:      config.AppConfig.CMPClient.OAuth.URL,
			AuthUser:     config.AppConfig.CMPClient.OAuth.User,
			AuthPassword: config.AppConfig.CMPClient.OAuth.Password,
		},
	}

	expClient := pipeline.ExportApiClient{
		URL:     config.AppConfig.ExportAPIClient.URL,
		HTTPCli: http.Client{Timeout: config.AppConfig.ExportAPIClient.HTTPTimeout},
		CMPCli:  cmpClient,
	}

	docStoreClient := pipeline.DiscoverDocumentStoreClient{
		HTTPCli: http.Client{Timeout: config.AppConfig.DocumentStoreClient.HTTPTimeout},
		JWTKey:  config.AppConfig.DocumentStoreClient.JWT,
		URL:     config.AppConfig.DocumentStoreClient.URL,
	}

	oobClient := pipeline.OOBClient{
		HTTPCli: http.Client{Timeout: config.AppConfig.OOBService.HTTPTimeout},
		URL:     config.AppConfig.OOBService.URL,
	}

	_, err = pipeline.NewWorker(config.AppConfig, pipeline.NewWorkerParams{
		TemCli:      tmpCli,
		BatCli:      batchClient,
		DocStoreCli: docStoreClient,
		OOBCli:      oobClient,
		ExpApiCli:   expClient,
		CMPCli:      cmpClient,
	})
	if err != nil {
		return nil, fmt.Errorf("failed to create the temporal worker: %w", err)
	}

	_, err = pipeline.NewReprocessingWorkflowWorker(config.AppConfig, pipeline.NewWorkerParams{
		TemCli:      tmpCli,
		BatCli:      batchClient,
		DocStoreCli: docStoreClient,
		OOBCli:      oobClient,
		ExpApiCli:   expClient,
		CMPCli:      cmpClient,
	})
	if err != nil {
		return nil, fmt.Errorf("failed to create the temporal reprocessing worker: %w", err)
	}

	return tmpCli, nil
}
