package main

import (
	"fmt"
	"net/http"
	"sync"
	"sync/atomic"
	"time"
)

type PurgeClient struct {
	Client  http.Client
	URL     string
	Project string
}

func (c *PurgeClient) Purge(ids []string) error {
	// simulating the purge operation
	fmt.Printf("Purging IDs: %v\n", ids)
	return nil
}

// deleteRequest represents an individual delete request
type deleteRequest struct {
	id     string
	result chan error
}

// Deleter manages batching of delete requests
type Deleter struct {
	batchSize   int
	timeout     time.Duration
	requests    chan deleteRequest
	wg          sync.WaitGroup
	mu          sync.Mutex // Mutex to protect access to closed flag
	closed      bool       // Flag to check if requests channel is closed
	purgeClient PurgeClient
}

// NewDeleter initializes a new Deleter
func NewDeleter(batchSize int, timeout time.Duration, purgeClient PurgeClient) *Deleter {
	d := &Deleter{
		batchSize:   batchSize,                // number of requests to batch before executing
		timeout:     timeout,                  // timeout for batching. If timeout is reached, it will execute batch regardless of size
		requests:    make(chan deleteRequest), // channel to receive delete requests.
		purgeClient: purgeClient,
	}
	d.wg.Add(1)
	go d.process()
	return d
}

// Delete enqueues a delete request and waits for the result
func (d *Deleter) Delete(id string) error {
	d.mu.Lock()
	// Check if the channel is already closed
	if d.closed {
		d.mu.Unlock()
		return fmt.Errorf("deleter is closed")
	}
	d.mu.Unlock()

	req := deleteRequest{
		id:     id,
		result: make(chan error),
	}

	d.requests <- req   // Send request to requests channel
	return <-req.result // Wait for request's callback result channel to trigger
}

// process handles batching and execution of delete requests
func (d *Deleter) process() {
	defer d.wg.Done()

	for {
		batch, err := d.waitForBatch()
		if err != nil {
			for _, e := range batch {
				e.result <- err // sending channel closed error back to caller
			}
			return
		}
		if len(batch) == 0 {
			continue
		}
		d.executeBatch(batch)
	}
}

// waitForBatch collects requests until batchSize is reached or timeout occurs
func (d *Deleter) waitForBatch() ([]deleteRequest, error) {
	var batch []deleteRequest
	timer := time.NewTimer(d.timeout)
	defer timer.Stop()

	for {
		select {
		case req, ok := <-d.requests:
			if !ok {
				return nil, fmt.Errorf("deleter closed")
			}
			batch = append(batch, req)
			if len(batch) >= d.batchSize {
				return batch, nil
			}
		case <-timer.C:
			return batch, nil
		}
	}
}

// executeBatch performs the batch delete and sends results back to the callers
func (d *Deleter) executeBatch(batch []deleteRequest) {
	ids := make([]string, len(batch))
	for i, req := range batch {
		ids[i] = req.id
	}
	err := d.purgeClient.Purge(ids)
	for _, req := range batch {
		req.result <- err
		close(req.result)
	}
}

// Close shuts down the Deleter gracefully
func (d *Deleter) Close() {
	d.mu.Lock() // Lock the mutex before closing
	defer d.mu.Unlock()

	if !d.closed {
		close(d.requests)
		d.closed = true
	}
	d.wg.Wait()
}

func main() {
	deleter := NewDeleter(10, 30*time.Second, PurgeClient{})

	// Simulate multiple concurrent delete requests
	var wg sync.WaitGroup
	var cnt int32
	for i := 0; i < 100; i++ {
		wg.Add(1)
		go func(id string) {
			defer wg.Done()
			err := deleter.Delete(id)
			if err != nil {
				fmt.Printf("Error deleting ID %s: %v\n", id, err)
			} else {
				atomic.AddInt32(&cnt, 1)
				fmt.Printf("Successfully deleted ID %s\n", id)
			}
		}(fmt.Sprintf("doc-%d", i))
	}

	wg.Wait()
	fmt.Println("deleted", cnt)
	deleter.Close()
}
