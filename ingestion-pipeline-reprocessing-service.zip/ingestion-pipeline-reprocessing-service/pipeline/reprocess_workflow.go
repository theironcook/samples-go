package pipeline

import (
	"context"
	"fmt"
	"net/http"

	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/ingestion-pipeline-reprocessing-service/config"
	nlp "gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/protobuf-definitions/pkg/nlpbase"
	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/protobuf-definitions/pkg/services/ingest"
	"go.temporal.io/sdk/activity"
	"go.temporal.io/sdk/log"
	"go.temporal.io/sdk/workflow"
)

type ReprocessingWorkflowParams struct {
	BatchID            string
	DocIden            DocIdentifier
	ContentProviderURL string
}

func ReprocessingWorkflow(wfctx workflow.Context, params ReprocessingWorkflowParams) error {
	logger := log.With(workflow.GetLogger(wfctx), "params", params)
	logger.Debug("started")
	defer logger.Debug("completed")

	enricherParams := EnricherActivityParams{
		BatchID: params.BatchID,
		DocIden: params.DocIden,
	}

	batchCtx := config.AppConfig.ReprocessingWorkflow.BatchActOptCfg.ToWFCtx(wfctx)
	metricsCtx := config.AppConfig.ReprocessingWorkflow.PerfMetricsActOptCfg.ToWFCtx(wfctx)

	scrubCtx := config.AppConfig.ReprocessingWorkflow.ScrubActOptCfg.ToWFCtx(wfctx)
	var scrubResult ScrubEnrichmentsResult
	err := workflow.ExecuteActivity(scrubCtx, (*ScrubActivities).ScrubEnrichments, ScrubEnrichmentsParams{BatchID: params.BatchID, DocIden: params.DocIden}).Get(scrubCtx, &scrubResult)
	if err != nil {
		return updateBatchRecord(batchCtx, metricsCtx, params, fmt.Errorf("scrub enrichments failed: %w", err))
	}

	enricherParams = EnricherActivityParams{
		BatchID: params.BatchID,
		DocIden: scrubResult.DocIden,
	}

	nlpFacadeCtx := config.AppConfig.ReprocessingWorkflow.NLPFacade.ActOptCfg.ToWFCtx(wfctx)
	err = workflow.ExecuteActivity(nlpFacadeCtx, (*NLPFacadeActivity).EnrichNLPFacade, enricherParams).Get(nlpFacadeCtx, nil)
	if err != nil {
		return updateBatchRecord(batchCtx, metricsCtx, params, fmt.Errorf("nlp facade failed: %w", err))
	}

	derivedCtx := config.AppConfig.ReprocessingWorkflow.DerivedAttribute.ActOptCfg.ToWFCtx(wfctx)
	err = workflow.ExecuteActivity(derivedCtx, (*DerivedAttributeActivity).EnrichDerivedAttribute, enricherParams).Get(derivedCtx, nil)
	if err != nil {
		return updateBatchRecord(batchCtx, metricsCtx, params, fmt.Errorf("derived attribute failed: %w", err))
	}

	sentimentCtx := config.AppConfig.ReprocessingWorkflow.Sentiment.ActOptCfg.ToWFCtx(wfctx)
	err = workflow.ExecuteActivity(sentimentCtx, (*SentimentActivity).EnrichSentiment, enricherParams).Get(sentimentCtx, nil)
	if err != nil {
		return updateBatchRecord(batchCtx, metricsCtx, params, fmt.Errorf("sentiment failed: %w", err))
	}

	classificationCtx := config.AppConfig.ReprocessingWorkflow.Classification.ActOptCfg.ToWFCtx(wfctx)
	err = workflow.ExecuteActivity(classificationCtx, (*ClassificationActivity).EnrichClassification, enricherParams).Get(classificationCtx, nil)
	if err != nil {
		return updateBatchRecord(batchCtx, metricsCtx, params, fmt.Errorf("classification failed: %w", err))
	}

	intelligentScoringCtx := config.AppConfig.ReprocessingWorkflow.IntelligentScoring.ActOptCfg.ToWFCtx(wfctx)
	err = workflow.ExecuteActivity(intelligentScoringCtx, (*IntelligentScoringActivity).EnrichIntelligentScoring, enricherParams).Get(intelligentScoringCtx, nil)
	if err != nil {
		return updateBatchRecord(batchCtx, metricsCtx, params, fmt.Errorf("intelligent scoring failed: %w", err))
	}

	deleteCtx := config.AppConfig.ReprocessingWorkflow.DeleteRecordActOptCfg.ToWFCtx(wfctx)
	err = workflow.ExecuteActivity(
		deleteCtx,
		(*CMPActivities).DeleteRecord,
		DeleteRecordParams{
			BatchID:            params.BatchID,
			DocIden:            enricherParams.DocIden,
			ContentProviderURL: params.ContentProviderURL,
		}).Get(deleteCtx, nil)
	if err != nil {
		return updateBatchRecord(batchCtx, metricsCtx, params, fmt.Errorf("failed to delete record: %w", err))
	}

	insertCtx := config.AppConfig.ReprocessingWorkflow.InsertRecordActOptCfg.ToWFCtx(wfctx)
	err = workflow.ExecuteActivity(
		insertCtx,
		(*CMPActivities).InsertRecord,
		InsertRecordParams{
			BatchID:            params.BatchID,
			DocIden:            enricherParams.DocIden,
			ContentProviderURL: params.ContentProviderURL,
		}).Get(insertCtx, nil)
	if err != nil {
		return updateBatchRecord(batchCtx, metricsCtx, params, fmt.Errorf("failed to update insert record: %w", err))
	}

	return updateBatchRecord(batchCtx, metricsCtx, params, nil)
}

func updateBatchRecord(batchCtx workflow.Context, metricsCtx workflow.Context, params ReprocessingWorkflowParams, err error) error {
	logger := log.With(workflow.GetLogger(batchCtx), "params", params)

	var progress RecordProgress
	if err == nil {
		progress = ProgressValues.Succeeded
	} else {
		progress = ProgressValues.Failed
	}

	// if run from non-batch context, we don't update batch.
	// TODO: feels clunky- should we refactor?
	// From Bart - let's discuss.  This code should almost never happen if we set our enricher Activity retry policies to basically retry forever in prod
	if params.BatchID != "" {
		updateErr := workflow.ExecuteActivity(
			batchCtx,
			(*BatchActivities).UpdateBatchRecord,
			UpdateBatchRecordParams{
				BatchID:  params.BatchID,
				RecordID: params.DocIden.NaturalID,
				Progress: progress,
				LastErr:  err,
			}).Get(batchCtx, nil)
		if updateErr != nil {
			err = fmt.Errorf("failed to execute the update batch record activity: %w", updateErr)
		}
	}

	if config.AppConfig.CollectPerfMetrics {
		metricsErr := workflow.ExecuteLocalActivity(metricsCtx, (*PerfMetricsActivities).RecordMetric, RecordMetricParams{Succeeded: err == nil}).Get(metricsCtx, nil)

		if metricsErr != nil {
			// Not a huge deal if this fails but it's nice to know if it did
			logger.Warn(fmt.Errorf("failed to record failure metric: %w", metricsErr).Error())
		}
	}

	if err != nil {
		logger.Error(err.Error())
	}

	return err
}

type ScrubActivities struct {
	OOBClient OOBClient
	// DiscoverDocStore FakeOOBASDocStoreDELETEME
	DiscoverDocStore DiscoverDocumentStoreClient
	HTTPClient       http.Client
	BatchClient      BatchClient
}

type ScrubEnrichmentsParams struct {
	BatchID string
	DocIden DocIdentifier
}

type ScrubEnrichmentsResult struct {
	DocIden DocIdentifier
}

func (a *ScrubActivities) ScrubEnrichments(ctx context.Context, params ScrubEnrichmentsParams) (ScrubEnrichmentsResult, error) {
	logger := log.With(activity.GetLogger(ctx), "params", params)
	logger.Debug("started")
	defer logger.Debug("completed")

	recErrParams := RecordErrParams{
		ctx:     ctx,
		batchID: params.BatchID,
		docID:   params.DocIden.NaturalID,
		logger:  logger,
	}

	// get original from doc store
	doc, err := a.DiscoverDocStore.FetchDoc(ctx, params.DocIden)

	if err != nil {
		return ScrubEnrichmentsResult{}, a.BatchClient.RecordErr(recErrParams, fmt.Errorf("scrub enrichments failing, doc store fetch: %w", err))
	}

	// store a copy of the original
	docIdenOrig := params.DocIden
	docIdenOrig.NaturalID = params.DocIden.NaturalID + "-orig"
	err = a.OOBClient.SaveDoc(ctx, docIdenOrig, doc)
	if err != nil {
		return ScrubEnrichmentsResult{}, a.BatchClient.RecordErr(recErrParams, fmt.Errorf("scrub enrichments failing, OOB save: %w", err))
	}
	// TODO - ramy: this code is to deal with doc store bug retrieving conversational data
	// remove once doc store is fixed
	vTypes := map[string]bool{}
	for _, v := range doc.Verbatims {
		if v.VerbatimSource.Source == nlp.SourceEnum_SOURCE_CALL || v.VerbatimSource.Source == nlp.SourceEnum_SOURCE_CHAT {
			for _, vt := range v.VerbatimTypes {
				vTypes[vt] = true
			}
		}
	}
	fVerbatims := []*ingest.IngestVerbatim{}
	for _, v := range doc.Verbatims {
		// for text sources, we filter out verbatim types that are present in the conversational source, removing
		// the duplication bug
		if v.VerbatimSource.Source == nlp.SourceEnum_SOURCE_TEXT {
			var dupFound bool
			for _, vType := range v.VerbatimTypes {
				_, dupFound = vTypes[vType]
				if dupFound {
					break
				}
			}
			if !dupFound {
				fVerbatims = append(fVerbatims, v)
			}
		} else {
			// for call or chat sources, we add them
			fVerbatims = append(fVerbatims, v)
		}
	}
	doc.Verbatims = fVerbatims

	// Bart todo - what else needs to be cleaned?
	for _, v := range doc.Verbatims {
		v.VerbatimResult = nil
	}

	doc.ClassificationResult = nil
	doc.DerivedAttributes = nil
	logger.Info("retrieved document from doc store with verbatims", "verbatim count", len(doc.Verbatims))

	// Store working copy
	err = a.OOBClient.SaveDoc(ctx, params.DocIden, doc)
	if err != nil {
		return ScrubEnrichmentsResult{}, a.BatchClient.RecordErr(recErrParams, fmt.Errorf("scrub enrichments failing, OOB save: %w", err))
	}

	return ScrubEnrichmentsResult{DocIden: params.DocIden}, nil
}

type CMPActivities struct {
	OOBClient   OOBClient
	CMPClient   CMPClient
	BatchClient BatchClient
}

type DeleteRecordParams struct {
	BatchID            string
	DocIden            DocIdentifier
	ContentProviderURL string
}

func (a *CMPActivities) DeleteRecord(ctx context.Context, params DeleteRecordParams) error {
	logger := log.With(activity.GetLogger(ctx), "params", params)
	logger.Debug("started")
	defer logger.Debug("completed")

	recErrParams := RecordErrParams{
		ctx:     ctx,
		batchID: params.BatchID,
		docID:   params.DocIden.NaturalID,
		logger:  logger,
	}

	batch := a.BatchClient.Get(ctx, params.BatchID)

	batchCMPFailCount, err := batch.CMPSaveFailCount(ctx)
	if err != nil {
		return a.BatchClient.RecordErr(recErrParams, fmt.Errorf("failing to  delete the CMP record, failed to fetch the save fail count: %w", err))
	}

	if batchCMPFailCount > 0 {
		// Don't perform any deletes if there are any outstanding failures on CMP saves
		return a.BatchClient.RecordErr(recErrParams, fmt.Errorf("failing to  delete the CMP record, the fail count (%v) is greater than zero", batchCMPFailCount))
	}

	doc, err := a.OOBClient.FetchDoc(ctx, params.DocIden)
	if err != nil {
		return a.BatchClient.RecordErr(recErrParams, fmt.Errorf("failing to  delete the CMP record, failed to fetch the doc from OOB: %w", err))
	}
	delReq := CMPDeleteRequest{
		ProjectID:          doc.Metadata.ProjectId,
		DocumentID:         doc.DocumentId,
		ContentProviderUrl: params.ContentProviderURL,
	}
	resp, err := a.CMPClient.Delete(ctx, delReq)
	if err != nil {
		return a.BatchClient.RecordErr(recErrParams, fmt.Errorf("failing to  delete the CMP record, the CMP delete request failed: %w", err))
	}

	if len(resp.Missing) > 0 {
		return a.BatchClient.RecordErr(recErrParams, fmt.Errorf("failing to  delete the CMP record, missing docs (%v) greater than zero", len(resp.Missing)))
	}

	if resp.Total != 1 {
		return a.BatchClient.RecordErr(recErrParams, fmt.Errorf("failing to  delete the CMP record, found (%d) but expected (1)", resp.Total))
	}

	return nil
}

type InsertRecordParams struct {
	BatchID            string
	DocIden            DocIdentifier
	ContentProviderURL string
}

// TODO - we haven't accounted for duplicate detection response. request could succeed with duplicate detected. This should be an error in the WF
func (a *CMPActivities) InsertRecord(ctx context.Context, params InsertRecordParams) error {
	logger := log.With(activity.GetLogger(ctx), "params", params)
	logger.Debug("started")
	defer logger.Debug("completed")

	recErrParams := RecordErrParams{
		ctx:     ctx,
		batchID: params.BatchID,
		docID:   params.DocIden.NaturalID,
		logger:  logger,
	}

	batch := a.BatchClient.Get(ctx, params.BatchID)
	doc, err := a.OOBClient.FetchDoc(ctx, params.DocIden)
	if err != nil {
		err = fmt.Errorf("insert record failing, OOB fetch doc: %w", err)

		_, incError := batch.IncCMPSaveFailCount(ctx, params.DocIden.NaturalID)
		if incError != nil {
			err = fmt.Errorf("%w: failed to increment the CMP save fail count: %w", err, incError)
		}

		return a.BatchClient.RecordErr(recErrParams, err)
	}

	err = a.CMPClient.UploadDocument(ctx, CMPUploadRequest{Doc: doc, ContentProviderUrl: params.ContentProviderURL})

	if err != nil {
		err = fmt.Errorf("insert record failing on upload: %w", err)

		_, incError := batch.IncCMPSaveFailCount(ctx, params.DocIden.NaturalID)
		if incError != nil {
			err = fmt.Errorf("%w: failed to increment the CMP save fail count: %w", err, incError)
		}

		return a.BatchClient.RecordErr(recErrParams, err)
	}

	return nil
}
