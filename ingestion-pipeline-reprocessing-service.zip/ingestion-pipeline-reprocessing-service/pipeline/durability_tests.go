package pipeline

import (
	"context"
	"fmt"
	"log/slog"
	"time"

	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/ingestion-pipeline-reprocessing-service/config"
	"go.temporal.io/sdk/client"
)

// Durability Test starter functions **********************************************************
func DTIndexer(temporalClient client.Client) {
	start := time.Now()
	ctx := context.Background()
	logger := slog.Default()
	batchID := "dt"
	workflowID := fmt.Sprintf("indexer-%v", batchID)

	startDate := time.Date(2020, 1, 1, 0, 0, 0, 0, time.UTC).Local()
	endDate := time.Date(2020, 2, 1, 0, 0, 0, 0, time.UTC).Local()

	runInfo, err := temporalClient.ExecuteWorkflow(ctx,
		client.StartWorkflowOptions{
			TaskQueue:             config.AppConfig.Temporal.Worker.DefaultTaskQueue,
			ID:                    workflowID,
			WorkflowIDReusePolicy: config.AppConfig.IndexerWorkflow.WorkflowIDReusePolicy,
			// WorkflowExecutionErrorWhenAlreadyStarted: true, // default is false, set to true if you want temporal to throw an error
		},
		IndexerWorkflow,
		IndexerWorkflowParams{
			ContentProviderURL: "https://cmp-staging03.staging.qualtrics.io",
			ProjectID:          11983,
			AccountID:          100,
			StartDate:          &startDate,
			EndDate:            &endDate,
			BatchID:            batchID,
			// ActivityOptions:    appConfig.Indexer.ActivityOptions,
		},
	)

	if err != nil {
		slog.Error(fmt.Errorf("failed to start AllRecordsWorkflow: %w", err).Error())
		return
	}

	logger.Info("started IndexWorkflow", "ID", runInfo.GetID(), "RunID", runInfo.GetRunID())

	var result IndexerWorkflowResult
	runInfo.Get(ctx, &result)
	logger.Info("finished IndexWorkflow", "ID", runInfo.GetID(), "RunID", runInfo.GetRunID(), "result", result, "timeElapsed", fmt.Sprintf("%v", time.Since(start)))
}

// Workflows **********************************************************************************

// Activities *********************************************************************************

// Helpers ************************************************************************************

// Results ***********************************************************************************
/*
STAGING environment tests:

	Concurrency: 30
	Batch size: 10,000
	Records: 1,306,847
	Seconds: 72
	Records per second: 18,151

	(2020 - 2022)
	Concurrency: 30
	Batch size: 10,000
	Records: 3,482,901
	Seconds: 102
	Records per second: 34,146 <-- WOW!!!  At that rate, 13 million records should take 6.3 minutes!

	Concurrency: 10
	Batch size: 10,000
	Records: 3,482,901
	Seconds: 186
	Records per second: 18,725 <-- Interesting, this is the same rate fetching 1.3 million records with the same concurrency of 30
*/
