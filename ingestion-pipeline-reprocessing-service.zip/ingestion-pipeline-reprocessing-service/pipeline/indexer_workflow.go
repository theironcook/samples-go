package pipeline

import (
	"context"
	"errors"
	"fmt"
	"net/url"
	"strings"
	"time"

	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/ingestion-pipeline-reprocessing-service/config"
	"go.temporal.io/sdk/activity"
	"go.temporal.io/sdk/log"
	"go.temporal.io/sdk/workflow"
)

type IndexerWorkflowParams struct {
	BatchID            string
	StartDate          *time.Time // Start date for the query
	EndDate            *time.Time // End date for the query
	Query              string     // Query string to filter the data
	ContentProviderURL string     // URL of the content provider
	ProjectID          int64      // Project ID for which data is being requested
	AccountID          int64
}

func (p *IndexerWorkflowParams) Validate() error {
	if p.StartDate == nil {
		return errors.New("StartDate is an empty string")
	}
	if p.EndDate == nil {
		return errors.New("EndDate is an empty string")
	}
	if p.EndDate.Before(*p.StartDate) {
		return errors.New("StartDate must be before the EndDate")
	}
	if p.ContentProviderURL == "" {
		return errors.New("ContentProviderURL is an empty string")
	}
	if _, err := url.ParseRequestURI(p.ContentProviderURL); err != nil {
		return fmt.Errorf("ContentProviderURL is not a valid url %w", err)
	}
	if p.ProjectID == 0 {
		return errors.New("ProjectID is 0")
	}
	if p.AccountID == 0 {
		return errors.New("AccountID is 0")
	}
	return nil
}

type IndexerWorkflowResult struct {
	TotalCount       int
	UnprocessedCount int
}

func IndexerWorkflow(wfctx workflow.Context, params IndexerWorkflowParams) (IndexerWorkflowResult, error) {
	logger := log.With(workflow.GetLogger(wfctx), "params", params)
	logger.Debug("started")
	defer logger.Debug("completed")

	err := params.Validate()
	if err != nil {
		logger.Error(fmt.Errorf("invalid params sent to indexer workflow: %w", err).Error())
		return IndexerWorkflowResult{}, err
	}

	var totalCount CountResult
	batchCtx := config.AppConfig.IndexerWorkflow.BatchActOptCfg.ToWFCtx(wfctx)

	err = workflow.ExecuteActivity(
		batchCtx,
		(*IndexerActivities).Count,
		CountParams{
			Req: ExportRequest{
				StartDate:          params.StartDate,
				EndDate:            params.EndDate,
				Query:              params.Query,
				ContentProviderURL: params.ContentProviderURL,
				ProjectId:          params.ProjectID,
			},
		},
	).Get(batchCtx, &totalCount)
	if err != nil {
		err = fmt.Errorf("failed to execute the count activity: %w", err)
		logger.Error(err.Error())
		return IndexerWorkflowResult{}, err
	}
	if totalCount.Count == 0 {
		err = errors.New("zero records were found for the query")
		logger.Error(err.Error())
		return IndexerWorkflowResult{TotalCount: 0}, err
	}
	logger = log.With(logger, "totalCount", totalCount)
	logger.Info("found records for the query")

	// Make sure the batch table exists (this might not be called from a batch workflow)
	err = workflow.ExecuteActivity(
		batchCtx,
		(*BatchActivities).CreateBatch,
		CreateBatchParams{
			BatchID: params.BatchID,
		}).Get(batchCtx, nil)
	if err != nil {
		err = fmt.Errorf("failed to execute the create batch activity: %w", err)
		logger.Error(err.Error())
		return IndexerWorkflowResult{}, err
	}

	prefixes := []string{
		"a*", "b*", "c*", "d*", "e*", "f*", "g*", "h*", "i*", "j*", "k*", "l*", "m*", "n*", "o*", "p*", "q*", "r*", "s*", "t*", "u*", "v*", "w*", "x*", "y*", "z*",
		"A*", "B*", "C*", "D*", "E*", "F*", "G*", "H*", "I*", "J*", "K*", "L*", "M*", "N*", "O*", "P*", "Q*", "R*", "S*", "T*", "U*", "V*", "W*", "X*", "Y*", "Z*",
		"0*", "1*", "2*", "3*", "4*", "5*", "6*", "7*", "8*", "9*",
		"\\+*", "\\/*"}

	sema := workflow.NewSemaphore(wfctx, config.AppConfig.IndexerWorkflow.Concurrency)
	wg := workflow.NewWaitGroup(wfctx)
	errs := []error{}
	insertIDsCtx := config.AppConfig.IndexerWorkflow.InsertIDsActOptCfg.ToWFCtx(wfctx)

	for _, p := range prefixes {
		insertIDsParams := InsertIDsParams{
			BatchID: params.BatchID,
			Prefix:  p,
			ExportRequest: ExportRequest{
				StartDate:          params.StartDate,
				EndDate:            params.EndDate,
				Query:              params.Query,
				ContentProviderURL: params.ContentProviderURL,
				ProjectId:          params.ProjectID,
				PageSize:           config.AppConfig.IndexerWorkflow.PageSize,
			},
		}
		if insertIDsParams.ExportRequest.Query == "" {
			insertIDsParams.ExportRequest.Query = fmt.Sprintf("natural_id_hash:%s", p)
		} else {
			insertIDsParams.ExportRequest.Query = fmt.Sprintf("(%s AND natural_id_hash:%s)", insertIDsParams.ExportRequest.Query, p)
		}

		wg.Add(1)
		workflow.Go(insertIDsCtx, func(ctx workflow.Context) {
			sema.Acquire(ctx, 1)
			defer sema.Release(1)
			defer wg.Done()
			err := workflow.ExecuteActivity(ctx, (*IndexerActivities).InsertIDs, insertIDsParams).Get(ctx, nil)
			if err != nil {
				err = fmt.Errorf("failed to execute the insert ids activity: %w", err)
				logger.Error(err.Error(), "prefix", p)
				errs = append(errs, err)
			}
		})
	}
	wg.Wait(wfctx)
	if len(errs) > 0 {
		// If we execute the InsertIds activity forever and it can never fail, this should not happen
		// but if it does, we should return an error of all the Activity errors collected
		var sb strings.Builder
		for _, err := range errs {
			sb.WriteString(err.Error())
			sb.WriteString("\n")
		}
		return IndexerWorkflowResult{}, errors.New(sb.String())
	}

	var countUnprocessedResult CountUnprocessedResult
	err = workflow.ExecuteActivity(
		batchCtx, (*IndexerActivities).CountUnprocessed,
		CountUnprocessedParams{
			BatchID: params.BatchID,
		}).Get(batchCtx, &countUnprocessedResult)

	if err != nil {
		err = fmt.Errorf("failed to execute the count unprocessed activity: %w", err)
		logger.Error(err.Error())
		return IndexerWorkflowResult{}, err
	}

	if totalCount.Count != countUnprocessedResult.Count {
		// Bart todo - this should be an on-call alert via Splunk?
		logger.Error("total record count does not match unprocessed count", "totalCount", totalCount, "unprocessedCount", countUnprocessedResult.Count)
	}

	return IndexerWorkflowResult{TotalCount: totalCount.Count, UnprocessedCount: countUnprocessedResult.Count}, err
}

type IndexerActivities struct {
	ExpCli ExportApiClient
	BatCli BatchClient
	OOBCli OOBClient
}

type CountParams struct {
	Req ExportRequest
}

type CountResult struct {
	Count int
}

func (a *IndexerActivities) Count(ctx context.Context, params CountParams) (CountResult, error) {
	logger := log.With(activity.GetLogger(ctx), "params", params)

	count, err := a.ExpCli.Count(ctx, params.Req)
	if err != nil {
		err = fmt.Errorf("failed to get  the export count: %w", err)
		logger.Error(err.Error())
		return CountResult{}, err
	}
	return CountResult{Count: count}, nil
}

type CountUnprocessedParams struct {
	BatchID string
}

type CountUnprocessedResult struct {
	Count int
}

func (a *IndexerActivities) CountUnprocessed(ctx context.Context, params CountUnprocessedParams) (CountUnprocessedResult, error) {
	logger := log.With(activity.GetLogger(ctx), "params", params)
	b := a.BatCli.Get(ctx, params.BatchID)
	count, err := b.CountUnprocessed(ctx)

	if err != nil {
		err = fmt.Errorf("failed to count unprocessed batch records: %w", err)
		logger.Error(err.Error())
		return CountUnprocessedResult{}, err
	}

	return CountUnprocessedResult{Count: count}, nil
}

type InsertIDsParams struct {
	BatchID       string
	Prefix        string
	ExportRequest ExportRequest
}

type InsertIDsResult struct {
	TotalCount int
}

func (a *IndexerActivities) InsertIDs(ctx context.Context, params InsertIDsParams) (InsertIDsResult, error) {
	start := time.Now()
	totalCount := 0
	logger := log.With(activity.GetLogger(ctx), "params", params)

	batch := a.BatCli.Get(ctx, params.BatchID)

	scroll, err := a.ExpCli.Request(ctx, params.ExportRequest)
	if err != nil {
		err = fmt.Errorf("failed to create the export request: %w", err)
		logger.Error(err.Error())
		return InsertIDsResult{}, err
	}

	for {
		start := time.Now()
		hasMore, err := scroll.Next(ctx)
		if err != nil {
			err = fmt.Errorf("failed to get the export next page: %w", err)
			logger.Error(err.Error())
			return InsertIDsResult{}, err
		}
		if !hasMore {
			break
		}
		records := scroll.Value()
		err = batch.AddRecords(ctx, records, params.Prefix)
		if err != nil {
			err = fmt.Errorf("failed to add records: %w", err)
			logger.Error(err.Error())
			return InsertIDsResult{}, err
		}
		activity.RecordHeartbeat(ctx)
		logger.Debug("added records", "recordCount", len(records), "timeElapsed", fmt.Sprintf("%v", time.Since(start)))
		totalCount += len(records)
	}

	logger.Debug("completed", "timeElapsed", fmt.Sprintf("%v", time.Since(start)))
	return InsertIDsResult{TotalCount: totalCount}, nil
}
