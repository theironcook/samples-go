package pipeline

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"os"
	"sync"
	"time"
)

const (
	logDir         = "./log"
	logFile        = "perf_metrics.log"
	tickerInterval = time.Second
)

type PerfMetricsActivities struct {
	metrics *PerfMetrics
}

type RecordMetricParams struct {
	Succeeded bool
}

func (a *PerfMetricsActivities) RecordMetric(ctx context.Context, params RecordMetricParams) error {
	if a.metrics == nil {
		a.metrics = &PerfMetrics{}
		go a.metrics.startCollecting(ctx)
	}
	if params.Succeeded {
		a.metrics.recordSucceeded()
	} else {
		a.metrics.recordFailed()
	}
	return nil
}

type PerfMetrics struct {
	mutex         sync.Mutex
	started       bool
	succeeded     int
	failed        int
	contTicks     int
	contSucceeded int
	contFailed    int
}

func (m *PerfMetrics) recordSucceeded() {
	m.mutex.Lock()
	defer m.mutex.Unlock()
	m.succeeded++
}

func (m *PerfMetrics) recordFailed() {
	m.mutex.Lock()
	defer m.mutex.Unlock()
	m.failed++
}

func (m *PerfMetrics) startCollecting(ctx context.Context) {
	m.mutex.Lock()
	if m.started {
		m.mutex.Unlock()
		return
	}
	m.started = true
	m.mutex.Unlock()

	if err := ensureLogDirectory(logDir); err != nil {
		slog.Error(err.Error())
		return
	}

	file, err := os.OpenFile(fmt.Sprintf("%s/%s", logDir, logFile), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		slog.Error(fmt.Errorf("failed to open metrics.log: %w", err).Error())
		return
	}
	defer file.Close()

	encoder := json.NewEncoder(file)
	ticker := time.NewTicker(tickerInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			m.collectAndLogMetrics(encoder)
		}
	}
}

func (m *PerfMetrics) collectAndLogMetrics(encoder *json.Encoder) {
	m.mutex.Lock()
	defer m.mutex.Unlock()

	if m.succeeded+m.failed > 0 {
		m.contSucceeded += m.succeeded
		m.contFailed += m.failed
		m.contTicks++
		rollingAvg := float64(m.contSucceeded+m.contFailed) / float64(m.contTicks)
		slog.Info("perf_metrics", "succeeded", m.succeeded, "failed", m.failed, "rollingAvg", fmt.Sprintf("%.2f", rollingAvg))
		logEntry := map[string]interface{}{
			"timestamp":  time.Now().Format(time.RFC3339),
			"succeeded":  m.succeeded,
			"failed":     m.failed,
			"rollingAvg": fmt.Sprintf("%.2f", rollingAvg),
		}
		if err := encoder.Encode(logEntry); err != nil {
			slog.Default().Error(fmt.Errorf("failed to write perf metric log entry: %w", err).Error())
		}
		m.failed = 0
		m.succeeded = 0
	} else {
		m.contTicks = 0
		m.contSucceeded = 0
		m.contFailed = 0
	}
}

func ensureLogDirectory(path string) error {
	return os.MkdirAll(path, os.ModePerm)
}
