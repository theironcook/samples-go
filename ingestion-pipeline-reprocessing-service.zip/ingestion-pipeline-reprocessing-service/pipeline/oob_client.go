package pipeline

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"net/http"

	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/protobuf-definitions/pkg/services/ingest"
	"google.golang.org/protobuf/proto"
)

type OOBClient struct {
	HTTPCli http.Client
	URL     string
}

type DocIdentifier struct {
	Instance  string
	AccountID int64
	ProjectID int64
	NaturalID string
}

func (d DocIdentifier) Validate() error {
	if d.Instance == "" {
		return fmt.Errorf("Instance is required")
	}
	if d.NaturalID == "" {
		return fmt.Errorf("NaturalID is required")
	}
	// Bart todo - 0 is a valid account id...
	// How to tell if it was explicitly set to 0 verse just missing?
	// if d.AccountId == 0 {
	// 	return fmt.Errorf("accountId is required")
	// }
	// Bart todo - 0 is a valid project id...
	// if d.projectId == 0 {
	// 	return fmt.Errorf("projectId is required")
	// }
	return nil
}

// https://gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/document-storage/-/blob/main/api/api.yaml?ref_type=heads
// /storage/{Instance}/{AccountId}/{ProjectId}/{DocumentId}:
// cmp-staging03/0/6990814/1111111111110

// How to quickly upload a doc to oob
// curl --location 'https://discover-pipelines-orchestration.staging.qualtrics.io/oobservice/cmp-staging03/0/6990814/1111111111111' \
// --header 'Content-Type: application/octet-stream' \
// --data '@/Users/bartwood/projects/ingestion-pipeline-reprocessing-service/oob-sample.pb'

// use underscore prefix to designate that it's the original doc
func (c OOBClient) FetchDoc(ctx context.Context, docIden DocIdentifier) (*ingest.IngestDocument, error) {
	url := fmt.Sprintf("%s/%s/%d/%d/%s", c.URL, docIden.Instance, docIden.AccountID, docIden.ProjectID, docIden.NaturalID)
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return nil, fmt.Errorf("error fetching doc (OOB) while creating request: %w", err)
	}

	InjectCtxPropsToHeaders(ctx, req)
	resp, err := c.HTTPCli.Do(req)
	if err != nil {
		return nil, fmt.Errorf("error fetching doc (OOB) while sending request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		// todo Bart - ask Ramy if we should try extracting the response body and try to include that in the error (like doc_store_client.go code does)
		return nil, fmt.Errorf("error fetching doc (OOB), expected response (%v) but received (%v)", http.StatusOK, resp.StatusCode)
	}

	// Read the response body
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("error fetching doc (OOB) while reading response body: %w", err)
	}

	doc := &ingest.IngestDocument{}
	err = proto.Unmarshal(body, doc)
	if err != nil {
		return nil, fmt.Errorf("error fetching doc (OOB) while unmarshalling response body: %w", err)
	}

	return doc, nil
}

func (c OOBClient) SaveDoc(ctx context.Context, docIden DocIdentifier, doc *ingest.IngestDocument) error {
	url := fmt.Sprintf("%s/%s/%d/%d/%s", c.URL, docIden.Instance, docIden.AccountID, docIden.ProjectID, docIden.NaturalID)
	docBytes, err := proto.Marshal(doc)
	if err != nil {
		return fmt.Errorf("error saving doc (OOB) while marshalling doc: %w", err)
	}

	reader := bytes.NewReader(docBytes)

	req, err := http.NewRequestWithContext(ctx, http.MethodPut, url, reader)
	if err != nil {
		return fmt.Errorf("error saving doc (OOB) while creating request: %w", err)
	}

	InjectCtxPropsToHeaders(ctx, req)
	req.Header.Set("doc-source-type", doc.Source)
	req.Header.Set("Content-Type", "application/octet-stream")

	resp, err := c.HTTPCli.Do(req)
	if err != nil {
		return fmt.Errorf("error saving doc (OOB) while sending request: %w", err)
	}
	defer resp.Body.Close()

	_, err = io.ReadAll(resp.Body)
	if err != nil {
		return fmt.Errorf("error saving doc (OOB) while reading response body: %w", err)
	}

	if resp.StatusCode != http.StatusCreated {
		// todo Bart - ask Ramy if we should try extracting the response body and try to include that in the error (like doc_store_client.go code does)
		return fmt.Errorf("error saving doc (OOB), expected response (%v) but received (%v)", http.StatusCreated, resp.StatusCode)
	}

	return nil
}
