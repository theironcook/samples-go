package pipeline

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"time"
)

// Request defines the structured input for FetchAllResults, including date ranges, queries, and project information.
type ExportRequest struct {
	StartDate          *time.Time // Start date for the query
	EndDate            *time.Time // End date for the query
	Query              string     // Query string to filter the data
	ContentProviderURL string     // URL of the content provider
	ProjectId          int64      // Project ID for which data is being requested
	ScrollId           string     // If ScrollId is provided, all other fields are omitted
	PageSize           int
}

type ExportApiClient struct {
	URL     string
	HTTPCli http.Client
	CMPCli  CMPClient
}

func (c *ExportApiClient) Count(ctx context.Context, request ExportRequest) (int, error) {
	// Build the URL parameters from structured inputs
	urlArgs := c.buildURLParams(request, "", true, 1)
	authToken, err := c.CMPCli.GetExportAPIAuthToken(request.ContentProviderURL, request.ProjectId)
	if err != nil {
		return 0, fmt.Errorf("error counting records (export API) while getting auth: %w", err)
	}

	response, err := c.makeExportRequest(ctx, authToken, urlArgs)
	if err != nil {
		return 0, err
	}
	return response.TotalCount, nil
}

func (c *ExportApiClient) Request(ctx context.Context, request ExportRequest) (exportAPIDocIterator, error) {
	authToken, err := c.CMPCli.GetExportAPIAuthToken(request.ContentProviderURL, request.ProjectId)
	if err != nil {
		return exportAPIDocIterator{}, fmt.Errorf("error in request (export API) while getting auth: %w", err)
	}

	if request.PageSize < 0 || request.PageSize > 10_001 {
		return exportAPIDocIterator{}, fmt.Errorf("error in request (export API), PageSize (%v) must be greater than 0 and less than 10,001", request.PageSize)
	}

	return exportAPIDocIterator{
		ctx:          ctx,
		indexer:      c,
		request:      request,
		scrollID:     "",
		hasMore:      true,
		authToken:    authToken,
		currentIndex: 0,
		pageSize:     request.PageSize,
	}, nil
}

// buildURLParams builds the query parameters for the API request from the provided request object.
//
// Parameters:
// - params: Request object containing query, date range, and project details.
// - scrollID: Scroll ID for paginating the results.
// - preview: Boolean flag to indicate if this is a preview request.
//
// Returns:
// - url.Values: The URL parameters for the API request.
func (c *ExportApiClient) buildURLParams(params ExportRequest, scrollID string, preview bool, pageSize int) url.Values {
	urlArgs := url.Values{}

	if scrollID == "" {
		// Add basic query parameters
		urlArgs.Set("schema", "true")
		urlArgs.Set("attributes", "natural_id")             // fields to return
		urlArgs.Set("page_size", fmt.Sprint(pageSize))      // returning x records at a time
		urlArgs.Set("preview", strconv.FormatBool(preview)) //TODO: remove this line.

		// Convert start and end dates into the desired query format
		query := ""
		if params.StartDate != nil || params.EndDate != nil {
			startDateStr := "*"
			endDateStr := "*"
			if params.StartDate != nil {
				startDateStr = params.StartDate.UTC().Format(dateFormat)
			}
			if params.EndDate != nil {
				endDateStr = params.EndDate.UTC().Format(dateFormat)
			}
			query = fmt.Sprintf("_doc_time:[%s TO %s] ", startDateStr, endDateStr)
		}
		if params.Query != "" {
			if query != "" {
				query += " AND "
			}
			query = fmt.Sprintf("%s%s", query, params.Query)
		}
		if query != "" {
			urlArgs.Set("query", query)
		}
	} else {
		urlArgs.Set("scroll", scrollID)
	}

	return urlArgs
}

// exportAPIServiceResponse represents the response from the API, including documents, scroll ID, and total count.
type exportAPIServiceResponse struct {
	Documents  []map[string]interface{} `json:"documents"`
	Sentences  []map[string]interface{} `json:"sentences"`
	ScrollId   string                   `json:"scroll_id"`
	TotalCount int                      `json:"total_count"`
}

// makeExportRequest sends an API request to Export API
//
// Parameters:
// - ctx: Context for controlling timeouts and cancellations.
// - authToken: The bearer token for the project
// - scrollID: Scroll ID for paginating through results.
// - index: The index to query (e.g., "documents").
// - urlArgs: URL parameters for the API request.
//
// Returns:
// - *exportAPIServiceResponse: The API response containing documents, sentences, and scroll ID.
// - error: An error if the request or response processing fails.
func (c *ExportApiClient) makeExportRequest(ctx context.Context, authToken string, urlArgs url.Values) (*exportAPIServiceResponse, error) {
	endpoint := c.URL + "/documents?" + urlArgs.Encode()
	req, err := http.NewRequestWithContext(ctx, "GET", endpoint, nil)
	if err != nil {
		return nil, fmt.Errorf("error making export API request while creating request: %w", err)
	}

	InjectCtxPropsToHeaders(ctx, req)
	req.Header.Add("Authorization", "Bearer "+authToken)
	req.Header.Add("Accept", "application/json")

	resp, err := c.HTTPCli.Do(req)
	if err != nil {
		return nil, fmt.Errorf("error making export API request while sending request: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		err = fmt.Errorf("error making export API request, expected response (%v) but received (%v)", http.StatusOK, resp.StatusCode)
		bodyBytes, readBodyErr := io.ReadAll(resp.Body)
		if readBodyErr != nil {
			err = fmt.Errorf("%w: error reading response body: %w", err, readBodyErr)
		} else {
			err = fmt.Errorf("%w: response body: %v", err, string(bodyBytes))
		}
		return nil, err
	}

	var response exportAPIServiceResponse
	err = json.NewDecoder(resp.Body).Decode(&response)
	if err != nil {
		return nil, fmt.Errorf("error making export API request while reading response body: %w", err)
	}

	return &response, nil
}

// exportAPIDocIterator is the custom iterator for paginating through batches of records.
type exportAPIDocIterator struct {
	ctx          context.Context
	indexer      *ExportApiClient
	request      ExportRequest
	scrollID     string
	currentBatch []string
	hasMore      bool
	authToken    string
	currentIndex int
	pageSize     int
}

// Next fetches the next batch of records and returns true if there are more records.
func (e *exportAPIDocIterator) Next(ctx context.Context) (bool, error) {
	if e.currentIndex < len(e.currentBatch) {
		return true, nil
	}

	// Fetch the next batch of records
	urlArgs := e.indexer.buildURLParams(e.request, e.scrollID, false, e.pageSize)

	response, err := e.indexer.makeExportRequest(e.ctx, e.authToken, urlArgs)
	if err != nil {
		e.hasMore = false
		return false, fmt.Errorf("error in export API next: %w", err)
	}

	// Update the iterator state
	e.scrollID = response.ScrollId
	e.currentBatch = make([]string, len(response.Documents))
	for i, doc := range response.Documents {
		e.currentBatch[i] = doc["natural_id"].(string)
	}

	e.hasMore = len(response.Documents) > 0
	e.currentIndex = 0

	return e.hasMore, nil
}

// Value returns the current set of records (batch).
func (e *exportAPIDocIterator) Value() []string {
	if e.currentIndex >= len(e.currentBatch) {
		return nil
	}
	value := e.currentBatch[e.currentIndex:]
	e.currentIndex = len(e.currentBatch)
	return value
}

const dateFormat = "20060102150405"
