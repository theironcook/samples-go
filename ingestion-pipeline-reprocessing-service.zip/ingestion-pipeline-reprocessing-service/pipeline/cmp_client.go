package pipeline

import (
	"bytes"
	"compress/gzip"
	"context"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net/http"

	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/protobuf-definitions/pkg/services/ingest"
	"google.golang.org/protobuf/proto"
)

type (
	CMPBasicAuth struct {
		Username string
		Password string
	}
	CMPOauth struct {
		AuthUrl      string
		AuthUser     string
		AuthPassword string
	}

	CMPClient struct {
		BasicAuth  *CMPBasicAuth
		AuthConfig CMPOauth
		HTTPCli    http.Client
	}

	CMPUploadRequest struct {
		ContentProviderUrl string
		Doc                *ingest.IngestDocument
	}

	CMPPurgeRequest struct {
		NaturalId          string
		ContentProviderUrl string
	}

	// StudioBulkDeleteDocumentsRequest represents the request to bulk delete documents.
	CMPDeleteRequest struct {
		ProjectID          int64 // Corresponds to project_id in the JSON request
		DocumentID         int64 // Corresponds to document_ids in the JSON request
		ContentProviderUrl string
	}
	// StudioBulkDeleteDocumentsRequest represents the request to bulk delete documents.
	bulkDeleteReq struct {
		ProjectID          int64   `json:"project_id"`   // Corresponds to project_id in the JSON request
		DocumentIDs        []int64 `json:"document_ids"` // Corresponds to document_ids in the JSON request
		BatchSize          int     `json:"batch_size"`   // Corresponds to batch_size in the JSON request, with a default value of 1000
		ContentProviderUrl string  `json:"-"`
	}

	// CMPBulkDeleteResponse represents the response after attempting to bulk delete documents.
	CMPBulkDeleteResponse struct {
		//Timestamp time.Time `json:"timestamp"` // Time when the response is generated
		Total   int     `json:"total"`   // Total number of documents in the request
		Deleted int     `json:"deleted"` // Number of documents successfully deleted
		Missing []int64 `json:"missing"` // List of documents that were not found
	}
)

func (c *CMPClient) Delete(ctx context.Context, req CMPDeleteRequest) (CMPBulkDeleteResponse, error) {
	d := bulkDeleteReq{
		ProjectID:          req.ProjectID,
		DocumentIDs:        []int64{req.DocumentID}, // Convert single int64 to a slice of int64
		BatchSize:          1000,                    // Bart todo - ask Ramy if this value is correct
		ContentProviderUrl: req.ContentProviderUrl,
	}
	url := fmt.Sprintf("%s%s", d.ContentProviderUrl, "/cbrestfulapi/api/documents/bulk_delete")
	reqB, err := json.Marshal(d)
	if err != nil {
		return CMPBulkDeleteResponse{}, fmt.Errorf("error deleting doc (CMP) while marshalling to json: %w", err)
	}

	httpReq, err := http.NewRequestWithContext(ctx, http.MethodPost, url, bytes.NewReader(reqB))
	if err != nil {
		return CMPBulkDeleteResponse{}, fmt.Errorf("error deleting doc (CMP) while creating request: %w", err)
	}

	authorization, err := c.getAuthorization("")
	if err != nil {
		return CMPBulkDeleteResponse{}, fmt.Errorf("error deleting doc (CMP) while getting auth: %w", err)
	}

	httpReq.Header.Set("Authorization", authorization)
	httpReq.Header.Set("Content-Type", "application/json")
	InjectCtxPropsToHeaders(ctx, httpReq)
	resp, err := c.HTTPCli.Do(httpReq)
	if err != nil {
		return CMPBulkDeleteResponse{}, fmt.Errorf("error deleting doc (CMP) while sending request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		err = fmt.Errorf("error deleting doc (CMP), expected response (%v) but received (%v)", http.StatusOK, resp.StatusCode)

		bodyBytes, readBodyErr := io.ReadAll(resp.Body)

		if readBodyErr != nil {
			err = fmt.Errorf("%w: error reading response body: %w", err, readBodyErr)
		} else {
			err = fmt.Errorf("%w: response body: %v", err, string(bodyBytes))
		}

		return CMPBulkDeleteResponse{}, err
	}
	var bulkResp CMPBulkDeleteResponse
	bb, err := io.ReadAll(resp.Body)
	if err != nil {
		return CMPBulkDeleteResponse{}, fmt.Errorf("error deleting doc (CMP) while reading body: %w", err)
	}
	err = json.Unmarshal(bb, &bulkResp)
	if err != nil {
		return CMPBulkDeleteResponse{}, fmt.Errorf("error deleting doc (CMP) while unmarshalling body: %w", err)
	}
	return bulkResp, nil
}

func (c *CMPClient) UploadDocument(ctx context.Context, doc CMPUploadRequest) error {
	url := fmt.Sprintf("%s/%s", doc.ContentProviderUrl, "mobile/rest/staging_loader/upload/message")

	// Serialize the document into bytes
	documentBytes, err := proto.Marshal(doc.Doc)
	if err != nil {
		return fmt.Errorf("error uploading doc (CMP) while marshalling doc: %w", err)
	}

	// Compress the serialized data using gzip
	var compressedBytes bytes.Buffer
	gzipWriter := gzip.NewWriter(&compressedBytes)
	//defer gzipWriter.Close()

	_, err = gzipWriter.Write(documentBytes)
	gzipWriter.Close()

	if err != nil {
		return fmt.Errorf("error uploading doc (CMP) while gzipping doc: %w", err)
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, url, &compressedBytes)
	if err != nil {
		return fmt.Errorf("error uploading doc (CMP) (CMP) while creating request: %w", err)
	}

	authorization, err := c.getAuthorization("realtime_upload")
	if err != nil {
		return fmt.Errorf("error uploading doc (CMP) while getting auth: %w", err)
	}

	// Set appropriate headers
	InjectCtxPropsToHeaders(ctx, req)
	req.Header.Set("Authorization", authorization)
	req.Header.Set("Content-Type", "application/octet-stream")
	req.Header.Set("Content-Encoding", "gzip")            // This is typically used with octet-stream data
	req.Header.Set("Content-Transfer-Encoding", "binary") // This is typically used with octet-stream data
	req.Header.Set("Content-Disposition", "attachment")   // Example additional header for octet-stream

	resp, err := c.HTTPCli.Do(req)
	if err != nil {
		return fmt.Errorf("error uploading doc (CMP) while sending request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		err = fmt.Errorf("error uploading doc (CMP), expected response (%v) but received (%v)", http.StatusOK, resp.StatusCode)

		bodyBytes, readBodyErr := io.ReadAll(resp.Body)

		if readBodyErr != nil {
			err = fmt.Errorf("%w: error reading response body: %w", err, readBodyErr)
		} else {
			err = fmt.Errorf("%w: error response: %s", err, string(bodyBytes))
		}

		return err
	}

	return nil
}

// getExportAPIAuthToken retrieves the export API token using the content provider URL and project ID.
//
// Parameters:
// - contentProviderURL: The URL of the content provider.
// - projectID: The ID of the project for which the token is being requested.
//
// Returns:
// - string: The export API token.
// - error: An error if the token retrieval fails.
func (c *CMPClient) GetExportAPIAuthToken(contentProviderURL string, projectID int64) (string, error) {
	authToken, err := c.getAuthorization("token_export")
	if err != nil {
		return "", err
	}

	return c.getProjectExportToken(contentProviderURL, projectID, authToken)
}

// getAuthorization retrieves an OAuth bearer token that can be used to access CMP.
//
// Returns:
// - string: The OAuth bearer token.
// - error: An error if the token retrieval fails.
func (c *CMPClient) getAuthorization(scope string) (string, error) {
	// return basic auth if its available
	if c.BasicAuth != nil {
		dataBytes := []byte(fmt.Sprintf("%s:%s", c.BasicAuth.Username, c.BasicAuth.Password))
		base64Encoded := base64.StdEncoding.EncodeToString(dataBytes)
		return fmt.Sprintf("Basic %s", base64Encoded), nil
	}

	authString := fmt.Sprintf("%s:%s", c.AuthConfig.AuthUser, c.AuthConfig.AuthPassword)
	authStringEncoded := base64.StdEncoding.EncodeToString([]byte(authString))

	data := []byte(`grant_type=client_credentials&scope=cx-designer.api[group='token_export']`)
	req, err := http.NewRequest("POST", c.AuthConfig.AuthUrl, bytes.NewBuffer(data))
	if err != nil {
		return "", fmt.Errorf("error getting auth while creating request: %w", err)
	}

	req.Header.Set("Authorization", "Basic "+authStringEncoded)
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	resp, err := c.HTTPCli.Do(req)
	if err != nil {
		return "", fmt.Errorf("error getting auth while sending request: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		err = fmt.Errorf("error getting auth, expected response (%v) but received (%v)", http.StatusOK, resp.StatusCode)

		bodyBytes, readBodyErr := io.ReadAll(resp.Body)

		if readBodyErr != nil {
			err = fmt.Errorf("%w: error reading response body: %w", err, readBodyErr)
		} else {
			err = fmt.Errorf("%w: response body: %v", err, string(bodyBytes))
		}

		return "", err
	}

	var respData map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&respData); err != nil {
		return "", err
	}

	accessToken, ok := respData["access_token"].(string)
	if !ok {
		return "", fmt.Errorf("error getting auth, missing access token: %w", err)
	}
	accessToken = "Bearer " + accessToken
	return accessToken, nil
}

// getProjectExportToken retrieves the bearer token for this project from CMP. This is the bearer token that Export API associates with a project
func (c *CMPClient) getProjectExportToken(contentProviderURL string, projectID int64, cmpAuthToken string) (string, error) {
	url := fmt.Sprintf("%s/api/v1/client/token/export?project_id=%d", contentProviderURL, projectID)

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return "", fmt.Errorf("error getting project export token while creating request: %w", err)
	}

	req.Header.Set("Authorization", cmpAuthToken)

	resp, err := c.HTTPCli.Do(req)
	if err != nil {
		return "", fmt.Errorf("error getting project export token while sending request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		err = fmt.Errorf("error getting project export token, expected response (%v) but received (%v)", http.StatusOK, resp.StatusCode)
		bodyBytes, readBodyErr := io.ReadAll(resp.Body)
		if readBodyErr != nil {
			err = fmt.Errorf("%w: error reading response body: %w", err, readBodyErr)
		} else {
			err = fmt.Errorf("%w: response body: %v", err, string(bodyBytes))
		}
		return "", err
	}

	bodyBytes, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", fmt.Errorf("error getting project export token while reading response body: %w", err)
	}

	var respData map[string]interface{}
	if err := json.Unmarshal(bodyBytes, &respData); err != nil {
		return "", fmt.Errorf("error getting project export token while unmarshalling response body: %w", err)
	}

	exportAPIToken, ok := respData["token"].(string)
	if !ok {
		return "", fmt.Errorf("error getting project export token, missing auth token: %w", err)
	}

	return exportAPIToken, nil
}
