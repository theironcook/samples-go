package pipeline

import (
	"crypto/tls"
	"fmt"
	"log/slog"
	"strings"

	"github.com/uber-go/tally/v4"
	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/ingestion-pipeline-reprocessing-service/config"
	"go.temporal.io/sdk/client"
	temtally "go.temporal.io/sdk/contrib/tally"
	"go.temporal.io/sdk/converter"
	temlog "go.temporal.io/sdk/log"
	"go.temporal.io/sdk/workflow"
)

func NewTemporalClient(metricsScope tally.Scope) (client.Client, error) {
	options := client.Options{
		HostPort:  config.AppConfig.Temporal.Client.HostPort,
		Namespace: config.AppConfig.Temporal.Client.Namespace,
		DataConverter: converter.NewCompositeDataConverter(
			converter.NewNilPayloadConverter(),
			converter.NewByteSlicePayloadConverter(),
			// Order is important here. Both ProtoJsonPayload and ProtoPayload converters check for the same proto.Message
			// interface. The first match (ProtoJsonPayload in this case) will always be used for serialization.
			// Deserialization is controlled by metadata, therefore both converters can deserialize corresponding data format
			converter.NewProtoPayloadConverter(),
			converter.NewJSONPayloadConverter(),
		),
		Logger:             temlog.NewStructuredLogger(slog.Default()),
		MetricsHandler:     temtally.NewMetricsHandler(metricsScope),
		ContextPropagators: []workflow.ContextPropagator{NewContextPropagator()},
	}

	isLocalHost := strings.HasPrefix(strings.ToUpper(config.AppConfig.Temporal.Client.HostPort), "LOCALHOST") || strings.HasPrefix(config.AppConfig.Temporal.Client.HostPort, "127.0.0.1")

	if !isLocalHost {
		slog.Default().Info("Configuring Temporal to use TLS")
		options.ConnectionOptions = client.ConnectionOptions{
			TLS: &tls.Config{
				Certificates: []tls.Certificate{config.AppSecrets.TLSCert},
			},
		}
	} else {
		slog.Default().Info("Configuring Temporal to not use TLS because connection is to localhost")
	}

	client, err := client.Dial(options)
	if err != nil {
		return nil, fmt.Errorf("failed to dial Temporal: %w", err)
	}

	return client, nil
}
