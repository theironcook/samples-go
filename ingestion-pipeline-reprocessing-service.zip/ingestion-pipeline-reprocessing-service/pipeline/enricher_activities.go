package pipeline

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"net/http"
	"time"

	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/protobuf-definitions/pkg/services/ingest"
	"go.temporal.io/sdk/activity"
	"go.temporal.io/sdk/log"
	"google.golang.org/protobuf/proto"
)

type Enricher struct {
	Name    string
	OOBCli  OOBClient
	URL     string
	HTTPCli http.Client
	BatCli  BatchClient
}

type EnricherActivityParams struct {
	BatchID string
	DocIden DocIdentifier
}

type NLPFacadeActivity struct {
	enricher Enricher
}

func (a *NLPFacadeActivity) EnrichNLPFacade(ctx context.Context, params EnricherActivityParams) error {
	return a.enricher.enrich(ctx, params)
}

type DerivedAttributeActivity struct {
	enricher Enricher
}

func (a *DerivedAttributeActivity) EnrichDerivedAttribute(ctx context.Context, params EnricherActivityParams) error {
	return a.enricher.enrich(ctx, params)
}

type SentimentActivity struct {
	enricher Enricher
}

func (a *SentimentActivity) EnrichSentiment(ctx context.Context, params EnricherActivityParams) error {
	return a.enricher.enrich(ctx, params)
}

type ClassificationActivity struct {
	enricher Enricher
}

func (a *ClassificationActivity) EnrichClassification(ctx context.Context, params EnricherActivityParams) error {
	return a.enricher.enrich(ctx, params)
}

type IntelligentScoringActivity struct {
	enricher Enricher
}

func (a *IntelligentScoringActivity) EnrichIntelligentScoring(ctx context.Context, params EnricherActivityParams) error {
	return a.enricher.enrich(ctx, params)
}

func (e *Enricher) enrich(ctx context.Context, params EnricherActivityParams) (theError error) {
	logger := log.With(activity.GetLogger(ctx), "URL", e.URL, "params", params, "Name", e.Name)
	logger.Debug("started")
	defer logger.Debug("completed")

	recErrParams := RecordErrParams{
		ctx:     ctx,
		batchID: params.BatchID,
		docID:   params.DocIden.NaturalID,
		logger:  logger,
	}

	doc, err := e.OOBCli.FetchDoc(ctx, params.DocIden)
	if err != nil {
		return e.BatCli.RecordErr(recErrParams, fmt.Errorf("enricher %v failing, OOB fetch: %w", e.Name, err))
	}

	// build request
	httpRequest, err := e.serializeToHttpRequest(ctx, params.DocIden, doc)
	if err != nil {
		return e.BatCli.RecordErr(recErrParams, fmt.Errorf("enricher %v failing, serializing request: %w", e.Name, err))
	}

	// send request to the enricher api
	startSend := time.Now()
	res, err := e.HTTPCli.Do(httpRequest)

	if err != nil {
		return e.BatCli.RecordErr(recErrParams, fmt.Errorf("enricher %v failing: %w", e.Name, err))
	}

	if res.StatusCode != http.StatusOK {
		return e.BatCli.RecordErr(recErrParams, fmt.Errorf("enricher %v failing, expected response (%v) but received (%v)", e.Name, http.StatusOK, res.StatusCode))
	}

	logger.Info(fmt.Sprintf("enricher %v completed", e.Name), "StatusCode", res.StatusCode, "TimeEllapsed", fmt.Sprintf("%v", time.Since(startSend).String()))

	defer res.Body.Close()

	doc, err = e.deserializeFromHttpResponse(res)
	if err != nil {
		return e.BatCli.RecordErr(recErrParams, fmt.Errorf("enricher %s failing, deserializing response: %w", e.Name, err))
	}

	err = e.OOBCli.SaveDoc(ctx, params.DocIden, doc)
	if err != nil {
		return e.BatCli.RecordErr(recErrParams, fmt.Errorf("enricher %s failing, OOB save: %w", e.Name, err))
	}

	return nil
}

func (e *Enricher) deserializeFromHttpResponse(response *http.Response) (*ingest.IngestDocument, error) {
	// parse response
	responseBytes, err := io.ReadAll(response.Body)
	if err != nil {
		return nil, fmt.Errorf("error reading response body: %w", err)
	}

	// unmarshal to response
	doc := &ingest.IngestDocument{}
	err = proto.Unmarshal(responseBytes, doc)
	if err != nil {
		return nil, fmt.Errorf("error unmarshalling doc: %w", err)
	}
	return doc, nil
}

func (e *Enricher) serializeToHttpRequest(ctx context.Context, docIden DocIdentifier, doc *ingest.IngestDocument) (*http.Request, error) {
	inputBytes, err := proto.Marshal(doc)
	if err != nil {
		return nil, fmt.Errorf("error marshalling doc: %w", err)
	}

	// build request
	bodyReader := bytes.NewReader(inputBytes)
	httpReq, err := http.NewRequestWithContext(ctx, http.MethodPost, e.URL, bodyReader)
	if err != nil {
		return nil, fmt.Errorf("error creating request: %w", err)
	}

	// add headers
	InjectCtxPropsToHeaders(ctx, httpReq)
	httpReq.Header.Set("instance", docIden.Instance)
	httpReq.Header.Set("accountId", fmt.Sprintf("%v", docIden.AccountID))
	httpReq.Header.Set("projectId", fmt.Sprintf("%v", docIden.ProjectID))
	httpReq.Header.Set("Content-Type", "application/octet-stream")

	return httpReq, nil
}
