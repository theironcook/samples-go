package pipeline

import (
	"context"
	"errors"
	"fmt"

	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/ingestion-pipeline-reprocessing-service/config"
	"go.temporal.io/sdk/activity"
	"go.temporal.io/sdk/client"
	"go.temporal.io/sdk/log"
	"go.temporal.io/sdk/workflow"
)

type BatchProcessingWorkflowParams struct {
	BatchID string
	Indexer IndexerWorkflowParams
}

func (p *BatchProcessingWorkflowParams) Validate() error {
	if p.BatchID == "" {
		return errors.New("BatchID is the empty string")
	}
	if p.Indexer.BatchID == "" {
		p.Indexer.BatchID = p.BatchID
	}
	if p.BatchID != p.Indexer.BatchID {
		return fmt.Errorf("BatchID (%s) needs to match the Indexer.BatchID (%s) if both are specified", p.BatchID, p.Indexer.BatchID)
	}
	return p.Indexer.Validate()
}

type BatchProcessingWorkflowResult struct {
	UpdateProgressResult UpdateProgressResult
}

// BatchProcessingWorkflow is the main workflow that handles batch processing.
// it first indexes records and generates a batch for those records using the IndexerRecords workflow
// it then triggers a reprocessing workflow for each unprocessed record in the batch
func BatchProcessingWorkflow(wfctx workflow.Context, params BatchProcessingWorkflowParams) (BatchProcessingWorkflowResult, error) {
	logger := log.With(workflow.GetLogger(wfctx), "params", params)
	logger.Debug("started")
	defer logger.Debug("completed")

	err := params.Validate()
	if err != nil {
		logger.Error(fmt.Errorf("invalid params: %w", err).Error())
		return BatchProcessingWorkflowResult{}, err
	}

	// Create the batch table
	var activities *BatchActivities
	batchCtx := config.AppConfig.BatchWorkflow.BatchActOptCfg.ToWFCtx(wfctx)
	if err := workflow.ExecuteActivity(batchCtx, activities.CreateBatch, CreateBatchParams{BatchID: params.BatchID}).Get(batchCtx, nil); err != nil {
		err = fmt.Errorf("failed to execute the create batch activity: %w", err)
		logger.Error(err.Error())
		return BatchProcessingWorkflowResult{}, err
	}

	// Fetch all records to process via the Indexer
	indexerCtx := workflow.WithChildOptions(wfctx, workflow.ChildWorkflowOptions{
		WorkflowID:            fmt.Sprintf("batch-%v-indexer", params.BatchID),
		WorkflowIDReusePolicy: config.AppConfig.IndexerWorkflow.WorkflowIDReusePolicy,
	})
	var indexerResult IndexerWorkflowResult
	// Block until the child workflow finishes. Postgres caches table results at the begining of a query and is not updated mid pagination
	err = workflow.ExecuteChildWorkflow(indexerCtx, IndexerWorkflow, params.Indexer).Get(indexerCtx, &indexerResult)
	if err != nil {
		err = fmt.Errorf("failed to execute the indexer workflow: %w", err)
		logger.Error(err.Error())
		return BatchProcessingWorkflowResult{}, err
	}

	// Trigger a reprocessing workflow for all unprocessed records in the batch
	triggerProcessingCtx := config.AppConfig.BatchWorkflow.TriggerProcessingActOptCfg.ToWFCtx(wfctx)
	triggerProcessingParams := TriggerRecordProcessingParams{
		BatchID:            params.BatchID,
		ProjectID:          params.Indexer.ProjectID,
		ContentProviderURL: params.Indexer.ContentProviderURL,
	}
	triggerProcessingResult := TriggerRecordProcessingResult{}
	err = workflow.ExecuteActivity(triggerProcessingCtx, activities.TriggerRecordProcessing, triggerProcessingParams).Get(triggerProcessingCtx, &triggerProcessingResult)
	if err != nil {
		err = fmt.Errorf("failed to execute the trigger record processing activity: %w", err)
		logger.Error(err.Error())
		return BatchProcessingWorkflowResult{}, err
	}

	// Loop to periodically check progress
	var result UpdateProgressResult
	for {

		err := workflow.Sleep(wfctx, config.AppConfig.BatchWorkflow.BatchPollDelay)
		if err != nil {
			return BatchProcessingWorkflowResult{}, err
		}

		err = workflow.ExecuteActivity(batchCtx, (*BatchActivities).UpdateProgress, UpdateProgressParams{BatchID: params.Indexer.BatchID}).Get(batchCtx, &result)
		if err != nil {
			logger.Error(fmt.Errorf("failed to execute the update progress activity: %w", err).Error())
		} else {
			logger.Debug("progress activity", "result", result)
			if result.InProgress == 0 {
				break
			}
		}
	}

	// Bart todo - talk with Ramy - I'm hoping to keep the tables around for a while for debugging purposes
	// Cleanup after processing is complete
	// err = workflow.ExecuteActivity(wfctx, ac.Cleanup, request.BatchID).Get(wfctx, nil)

	return BatchProcessingWorkflowResult{UpdateProgressResult: result}, err
}

type BatchActivities struct {
	TemCli client.Client
	BatCli BatchClient
}

type CreateBatchParams struct {
	BatchID string
}

func (a *BatchActivities) CreateBatch(ctx context.Context, params CreateBatchParams) (Batch, error) {
	logger := log.With(activity.GetLogger(ctx), "params", params)
	batch, err := a.BatCli.CreateOrGet(ctx, params.BatchID)
	if err != nil {
		err = fmt.Errorf("failed to create batch: %w", err)
		logger.Error(err.Error())
		return Batch{}, err
	}
	return batch, nil
}

type TriggerRecordProcessingParams struct {
	BatchID            string
	ProjectID          int64
	AccountID          int64
	ContentProviderURL string
}

type TriggerRecordProcessingResult struct {
	BeginUnprocessedCount int
	StartedCount          int
}

type triggerRecordProcessingHeartbeat struct {
	StartedCount int
	RecordID     string
}

// TriggerRecordProcessing triggers the processing of individual records in the batch by launching
// a new workflow for each unprocessed record.
func (a *BatchActivities) TriggerRecordProcessing(ctx context.Context, params TriggerRecordProcessingParams) (TriggerRecordProcessingResult, error) {
	logger := log.With(activity.GetLogger(ctx), "params", params)
	logger.Debug("started")
	defer logger.Debug("completed")

	batch := a.BatCli.Get(ctx, params.BatchID)

	beginUnprocessedCount, err := batch.CountUnprocessed(ctx)
	if err != nil {
		logger.Error(fmt.Errorf("failed to count unprocessed records: %w", err).Error())
		return TriggerRecordProcessingResult{}, err
	}
	logger = log.With(activity.GetLogger(ctx), "beginUnprocessedCount", beginUnprocessedCount)
	result := TriggerRecordProcessingResult{BeginUnprocessedCount: beginUnprocessedCount}

	// List all unprocessed records (note that if new records are added to the table after this invocation, they won't be processed)
	recordsIterator, err := batch.ListUnprocessed(ctx)
	if err != nil {
		logger.Error(fmt.Errorf("failed to list unprocessed records: %w", err).Error())
		return result, err
	}
	defer recordsIterator.Close()

	var transactionID, requestID string

	ctxProps := ctx.Value(PropagateKey)
	if ctxProps != nil {
		propVals := ctxProps.(PropValues)
		transactionID = propVals.TransactionID
		requestID = propVals.RequestID
	} else {
		logger.Error("failed to get context propegation values to send along to the reprocess workflow")
	}

	logger.Debug("starting the loop to execute reprocessing workflows")
	// For each unprocessed record, trigger a new workflow to process it
	for recordsIterator.Next() {
		record, err := recordsIterator.Value()
		if err != nil {
			logger.Error(fmt.Errorf("failed to get record value: %w", err).Error())
			return result, err
		}
		if err = recordsIterator.Err(); err != nil {
			logger.Error(fmt.Errorf("failure iterating over records: %w", err).Error())
			return result, err
		}

		_, err = a.TemCli.ExecuteWorkflow(
			// Generate a unique request id per workflow / doc for easier tracking
			context.WithValue(
				ctx,
				PropagateKey,
				PropValues{
					BatchID:         params.BatchID,
					TransactionID:   transactionID,
					RequestID:       newUUIDv4().String(),
					ParentRequestID: requestID,
				},
			),
			client.StartWorkflowOptions{
				TaskQueue: config.AppConfig.Temporal.ReprocessingWorkflowWorker.TaskQueue,
				ID:        fmt.Sprintf("%v-rp-%v", params.BatchID, record.RecordID),
			},
			ReprocessingWorkflow,
			ReprocessingWorkflowParams{
				BatchID: params.BatchID,
				DocIden: DocIdentifier{
					Instance:  a.convertURLToContentProvider(params.ContentProviderURL),
					AccountID: params.AccountID,
					ProjectID: params.ProjectID,
					NaturalID: record.RecordID,
				},
				ContentProviderURL: params.ContentProviderURL,
			},
		)

		if err != nil {
			err = fmt.Errorf("failed to start reprocessing workflow: %w", err)
			logger.Error(err.Error(), "RecordID", record.RecordID, "StartedCount", result.StartedCount)
			return result, err
		}

		// Don't rely on the workflow to update the status to started. It can take a long time before a worker picks up the workflow depending on saturation.
		// If there is a failure between starting a workflow and this db update, we will restart the same workflowID but this is idempotent so it's OK
		batch.UpdateStatus(ctx, record.RecordID, ProgressValues.Started)
		result.StartedCount++
		logger.Debug("started record workflow", "RecordID", record.RecordID, "StartedCount", result.StartedCount)
		activity.RecordHeartbeat(ctx, triggerRecordProcessingHeartbeat{StartedCount: result.StartedCount, RecordID: record.RecordID})
	}

	return result, nil
}

// Cleanup closes the batch and performs cleanup, including deleting the batch's table.
func (a *BatchActivities) Cleanup(ctx context.Context, batchId string) error {
	l := activity.GetLogger(ctx)
	b, err := a.BatCli.CreateOrGet(ctx, batchId)
	if err != nil {
		return err
	}
	err = b.Close(ctx)
	if err != nil {
		l.Error(err.Error())
		return err
	}
	return nil
}

type UpdateBatchRecordParams struct {
	BatchID  string
	RecordID string
	Progress RecordProgress
	LastErr  error
}

func (a *BatchActivities) UpdateBatchRecord(ctx context.Context, params UpdateBatchRecordParams) error {
	logger := log.With(activity.GetLogger(ctx), "params", params)
	batch := a.BatCli.Get(ctx, params.BatchID)

	err := batch.UpdateStatus(ctx, params.RecordID, params.Progress)
	if err != nil {
		err = fmt.Errorf("failed to update batch record status: %w", err)
		logger.Error(err.Error())
		return err
	}

	if params.LastErr != nil {
		err := batch.UpdateLastErr(ctx, params.RecordID, params.LastErr)
		if err != nil {
			err = fmt.Errorf("failed to update batch last err: %w", err)
			logger.Error(err.Error())
			return err
		}
	}

	return nil
}

func (a *BatchActivities) convertURLToContentProvider(url string) string {
	// TODO: fix the data model
	return "cmp-staging03"
}

type UpdateProgressParams struct {
	BatchID string
}
type UpdateProgressResult struct {
	State        string
	Total        int
	PendingStart int
	InProgress   int
	Failing      int
	Failed       int
	Succeeded    int
}

// UpdateProgress retrieves the current progress of the batch processing and returns the updated Progress struct.
func (a *BatchActivities) UpdateProgress(ctx context.Context, params UpdateProgressParams) (UpdateProgressResult, error) {
	logger := log.With(activity.GetLogger(ctx), "params", params)
	// Retrieve the batch statistics
	batch := a.BatCli.Get(ctx, params.BatchID)

	stats, err := batch.Stats(ctx)
	if err != nil {
		err = fmt.Errorf("failed to get progress: %w", err)
		logger.Error(err.Error())
		return UpdateProgressResult{}, err
	}

	// Create and return the updated progress
	progress := UpdateProgressResult{
		InProgress:   stats.InProgress, // Replace with actual logic
		PendingStart: stats.PendingStart,
		Failed:       stats.Failed, // Replace with actual logic
		Succeeded:    stats.Succeeded,
	}
	return progress, nil
}
