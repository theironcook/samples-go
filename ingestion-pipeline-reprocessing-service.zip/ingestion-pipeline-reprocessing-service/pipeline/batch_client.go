package pipeline

import (
	"context"
	"fmt"
	"strings"
	"sync"
	"time"

	"github.com/jackc/pgx/v4"
	"github.com/jackc/pgx/v4/pgxpool"
	"go.temporal.io/sdk/log"
)

// PProgress represents the possible states of a record within a batch.
var ProgressValues = struct {
	PendingStart RecordProgress
	Started      RecordProgress
	Failed       RecordProgress
	Succeeded    RecordProgress
}{
	Started:      "started",
	Failed:       "failed",
	Succeeded:    "succeeded",
	PendingStart: "pending_start",
}

type RecordProgress string

// BatchClient manages the connection to the database and interacts with batches of records.
type BatchClient struct {
	pool *pgxpool.Pool // Bart todo - discuss with Ramy whether this connection auto heals during a intermitent network failures
}

// NewBatchClient initializes a new Client by connecting to the database using the provided connection info.
// It returns an initialized Client or an error if the connection fails.
func NewBatchClient(ctx context.Context, connString string, connTimeout time.Duration) (BatchClient, error) {
	cfg, err := pgxpool.ParseConfig(connString)
	if err != nil {
		return BatchClient{}, fmt.Errorf("error parsing connection string: %w", err)
	}
	cfg.ConnConfig.ConnectTimeout = connTimeout

	pool, err := pgxpool.ConnectConfig(ctx, cfg)
	if err != nil {
		return BatchClient{}, fmt.Errorf("error connecting to database: %w", err)
	}
	return BatchClient{pool: pool}, nil
}

func (c *BatchClient) Close() {
	c.pool.Close()
}

// CreateOrGet creates a new batch if it doesn't exist or retrieves an existing one.
// It returns the initialized Batch or an error if table creation fails.
func (c *BatchClient) CreateOrGet(ctx context.Context, batchId string) (Batch, error) {
	batch := Batch{pool: c.pool, batchTable: fmt.Sprintf("batch_%s", batchId)}
	return batch, batch.createTable(ctx)
}

func (c *BatchClient) Get(ctx context.Context, batchId string) Batch {
	return Batch{pool: c.pool, batchTable: fmt.Sprintf("batch_%s", batchId)}
}

type RecordErrParams struct {
	ctx     context.Context
	batchID string
	docID   string
	logger  log.Logger
}

// Reusable way to log and update batch errs
func (c *BatchClient) RecordErr(params RecordErrParams, err error) error {
	batch := c.Get(params.ctx, params.batchID)
	updateErr := batch.UpdateLastErr(params.ctx, params.docID, err)

	if updateErr != nil {
		err = fmt.Errorf("%w: error updating batch last error: %w", err, updateErr)
	}

	params.logger.Error(err.Error())
	return err
}

// Batch represents a batch of records and the various state manipulations that can be performed.
type Batch struct {
	pool       *pgxpool.Pool
	batchTable string
}

func (b *Batch) CountUnprocessed(ctx context.Context) (int, error) {
	sqlQuery := fmt.Sprintf("SELECT COUNT(*) FROM cmp_batch.%s WHERE progress='pending_start'", b.batchTable)
	rows, err := b.pool.Query(ctx, sqlQuery)

	if err != nil {
		return 0, fmt.Errorf("error counting unprocessed while executing query: %w", err)
	}
	defer rows.Close()

	var count int
	rows.Next()
	if err := rows.Scan(&count); err != nil {
		return 0, fmt.Errorf("error counting unprocessed while scanning rows: %w", err)
	}

	if err := rows.Err(); err != nil {
		return 0, fmt.Errorf("error counting unprocessed while checking row errors: %w", err)
	}
	return count, nil
}

func (b *Batch) CMPSaveFailCount(ctx context.Context) (int, error) {
	sqlQuery := fmt.Sprintf("SELECT COUNT(*) FROM cmp_batch.%s WHERE cmp_save_fail_count>0 AND progress='%s'", b.batchTable, ProgressValues.Started)
	rows, err := b.pool.Query(ctx, sqlQuery)

	if err != nil {
		return 0, fmt.Errorf("error saving CMP fail count while executing query: %w", err)
	}
	defer rows.Close()

	var count int
	rows.Next()
	if err := rows.Scan(&count); err != nil {
		return 0, fmt.Errorf("error saving CMP fail count while scanning rows: %w", err)
	}

	if err := rows.Err(); err != nil {
		return 0, fmt.Errorf("error saving CMP fail count while checking row errors: %w", err)
	}
	return count, nil
}

// AddRecords inserts a list of record IDs into the batch's database table.
// It executes the insertion in a single transaction.
// Returns an error if the transaction fails.
// The operation is idempotent as inserting the same records DOES NOTHING
func (b *Batch) AddRecords(ctx context.Context, recordIds []string, prefix string) (err error) {
	// Start a transaction
	tx, err := b.pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("error adding records to batch while starting a transaction: %w", err)
	}

	// Defer to rollback the transaction if an error occurs
	defer func() {
		if err != nil {
			tx.Rollback(ctx)
		}
	}()
	// Prepare placeholder string and arguments array
	placeholders := make([]string, 0, len(recordIds))
	args := make([]interface{}, len(recordIds))
	for i, id := range recordIds {
		placeholders = append(placeholders, fmt.Sprintf("($%d, '%v')", i+1, prefix))
		args[i] = id
	}

	// Generate the SQL statement using the placeholders
	valuesPart := strings.Join(placeholders, ",")
	sqlInsert := fmt.Sprintf("INSERT INTO cmp_batch.%s (record_id, search_prefix) VALUES %s ON CONFLICT (record_id) DO NOTHING;", b.batchTable, valuesPart)

	// Insert the records into the batch table
	_, err = tx.Exec(ctx, sqlInsert, args...)
	if err != nil {
		return fmt.Errorf("error adding records to batch while executing query: %w", err)
	}

	// Commit the transaction
	return tx.Commit(ctx)
}

// UpdateStatus updates the progress status of a specific record in the batch.
// It updates the record identified by recordId with the given progress state.
// Returns an error if the transaction fails.
func (b *Batch) UpdateStatus(ctx context.Context, recordId string, progress RecordProgress) (err error) {
	tx, err := b.pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("error updating batch status while starting transaction: %w", err)
	}

	defer func() {
		if err != nil {
			tx.Rollback(ctx)
		}
	}()

	// Update the record progress
	sqlUpdate := fmt.Sprintf("UPDATE cmp_batch.%s SET progress = $1 WHERE record_id = $2", b.batchTable)
	if _, err = tx.Exec(ctx, sqlUpdate, string(progress), recordId); err != nil {
		return fmt.Errorf("error updating batch status while executing query: %w", err)
	}
	return tx.Commit(ctx)
}

func (b *Batch) UpdateLastErr(ctx context.Context, recordId string, lastErr error) (err error) {
	tx, err := b.pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("error updating batch last error while starting transaction: %w", err)
	}

	defer func() {
		if err != nil {
			tx.Rollback(ctx)
		}
	}()

	// Update the record progress
	sqlUpdate := fmt.Sprintf("UPDATE cmp_batch.%s SET last_err = $1 WHERE record_id = $2", b.batchTable)
	if _, err = tx.Exec(ctx, sqlUpdate, lastErr.Error(), recordId); err != nil {
		return fmt.Errorf("error updating batch last error while executing query: %w", err)
	}
	return tx.Commit(ctx)
}

func (b *Batch) IncCMPSaveFailCount(ctx context.Context, recordId string) (newCount int, err error) {
	tx, err := b.pool.Begin(ctx)
	if err != nil {
		return 0, fmt.Errorf("error updating batch CMP save fail count while starting transaction: %w", err)
	}

	defer func() {
		if err != nil {
			tx.Rollback(ctx)
		}
	}()

	sqlUpdate := fmt.Sprintf("UPDATE cmp_batch.%s SET cmp_save_fail_count = cmp_save_fail_count + 1 WHERE record_id = '%s' RETURNING cmp_save_fail_count", b.batchTable, recordId)

	err = tx.QueryRow(ctx, sqlUpdate).Scan(&newCount)
	if err != nil {
		return 0, fmt.Errorf("error updating batch CMP save fail count while executing query: %w", err)
	}

	if err = tx.Commit(ctx); err != nil {
		return 0, fmt.Errorf("error updating batch CMP save fail count while commiting transaction: %w", err)
	}

	return newCount, nil
}

// ListUnprocessed returns an iterator to iterate through records that have not yet been processed.
// Returns a recordIterator or an error if the query fails.
func (b *Batch) ListUnprocessed(ctx context.Context) (recordIterator, error) {
	sqlQuery := fmt.Sprintf("SELECT record_id, progress FROM cmp_batch.%s WHERE progress='pending_start'", b.batchTable)
	rows, err := b.pool.Query(ctx, sqlQuery)
	if err != nil {
		return recordIterator{}, fmt.Errorf("error listing unprocessed records while executing query: %w", err)
	}
	return recordIterator{rows}, nil
}

// Stats retrieves statistics on the current batch, returning the counts of records in each progress state.
// It returns a Stats struct or an error if the query fails.
func (b *Batch) Stats(ctx context.Context) (Stats, error) {
	var stats Stats

	// Query to fetch counts of records grouped by their progress state
	sqlQuery := fmt.Sprintf("SELECT progress, COUNT(*) FROM cmp_batch.%s GROUP BY progress", b.batchTable)

	rows, err := b.pool.Query(ctx, sqlQuery)
	if err != nil {
		return stats, fmt.Errorf("error fetching stats while starting transaction: %w", err)
	}
	defer rows.Close()

	// Populate stats by scanning the query results
	for rows.Next() {
		var progress RecordProgress
		var count int
		if err := rows.Scan(&progress, &count); err != nil {
			return stats, fmt.Errorf("error fetching stats while scanning row: %w", err)
		}

		switch progress {
		case ProgressValues.Started:
			stats.InProgress = count
		case ProgressValues.Failed:
			stats.Failed = count
		case ProgressValues.PendingStart:
			stats.PendingStart = count
		case ProgressValues.Succeeded:
			stats.Succeeded = count
		}
	}

	// Check if there were any errors during the iteration of rows
	if err := rows.Err(); err != nil {
		return stats, fmt.Errorf("error fetching stats while reading row errors: %w", err)
	}

	return stats, nil
}

// Close deletes all state of the batch
// Internally this drops all tables and references to batch
// This operation is executed in a transaction, which is rolled back if it fails.
// Returns an error if the transaction fails.
func (b *Batch) Close(ctx context.Context) error {
	tx, err := b.pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("error closing batch (%v) while starting transaction: %w", b.batchTable, err)
	}

	defer func() {
		if err != nil {
			tx.Rollback(ctx)
		}
	}()

	// Drop the batch table
	sqlDropTable := fmt.Sprintf("DROP TABLE IF EXISTS cmp_batch.%s", b.batchTable)
	_, err = tx.Exec(ctx, sqlDropTable)
	if err != nil {
		return fmt.Errorf("error closing batch (%v) while executing query: %w", b.batchTable, err)
	}
	err = tx.Commit(ctx)
	if err != nil {
		return fmt.Errorf("error closing batch (%v) while commiting transaction: %w", b.batchTable, err)
	}
	return nil
}

// It's problematic when many concurrent Activities execute this function
var createTableMutex sync.Mutex

// createTable creates the batch table if it doesn't already exist.
// It also creates an index on the 'progress' column to optimize status-based queries.
func (b *Batch) createTable(ctx context.Context) error {
	createTableMutex.Lock()
	defer createTableMutex.Unlock()
	// Start a transaction
	tx, err := b.pool.Begin(ctx)

	if err != nil {
		return fmt.Errorf("error creating batch (%v) while starting transaction: %w", b.batchTable, err)
	}

	// Defer to rollback the transaction if it isn't committed by the end of the function
	// This will only roll back if the commit hasn't been called
	defer func() {
		if err != nil {
			tx.Rollback(ctx)
		}
	}()

	// Create the table
	create := fmt.Sprintf(
		`CREATE TABLE IF NOT EXISTS cmp_batch.%s (
        record_id TEXT NOT NULL PRIMARY KEY,
        progress TEXT DEFAULT '%s',
		search_prefix TEXT,
		last_err TEXT,
		cmp_save_fail_count INTEGER DEFAULT 0)`,
		b.batchTable, ProgressValues.PendingStart)

	_, err = tx.Exec(ctx, create)
	if err != nil {
		return fmt.Errorf("error creating batch (%v) while executing query: %w", b.batchTable, err)
	}

	// Create index on progress column to optimize filtering on progress
	sqlIndex := fmt.Sprintf(`CREATE INDEX IF NOT EXISTS idx_progress ON cmp_batch.%s (progress)`, b.batchTable)
	_, err = tx.Exec(ctx, sqlIndex)
	if err != nil {
		return fmt.Errorf("error creating batch (%v) while executing index query: %w", b.batchTable, err)
	}
	// Commit the transaction
	return tx.Commit(ctx)
}

// Record represents an individual record in a batch, including its ID and progress state.
type Record struct {
	RecordID  string
	PProgress string
}

// recordIterator allows iteration over a list of records fetched from the database.
// iterator is preferred over list because a batch may produce millions of records, possibly loading
// gigabytes into memory
type recordIterator struct {
	rows pgx.Rows
}

// Err returns any errors encountered during the iteration of records.
func (r *recordIterator) Err() error {
	return r.rows.Err()
}

// Close closes the iterator and releases any resources associated with the database query.
func (r *recordIterator) Close() {
	r.rows.Close()
}

// Next advances the iterator to the next record, returning false if no more records are available.
func (r *recordIterator) Next() bool {
	return r.rows.Next()
}

// Value retrieves the current record from the iterator.
// It returns a pointer to a Record or an error if the scan operation fails.
func (r *recordIterator) Value() (*Record, error) {
	var recordID, progress string
	err := r.rows.Scan(&recordID, &progress)
	if err != nil {
		return nil, err
	}
	return &Record{
		RecordID:  recordID,
		PProgress: progress,
	}, nil
}

// Stats holds the counts of records in different progress states within a batch.
type Stats struct {
	InProgress   int // Number of records currently in progress
	Failed       int // Number of records that failed processing
	Succeeded    int // Number of records successfully processed
	PendingStart int // Number of records that haven't started processing
}
