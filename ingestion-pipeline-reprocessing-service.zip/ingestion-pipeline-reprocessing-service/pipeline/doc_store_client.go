package pipeline

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"time"

	"gitlab-app.eng.qops.net/golang/jwt"
	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/protobuf-definitions/pkg/services/ingest"
	"go.temporal.io/sdk/activity"
	"go.temporal.io/sdk/log"
	"google.golang.org/protobuf/proto"
)

const (
	jwtTimeout = 5 * time.Minute
)

type DiscoverDocumentStoreClient struct {
	HTTPCli http.Client
	JWTKey  string
	URL     string
}

func (c *DiscoverDocumentStoreClient) FetchDoc(ctx context.Context, docIden DocIdentifier) (*ingest.IngestDocument, error) {
	logger := log.With(activity.GetLogger(ctx), "docIden", docIden)
	logger.Debug("started")
	defer logger.Debug("completed")

	// signer is created once and can be used repeatedly to sign HTTP requests
	signer := &jwt.Signer{
		Key: []byte(c.JWTKey),
		DefaultClaims: jwt.Claims{
			Issuer: "qualtrics",
		},
		Timeout: jwtTimeout,
	}

	// claims will be used for this specific request, overwriting the signer's default claims
	claims := jwt.Claims{
		Audience: "discover-document-store",
		Issuer:   "data-pipelines",
		Custom: map[string]interface{}{
			"projectId":  fmt.Sprintf("%d", docIden.ProjectID),
			"accountId":  fmt.Sprintf("%d", docIden.AccountID),
			"cmpId":      docIden.Instance,
			"instanceId": docIden.Instance,
			"exp":        time.Now().Add(jwtTimeout).Unix(),
		},
	}
	url := fmt.Sprintf("%s/%s/projects/%v/documents-by-natural-id/%s", c.URL, docIden.Instance, docIden.ProjectID, docIden.NaturalID)
	logger.Info("generated the doc store url", "url", url)
	// create a request to sign
	r, err := http.NewRequest(http.MethodGet, url, nil)
	if err != nil {
		return nil, fmt.Errorf("error fetching doc (docstore) while creating request: %w", err)
	}

	// sign request with given claims
	err = signer.Sign(r, claims)
	if err != nil {
		return nil, fmt.Errorf("error fetching doc (docstore) while signing JWT: %w", err)
	}

	if len(r.Header["X-Jwt"]) > 0 {
		r.Header.Add("Authorization", "Bearer "+r.Header["X-Jwt"][0])
	}
	r.Header.Del("X-JWT")
	r.Header.Del("X-Jwt")
	InjectCtxPropsToHeaders(ctx, r)

	resp, err := c.HTTPCli.Do(r)
	if err != nil {
		return nil, fmt.Errorf("error fetching doc (docstore) while sending request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		err = fmt.Errorf("error fetching doc (docstore), expected response (%v) but received (%v)", http.StatusOK, resp.StatusCode)

		bodyBytes, readBodyErr := io.ReadAll(resp.Body)

		if readBodyErr != nil {
			err = fmt.Errorf("%w: error reading response body: %w", err, readBodyErr)
		} else {
			err = fmt.Errorf("%w: error response: %s", err, string(bodyBytes))
		}

		return nil, err
	}

	responseBytes, _ := io.ReadAll(resp.Body)
	doc := &ingest.IngestDocument{}
	err = proto.Unmarshal(responseBytes, doc)
	if err != nil {
		return nil, fmt.Errorf("error fetching doc (docstore) while reading response body: %w", err)
	}

	return doc, nil
}
