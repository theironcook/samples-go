package pipeline

import (
	"context"
	"net/http"

	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/ingestion-pipeline-reprocessing-service/config"
	"go.temporal.io/sdk/client"
	"go.temporal.io/sdk/interceptor"
	"go.temporal.io/sdk/worker"
	"go.temporal.io/sdk/workflow"
)

type NewWorkerParams struct {
	OOBCli OOBClient
	//DocStoreCli FakeOOBASDocStoreDELETEME
	DocStoreCli DiscoverDocumentStoreClient
	TemCli      client.Client
	BatCli      BatchClient
	ExpApiCli   ExportApiClient
	CMPCli      CMPClient
}

func NewWorker(appConfig config.Config, params NewWorkerParams) (worker.Worker, error) {
	// Add any default logging values you want to include for ALL logging statements
	loggingInterceptors := []interceptor.WorkerInterceptor{NewWorkerInterceptor(InterceptorOptions{
		GetExtraLogTagsForWorkflow: func(ctx workflow.Context) []interface{} {
			return []interface{}{}
		},
		GetExtraLogTagsForActivity: func(ctx context.Context) []interface{} {
			return []interface{}{}
		},
	})}

	options := worker.Options{
		DisableRegistrationAliasing:      true,
		Interceptors:                     loggingInterceptors,
		MaxConcurrentWorkflowTaskPollers: config.AppConfig.Temporal.Worker.MaxConcurrentWorkflowTaskPollers,
		MaxConcurrentActivityTaskPollers: config.AppConfig.Temporal.Worker.MaxConcurrentActivityTaskPollers,
	}

	w := worker.New(params.TemCli, appConfig.Temporal.Worker.DefaultTaskQueue, options)

	w.RegisterWorkflow(BatchProcessingWorkflow)
	w.RegisterWorkflow(IndexerWorkflow)

	w.RegisterActivity(&IndexerActivities{
		OOBCli: params.OOBCli,
		ExpCli: params.ExpApiCli,
		BatCli: params.BatCli,
	})

	w.RegisterActivity(&BatchActivities{
		BatCli: params.BatCli,
		TemCli: params.TemCli,
	})

	go w.Run(worker.InterruptCh())

	return w, nil
}

func NewReprocessingWorkflowWorker(appConfig config.Config, params NewWorkerParams) (worker.Worker, error) {
	// Add any default logging values you want to include for ALL logging statements
	loggingInterceptors := []interceptor.WorkerInterceptor{NewWorkerInterceptor(InterceptorOptions{
		GetExtraLogTagsForWorkflow: func(ctx workflow.Context) []interface{} {
			return []interface{}{}
		},
		GetExtraLogTagsForActivity: func(ctx context.Context) []interface{} {
			return []interface{}{}
		},
	})}

	options := worker.Options{
		TaskQueueActivitiesPerSecond:     config.AppConfig.Temporal.ReprocessingWorkflowWorker.TaskQueueActivitiesPerSecond,
		DisableRegistrationAliasing:      true,
		Interceptors:                     loggingInterceptors,
		MaxConcurrentWorkflowTaskPollers: config.AppConfig.Temporal.ReprocessingWorkflowWorker.MaxConcurrentWorkflowTaskPollers,
		MaxConcurrentActivityTaskPollers: config.AppConfig.Temporal.ReprocessingWorkflowWorker.MaxConcurrentActivityTaskPollers,
	}

	w := worker.New(params.TemCli, appConfig.Temporal.ReprocessingWorkflowWorker.TaskQueue, options)

	w.RegisterWorkflow(ReprocessingWorkflow)

	w.RegisterActivity(&BatchActivities{
		BatCli: params.BatCli,
		TemCli: params.TemCli,
	})

	w.RegisterActivity(&ScrubActivities{
		DiscoverDocStore: params.DocStoreCli,
		OOBClient:        params.OOBCli,
		BatchClient:      params.BatCli,
	})

	w.RegisterActivity(&NLPFacadeActivity{
		enricher: Enricher{
			Name:    "NLP Facade",
			URL:     appConfig.ReprocessingWorkflow.NLPFacade.URL,
			HTTPCli: http.Client{Timeout: appConfig.ReprocessingWorkflow.NLPFacade.HTTPTimeout},
			OOBCli:  params.OOBCli,
			BatCli:  params.BatCli,
		},
	})

	w.RegisterActivity(&DerivedAttributeActivity{
		enricher: Enricher{
			Name:    "Derived Attribute",
			URL:     appConfig.ReprocessingWorkflow.DerivedAttribute.URL,
			HTTPCli: http.Client{Timeout: appConfig.ReprocessingWorkflow.DerivedAttribute.HTTPTimeout},
			OOBCli:  params.OOBCli,
			BatCli:  params.BatCli,
		},
	})
	w.RegisterActivity(&SentimentActivity{
		enricher: Enricher{
			Name:    "Sentiment",
			URL:     appConfig.ReprocessingWorkflow.Sentiment.URL,
			HTTPCli: http.Client{Timeout: appConfig.ReprocessingWorkflow.Sentiment.HTTPTimeout},
			OOBCli:  params.OOBCli,
			BatCli:  params.BatCli,
		},
	})

	w.RegisterActivity(&ClassificationActivity{
		enricher: Enricher{
			Name:    "Classification",
			URL:     appConfig.ReprocessingWorkflow.Classification.URL,
			HTTPCli: http.Client{Timeout: appConfig.ReprocessingWorkflow.Classification.HTTPTimeout},
			OOBCli:  params.OOBCli,
			BatCli:  params.BatCli,
		},
	})
	w.RegisterActivity(&IntelligentScoringActivity{
		enricher: Enricher{
			Name:    "Intelligent Scoring",
			URL:     appConfig.ReprocessingWorkflow.IntelligentScoring.URL,
			HTTPCli: http.Client{Timeout: appConfig.ReprocessingWorkflow.IntelligentScoring.HTTPTimeout},
			OOBCli:  params.OOBCli,
			BatCli:  params.BatCli,
		},
	})

	w.RegisterActivity(&CMPActivities{
		OOBClient:   params.OOBCli,
		CMPClient:   params.CMPCli,
		BatchClient: params.BatCli,
	})

	w.RegisterActivity(&PerfMetricsActivities{})

	go w.Run(worker.InterruptCh())

	return w, nil
}
