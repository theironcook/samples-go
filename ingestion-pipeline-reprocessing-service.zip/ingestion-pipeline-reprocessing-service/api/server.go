package api

import (
	"net/http"

	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/ingestion-pipeline-reprocessing-service/config"
	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/ingestion-pipeline-reprocessing-service/pipeline"
	"go.temporal.io/sdk/client"
)

func NewServeMux(appConfig config.Config, temporalClient client.Client, batchClient pipeline.BatchClient) http.Handler {
	mux := http.NewServeMux()
	// Bart todo - add JWT auth middleware
	mux.Handle("/doc",
		NewReprocessHandler(
			appConfig,
			temporalClient,
			batchClient,
		),
	)
	mux.Handle("/batch",
		NewBatchHandler(appConfig, temporalClient),
	)
	return mux
}
