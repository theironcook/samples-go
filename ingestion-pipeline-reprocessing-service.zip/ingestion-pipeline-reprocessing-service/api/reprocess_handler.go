package api

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"net/http"

	"gitlab-app.eng.qops.net/golang/transaction"
	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/ingestion-pipeline-reprocessing-service/config"
	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/ingestion-pipeline-reprocessing-service/pipeline"
	"go.temporal.io/sdk/client"
)

type reprocessHandler struct {
	TemporalClient       client.Client
	StartWorkflowOptions client.StartWorkflowOptions
	BatchClient          pipeline.BatchClient
}

func NewReprocessHandler(appConfig config.Config, temporalClient client.Client, batchClient pipeline.BatchClient) http.Handler {
	return reprocessHandler{
		TemporalClient: temporalClient,
		StartWorkflowOptions: client.StartWorkflowOptions{
			TaskQueue: appConfig.Temporal.ReprocessingWorkflowWorker.TaskQueue,
		},
		BatchClient: batchClient,
	}
}

func (h reprocessHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	body, err := io.ReadAll(r.Body)
	if err != nil {
		http.Error(w, fmt.Sprintf("failed to read http body: %s", err), http.StatusBadRequest)
		return
	}

	if len(body) == 0 {
		http.Error(w, "failed to read http body: no body passed", http.StatusBadRequest)
		return
	}

	params := pipeline.ReprocessingWorkflowParams{}
	err = json.Unmarshal(body, &params)
	if err != nil {
		http.Error(w, fmt.Sprintf("failed to unmarshal params: %s", err), http.StatusBadRequest)
		return
	}

	if err = params.DocIden.Validate(); err != nil {
		http.Error(w, fmt.Sprintf("invalid document identifier: %s", err), http.StatusBadRequest)
		return
	}

	if params.BatchID == "" {
		params.BatchID = randString(5)
		slog.Info("no batch id was passed. generated a random one", "BatchID", params.BatchID)
	}

	resp, err := h.process(r.Context(), params)
	if err != nil {
		http.Error(w, fmt.Sprintf("failed to process the request: %s", err.Error()), http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(resp)
}

type processDocResult struct {
	BatchID    string
	WorkflowID string
	RunID      string
}

func (h reprocessHandler) process(ctx context.Context, params pipeline.ReprocessingWorkflowParams) (processDocResult, error) {
	// Pass context from http request (via Qualtrics app code) to the workflow context which is propegated via Temporal headers
	if trans, ok := transaction.FromContext(ctx); ok {
		ctx = context.WithValue(ctx, pipeline.PropagateKey, pipeline.PropValues{
			BatchID:         params.BatchID,
			TransactionID:   trans.TransactionID,
			RequestID:       trans.RequestID,
			ParentRequestID: trans.ParentRequestID,
		})
	} else {
		slog.Warn("no transaction information found in context")
	}

	// Normally a batch workflow creates the batch table entries but we must create that here
	_, err := h.BatchClient.CreateOrGet(ctx, params.BatchID)

	if err != nil {
		err = fmt.Errorf("failed to create the batch: %w", err)
		slog.Error(err.Error())
		return processDocResult{}, err
	}

	wr, err := h.TemporalClient.ExecuteWorkflow(ctx,
		h.StartWorkflowOptions,
		pipeline.ReprocessingWorkflow,
		params)
	if err != nil {
		err = fmt.Errorf("failed to execute the workflow: %w", err)
		slog.Error(err.Error())
		return processDocResult{}, err
	}

	slog.Info("started workflow", "BatchID", params.BatchID, "WorkflowID", wr.GetID(), "RunID", wr.GetRunID())
	return processDocResult{BatchID: params.BatchID, WorkflowID: wr.GetID(), RunID: wr.GetRunID()}, nil
}
