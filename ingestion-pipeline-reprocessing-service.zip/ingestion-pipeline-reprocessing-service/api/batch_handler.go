package api

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"math/rand"
	"net/http"

	"gitlab-app.eng.qops.net/golang/transaction"
	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/ingestion-pipeline-reprocessing-service/config"
	"gitlab-app.eng.qops.net/xm-discover/discover-platform-group/discover-data-pipelines/ingestion-pipeline-reprocessing-service/pipeline"
	"go.temporal.io/sdk/client"
	"go.temporal.io/sdk/log"
)

type batchHandler struct {
	temporalClient client.Client
	appConfig      config.Config
}

func NewBatchHandler(appConfig config.Config, temporalClient client.Client) http.Handler {
	return batchHandler{
		temporalClient: temporalClient,
		appConfig:      appConfig,
	}
}

func (h batchHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	body, err := io.ReadAll(r.Body)
	if err != nil {
		http.Error(w, fmt.Errorf("failed to read the request body: %w", err).Error(), http.StatusBadRequest)
		return
	}

	if len(body) == 0 {
		http.Error(w, "failed to read request body. no body was passed", http.StatusBadRequest)
		return
	}

	params := pipeline.BatchProcessingWorkflowParams{}
	err = json.Unmarshal(body, &params)
	if err != nil {
		http.Error(w, fmt.Errorf("failed to parse the request body: %w", err).Error(), http.StatusBadRequest)
		return
	}
	if params.BatchID == "" {
		params.BatchID = randString(5)
		slog.Info("no batch id was passed. generated a random one", "BatchID", params.Indexer.BatchID)
	}

	if err := params.Validate(); err != nil {
		errStr := fmt.Errorf("invalid body sent: %w", err).Error()
		slog.Error(errStr)
		http.Error(w, errStr, http.StatusBadRequest)
		return
	}

	resp, err := h.process(r.Context(), params)
	if err != nil {
		http.Error(w, fmt.Errorf("processing request: %w", err).Error(), http.StatusInternalServerError)
		return
	}

	// set to 202 for job accepted
	w.WriteHeader(http.StatusAccepted)
	fmt.Fprintln(w, resp)
}

func (h batchHandler) process(ctx context.Context, params pipeline.BatchProcessingWorkflowParams) (string, error) {
	logger := log.With(slog.Default(), "params", params)
	// Pass context from http request (via Qualtrics app code) to the workflow context which is propegated via Temporal headers
	if trans, ok := transaction.FromContext(ctx); ok {
		ctx = context.WithValue(
			ctx,
			pipeline.PropagateKey,
			pipeline.PropValues{
				BatchID:         params.Indexer.BatchID,
				TransactionID:   trans.TransactionID,
				RequestID:       trans.RequestID,
				ParentRequestID: trans.ParentRequestID,
			},
		)
	} else {
		logger.Warn("no transaction information found in the context")
	}

	wr, err := h.temporalClient.ExecuteWorkflow(
		ctx,
		client.StartWorkflowOptions{
			ID:                    fmt.Sprintf("batch-%s", params.Indexer.BatchID),
			WorkflowIDReusePolicy: config.AppConfig.BatchWorkflow.WorkflowIDReusePolicy,
			TaskQueue:             h.appConfig.Temporal.Worker.DefaultTaskQueue,
			RetryPolicy:           config.AppConfig.BatchWorkflow.RetryPolCfg.ToRetryPolicy(),
		},
		pipeline.BatchProcessingWorkflow,
		params,
	)
	if err != nil {
		logger.Error(fmt.Errorf("unable to execute workflow: %w", err).Error())
		return "", err
	}

	logger.Info("started batch processing workflow", "WorkflowID", wr.GetID(), "RunID", wr.GetRunID())
	return wr.GetID(), nil
}

func randString(length int) string {
	const letters = "abcdefghijklmnopqrstuvwxyz"
	randomString := make([]byte, length)
	for i := range randomString {
		randomString[i] = letters[rand.Intn(len(letters))]
	}
	return string(randomString)
}
