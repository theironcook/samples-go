# protobuf-definitions

## go

To use protobuf-definitions in your Go projects, add the following lines to your root-level Makefile.

Specify the following at the top of your Makefile

```cmake
PROTO_RELEASE_VERSION=1.1.1
PB_DIR_NAME=protobuf-definitions-${PROTO_RELEASE_VERSION}
GO_MODULE_NAME=<YOUR_APPLICATION_MODULE_NAME>
```

Add the following targets to the Makefile

```cmake
get-proto-release:
  git clone -b v${PROTO_RELEASE_VERSION} --single-branch https://github.com/ClarabridgeInc/protobuf-definitions ${PB_DIR_NAME}

proto: get-proto-release
  @$(MAKE) -C ${PB_DIR_NAME} gen-go PROTO_RELEASE_VERSION=$(PROTO_RELEASE_VERSION) GO_MODULE_NAME=$(GO_MODULE_NAME)
```

Add the following to your application repo's `.gitignore` file

```bash
pb
```

Finally run,  

```bash
make proto
```

BOOM! Your auto-generated clarabridge protobuf stubs are available at `internal/pb` and all non-essential artifacts of the compilation process removed from your filesystem!

For use with the shared build pipeline for Go to specify the `proto-build` stage, refer to the following Jenkinsfile.

```groovy
#!groovy

@Library('kubernetes') _

golangBuildPipeline([
    'slackChannel': '#$SOME_CHANNEL', // slack channel for notifications
    'teamName': '$YOUR_TEAM_NAME', // your team name
    'helmChartDirectory': './helm/' // path to helm chart in your app/source repo (This does not refer to a path to the helm-charts monorepo)
]) {
    // All Protobuf compilation steps should go within a sh block
    sh """
      echo "  >  Compiling protobuf and autogenerating code..."
      make proto
    """
}

```

To compile and generate the code stubs for Go projects from the `protobuf-definitions` repo, refer to the following stage from a multi-stage Dockerfile.

```dockerfile
# -------------------------------------------------------------------
# PROTOBUF BUILD STAGE
# -------------------------------------------------------------------
FROM 799231120095.dkr.ecr.us-east-1.amazonaws.com/base/go:1.18.3 as proto-builder

WORKDIR /narrative-controller-service # change according to your needs
COPY Makefile .
RUN make proto
```

This process is maintained by Sandesh Gade (@cyberbeast / sandeshg@qualtrics.com) for Go. This process simplifies the usage of protobuf-definitions for Go *ONLY*. We are gonna have to wait until a dedicated team/individual can find the bandwidth to take ownership of the process for other programming languages. If you'd like to,

- add your proto file to the go release,
- make a team/service specific release,

consider submitting a PR with @cyberbeast as the reviewer.

### Current Version

current release version: `v1.1.1`
