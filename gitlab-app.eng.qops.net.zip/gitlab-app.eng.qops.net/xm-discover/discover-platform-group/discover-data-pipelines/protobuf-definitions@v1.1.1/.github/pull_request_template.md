Thank you for submitting a pull request to the protobuf-definitions repo.

In order to streamline the review, we ask you to ensure the following steps have been taken:

For PR submitter:
- [ ] *No protobuf fields may use `required`*. Use of `required` breaks backward compatibility and is therefore not allowed in this repository. If you believe your use case warrants `required`, contact the maintainers to discuss alternatives.
- [ ] There is a JIRA ticket associated with this PR, and it is referenced in the commit message.
- [ ] The PR title starts with CB-XXXX (or NLP-XXXX/CXS-XXXX/CSI-XXXX) where XXXX is the JIRA number you are trying to resolve. Pay particular attention to the hyphen ("-") and absence of the colon after the JIRA ticket number. Example: "CB-1666 Update the Spring dependency due to security vulnerabilities".
- [ ] All messages types and fields are properly documented.

For PR reviewer:
- [ ] All acceptance criteria above are met.

___

**Please describe your pull request here.**
