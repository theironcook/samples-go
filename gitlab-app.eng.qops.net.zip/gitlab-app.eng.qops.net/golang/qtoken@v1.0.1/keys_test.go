package qtoken_test

import (
	"bytes"
	"os"
	"testing"

	"gitlab-app.eng.qops.net/golang/qtoken"
)

func TestMustKeysFromEnv(t *testing.T) {

	envQToken := "foo"
	envQTokenRotated := "bar"
	envQTokenChecksum := "baz"

	var keys qtoken.Keys

	func() {
		defer func() {
			if r := recover(); r == nil {
				t.Errorf("should panic if %q was not set", qtoken.EnvQToken)
			}
		}()
		keys = qtoken.MustKeysFromEnv()
	}()
	os.Setenv(qtoken.EnvQToken, envQToken)

	func() {
		defer func() {
			if r := recover(); r == nil {
				t.Errorf("should panic if %q was not set", qtoken.EnvQTokenRotated)
			}
		}()
		keys = qtoken.MustKeysFromEnv()
	}()
	os.Setenv(qtoken.EnvQTokenRotated, envQTokenRotated)

	func() {
		defer func() {
			if r := recover(); r == nil {
				t.Errorf("should panic if %q was not set", qtoken.EnvQTokenChecksum)
			}
		}()
		keys = qtoken.MustKeysFromEnv()
	}()
	os.Setenv(qtoken.EnvQTokenChecksum, envQTokenChecksum)

	keys = qtoken.MustKeysFromEnv()

	if bytes.Compare(keys.Primary, []byte(envQToken)) != 0 {
		t.Errorf("error with Primary key; got %q, want %q", string(keys.Primary), envQToken)
	}
	if bytes.Compare(keys.Rotated, []byte(envQTokenRotated)) != 0 {
		t.Errorf("error with Rotated key; got %q, want %q", string(keys.Rotated), envQTokenRotated)
	}

}

const (
	tokenDeprecated = "outgoing"
	tokenNew        = "incoming"
	tokenUnknown    = "unknown"
)

func TestKeys_Name(t *testing.T) {

	type name struct {
		Desc      string
		Key, Name string
	}

	cases := []struct {
		Phase             string
		EnvQToken         string
		EnvQTokenRotated  string
		EnvQTokenChecksum string
		Names             []name
	}{
		{
			Phase:             "Phase 1",
			EnvQToken:         tokenDeprecated,
			EnvQTokenRotated:  tokenDeprecated,
			EnvQTokenChecksum: tokenDeprecated,
			Names: []name{
				{Key: tokenDeprecated, Name: "new"},
				{Key: tokenNew, Name: "invalid"},
				{Key: tokenUnknown, Name: "invalid"},
			},
		},

		{
			Phase:             "Phase 2",
			EnvQToken:         tokenDeprecated,
			EnvQTokenRotated:  tokenNew,
			EnvQTokenChecksum: tokenNew,
			Names: []name{
				{Key: tokenDeprecated, Name: "old"}, // this is the case @shayneh caught
				{Key: tokenNew, Name: "new"},
				{Key: tokenUnknown, Name: "invalid"},
			},
		},

		{
			Phase:             "Phase 3",
			EnvQToken:         tokenNew,
			EnvQTokenRotated:  tokenDeprecated,
			EnvQTokenChecksum: tokenNew,
			Names: []name{
				{Key: tokenDeprecated, Name: "old"},
				{Key: tokenNew, Name: "new"},
				{Key: tokenUnknown, Name: "invalid"},
			},
		},

		{
			Phase:             "Phase 4",
			EnvQToken:         tokenNew,
			EnvQTokenRotated:  tokenNew,
			EnvQTokenChecksum: tokenNew,
			Names: []name{
				{Key: tokenDeprecated, Name: "invalid"},
				{Key: tokenNew, Name: "new"},
				{Key: tokenUnknown, Name: "invalid"},
			},
		},
	}

	for _, c := range cases {
		t.Run(c.Phase, func(t *testing.T) {

			os.Setenv(qtoken.EnvQToken, c.EnvQToken)
			os.Setenv(qtoken.EnvQTokenRotated, c.EnvQTokenRotated)
			os.Setenv(qtoken.EnvQTokenChecksum, c.EnvQTokenChecksum)

			keys := qtoken.MustKeysFromEnv()

			for _, name := range c.Names {
				t.Run(name.Key, func(t *testing.T) {
					actual, _ := keys.Name([]byte(name.Key))

					if actual != name.Name {
						t.Errorf("error with key name; got %q, want %q", actual, name.Name)
					}
				})
			}

		})
	}
}
