// Package qtoken provides the logic for obtaining the current QToken secrets.
// Users can thereby obtain the currently-applicable secrets and discern which
// value to use for signing.
//
// Usage
//
// Fetch the current keys using the package-level getter, then use the
// contained values as follows:
//
//     keys, _ := qtoken.KeysFromEnv()
//
//     // Always use the "Primary" key for signing outbound things.
//     keyForSigning := keys.Primary
//
//     // Accept incoming things signed by either key.
//     keysForVerifying := {keys.Primary, keys.Rotated}
//
// Note that due to quirks in the spec, the two values might be identical.
//
//
// Rotation Algorithm
//
// This package implements the March 2021 QToken rotation logic.
//
// Users of this package don't need to understand the rotation logic to use the
// package, but the internals may be useful to those trying to understand its
// behavior.
//
// The March 2021 rotation scheme proceeds in 4 phases:
//
//     Phase 1
//     How things start
//         QTOKEN_ROTATED:  [old value]
//         QTOKEN:          [old value]
//         QTOKEN_CHECKSUM: [old value]
//
//     Phase 2
//     We decide we want to rotate QTOKEN, and update QTOKEN_ROTATED and  QTOKEN_CHECKSUM.
//     Services start accepting [new value] but still sign things using [old value].
//         QTOKEN_ROTATED:  [new value]
//         QTOKEN:          [old value]
//         QTOKEN_CHECKSUM: [new value]
//
//     Phase 3
//     We update QTOKEN to have the [new value]. Service still accept [old value]
//     but now things start being signed with [new value].
//         QTOKEN_ROTATED:  [old value]
//         QTOKEN:          [new value]
//         QTOKEN_CHECKSUM: [new value]
//
//     Phase 4
//     Finally, we update QTOKEN_ROTATED to have [new value] too, so that
//     only the [new value] is used and accepted by anyone.
//         QTOKEN_ROTATED:  [new value]
//         QTOKEN:          [new value]
//         QTOKEN_CHECKSUM: [new value]
//
// During Phase 1, the observed behavior of this package should be:
//
//     - keys.Name("[old value]") == "new"
//     - keys.Name("[new value]") == "invalid"
//     - keys.Name("[anything else]") == "invalid"
//
// (This may seem counterintuitive at first, but it's just a reflection of the
// fact that the ONLY valid key is the old one. It may be clearer why it's
// reported as "new" by noting that Phase 1 for a given rotation cycle is
// identical to Phase 4 of the last rotation cycle.)
//
// During Phases 2 and 3, the observed behavior of this package should be:
//
//     - keys.Name("[old value]") == "old"
//     - keys.Name("[new value]") == "new"
//     - keys.Name("[anything else]") == "invalid"
//
// During Phase 4, the observed behavior of this package should be:
//
//     - keys.Name("[old value]") == "invalid"
//     - keys.Name("[new value]") == "new"
//     - keys.Name("[anything else]") == "invalid"
package qtoken
