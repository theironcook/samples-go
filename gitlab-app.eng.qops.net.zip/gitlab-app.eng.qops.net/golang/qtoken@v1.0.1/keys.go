package qtoken

import (
	"bytes"
	"fmt"
	"os"
)

const (
	EnvQToken         = "QTOKEN"
	EnvQTokenRotated  = "QTOKEN_ROTATED"
	EnvQTokenChecksum = "QTOKEN_CHECKSUM"
)

// Keys should be a read-only struct. You should always get it from KeysFromEnv().
type Keys struct {
	Primary []byte
	Rotated []byte

	primaryIsNewKey bool
}

// Name gives the name of key suitable for telemetry according to the March 2021 QToken rotation spec, or indicates that no such key exists.
func (k Keys) Name(key []byte) (string, bool) {
	if bytes.Compare(k.newKey(), key) == 0 {
		return "new", true
	} else if bytes.Compare(k.oldKey(), key) == 0 {
		return "old", true
	}
	return "invalid", false
}

func (k Keys) newKey() []byte {
	if k.primaryIsNewKey {
		return k.Primary
	}
	return k.Rotated
}

func (k Keys) oldKey() []byte {
	if k.primaryIsNewKey {
		return k.Rotated
	}
	return k.Primary
}

// KeysFromEnv produces an instance of Keys based on the current environment, or indicates
// that the environment does not contain QToken key material in the standardized place.
func KeysFromEnv() (Keys, error) {

	qtoken, ok := os.LookupEnv(EnvQToken)
	if !ok {
		return Keys{}, fmt.Errorf("missing env var %q", EnvQToken)
	}

	qtokenR, ok := os.LookupEnv(EnvQTokenRotated)
	if !ok {
		return Keys{}, fmt.Errorf("missing env var %q", EnvQTokenRotated)
	}

	qtokenC, ok := os.LookupEnv(EnvQTokenChecksum)
	if !ok {
		return Keys{}, fmt.Errorf("missing env var %q", EnvQTokenChecksum)
	}

	return Keys{
		Primary:         []byte(qtoken),
		Rotated:         []byte(qtokenR),
		primaryIsNewKey: qtoken == qtokenC,
	}, nil
}

// MustKeysFromEnv is like KeysFromEnv except it panics if no valid key material can be found.
func MustKeysFromEnv() Keys {
	keys, err := KeysFromEnv()
	if err != nil {
		panic(err)
	}
	return keys
}
