author: jaredr@qualtrics.com, tylerc@qualtrics.com

Building Applications with `golang/app`
===

[![GoDoc](http://godoc.eng.qops.net/gitlab-app.eng.qops.net/golang/app?status.svg)](http://godoc.eng.qops.net/gitlab-app.eng.qops.net/golang/app)

# Design

The theory of this package is documented in [DESIGN.md](https://gitlab-app.eng.qops.net/golang/app/blob/master/DESIGN.md) and is recommended reading for those curious about the purpose or value of this package.

Contributors to `app` should read DESIGN.md and the [Contributing guidelines](https://corpus.eng.qops.net/docs/packages_&_service_apis/packages/go/index/#contributing-to-existing-shared-packages) before submitting changes.

# Starting from scratch

The easiest way to create a new Go service is using the `app` package, which abstracts out the common components of a service and spares you from reimplementing boilerplate in every service.

## Creating `main.go`

Let's start a service called "walkthrough" by creating a new `main.go` file:

```go
package main

import (
	"log"

	"gitlab-app.eng.qops.net/golang/app"
	httpserver "gitlab-app.eng.qops.net/golang/app/server/http"
)

func main() {

	walkthrough := app.New(

		// Set the name for this service.
		app.WithName("walkthrough"),

		// Start a new HTTP server listening on 0.0.0.0:8080.
		app.WithServer(":8080", httpserver.New()),

	)

	// Execution will wait here until the servers have been stopped
	walkthrough.Run()

}
```

Even with just this scaffolding, our application already supports a lot of fundamental functionality:

- **Access logs**: Logs formatted according to the Qualtrics latency log format are produced for the HTTP server. By default they are written to `stdout`, but a production service should configure them to be written to a file on disk.
- **Reads tracing data**: The HTTP server conforms to our tracing standards by reading (or generating) standard keys like Transaction ID. These are automatically added in access logs and also attached to the request context using the [`transaction`](http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/transaction) package.
- **Implements graceful shutdown**: When the application is stopped by either a SIGINT (`^C`) or SIGTERM (`docker stop`), it waits a short grace period[^1] for processing to complete on existing connections. This helps enable zero-downtime deployments.
- **Implements standard routes**: The standardized healthcheck and version routes are pre-mounted on our HTTP server:
	- `http://localhost:8080/qualtrics/v1/version` describes current version information.
	- `http://localhost:8080/walkthrough/healthcheck` is a simple healthcheck that always returns `{"status":"ok"}`. This is a useful healthcheck on its own, as it fails if the service is inaccessible, but it can be replaced with a deeper check if needed.
- **Configures a maintenance server**: An additional HTTP server is started on port 22500 that included with debugging and maintenance facilities. In our simple template, this includes:
	- The `pprof` profiling endpoints at `http://localhost:22500/debug/pprof`
	- Go runtime metrics exported at `http://localhost:22500/metrics`

[^1]: The grace period is 10 seconds by default, but you could configure it to another value using `server.WithShutdownGracePeriod(...)` if you wanted.

## Adding routes

As it stands, our server starts an HTTP server on port 8080, but doesn't provide any handlers. Apart from automatically-handled routes like the healthcheck, this means that all requests result in a `404 Not Found` response.

Let's configure a handler to respond to requests more intelligently. All HTTP processing in Go is done by things that implement the [`http.Handler`](https://golang.org/pkg/net/http/#Handler) interface in the standard library. 

Create a simple `http.ServeMux`, which implements this interface, and attach some routes:

```go
func main() {

	// Implement a couple routes	
	mux := http.NewServeMux()
	mux.Handle("/hello", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintln(w, "Hello, world!")
	}))
	mux.Handle("/goodbye", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintln(w, "Goodbye, world!")
	}))

	...

}
```

Then, we provide our routes to the application server using the configuration option `httpserver.WithHandler(...)` , which takes any `http.Handler` as its argument for our server to use.

```go

		...

		app.WithServer(":8080", httpserver.New(
			httpserver.WithHandler(mux)
		)),

		...

```

### Using `julienschmidt/httprouter`

Since an `*httprouter.Router` also implements the `http.Handler` interface, it can be used in place of the `http.ServeMux` we were using before.

```go
func main() {

	// Implement a couple routes
	router := httprouter.New()

	router.GET("/resource/:RESOURCE_ID", httprouter.Handle(func(w http.ResponseWriter, req *http.Request, ps httprouter.Params) {
		fmt.Fprintf(w, "Get %s", ps.ByName("RESOURCE_ID"))
	}))

	...

}
```

Just as before, you provide the routes to the application server using the configuration option `httpserver.WithHandler(...)`. However, you'll pass `router` instead of passing `mux`.

## Specifying an access log file

In your `main.go`, specify the location for your access log file. Something like:

```go
var logfile = flag.String("logfile", "/var/log/walkthrough_access.json", "access log file path")
```

Using the "flag" package allows you to pass in a logfile as a flag when running this app locally, by appending `-logfile ./access.log` to the end of the command when running the app.

We'll use that flag to open an access log and provide it to the application server using the configuration option `httpserver.WithAccessLog(...)` , which takes any `io.Writer` as its argument for our server to use.

We can use the `accesslog.MustOpenWriter` helper to create an `io.Writer` configured to open the file for writing, which will panic on startup if for some reason the access log file can't be opened.

```go
import "gitlab-app.eng.qops.net/golang/http/accesslog"

func main() {

	flag.Parse()

		...

		app.WithServer(":8080", httpserver.New(
			httpserver.WithAccessLog(accesslog.MustOpenWriter(*logfile)),
		)),

		...

}
```

## Verifying your app
After compiling and running this new program, we can verify its behavior.

```bash
$ curl http://127.0.0.1:8080/hello
Hello, world!
```

Great!

# Sample

This program is the result of combining all the steps above:

```go
package main

import (
	"log"

	"gitlab-app.eng.qops.net/golang/app"
	httpserver "gitlab-app.eng.qops.net/golang/app/server/http"
)

var logfile = flag.String("logfile", "/var/log/walkthrough_access.json", "access log file path")

func main() {

	flag.Parse()

	// Implement a couple routes
	mux := http.NewServeMux()
	mux.Handle("/hello", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintln(w, "Hello, world!")
	}))
	mux.Handle("/goodbye", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintln(w, "Goodbye, world!")
	}))

	walkthrough := app.New(

		// Set the name for this service.
		app.WithName("walkthrough"),

		// Start a new HTTP server listening on 0.0.0.0:8080.
		app.WithServer(":8080", httpserver.New(
			httpserver.WithHandler(mux)
			httpserver.WithAccessLog(accesslog.MustOpenWriter(*logfile)),
		)),

	)

	// Execution will wait here until the servers have been stopped
	walkthrough.Run()

}

```
