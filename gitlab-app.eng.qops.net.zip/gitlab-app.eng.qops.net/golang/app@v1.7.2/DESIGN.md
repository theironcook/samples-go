# Design

## Goal / Purpose

The `app` package is intended to simplify bootstrapping new services that include HTTP, gRPC, or
Thrift servers by providing zero-configuration support for standard features, so that new services
can be make production-ready in minutes rather than hours.

Problems addressed by this package include:

- Making fast the creation of a new service
- Standardizing the structure and tooling of Go services
- Reducing new service boilerplate by including:
  - [access logging](https://gitlab-app.eng.qops.net/misc/latency/blob/master/README.md)
  - graceful shutdown
  - [healthchecks](https://odo.corp.qualtrics.com/wiki/index.php/Qualtrics_API_Conventions#Health_Check)
  - [profiling support](https://golang.org/pkg/net/http/pprof/)
  - metrics
  - [version route](https://odo.corp.qualtrics.com/wiki/index.php/Qualtrics_API_Conventions#Version_Information)

For more information about included functionality, see the [godoc](http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/app).

## Audience

Who should use this?

Using the app package is strongly recommended for all Go services at Qualtrics that provide HTTP,
gRPC, TCP, or Thrift servers.

## Vision

This package was created after realizing that starting a new service virtually always included
setting up the same standard structure as other services, including HTTP graceful shutdown
support, the standard Qualtrics versioning route, access logs formatted according to spec, and
profiling support. Because this was nontrivial work, it was common for new services to omit
some or all of these features.

The guiding principles of `app` are as follows:

- **Make common patterns easier, but do not make any pattern impossible.** In general, `app`
  must not enforce any new assumptions on the user because the utility and adoption of `app` is
  greatest if a user never feels as though `app` has forced them into a particular API or decision.
  As an example, HTTP servers use `http.Handler` and not `httprouter`. As a second example, access
  logs are provided to a generic `io.Writer` rather than any particular logging library.

- **Always allow the user to opt out of any automatic behavior.** If `app` provides a behavior by
  default it should also include means for disabling that behavior. For example, `app` chooses to
  mount a debug server with profiling endpoints by default, but can be disabled by users who don't
  want it.

- **Include zero-configuration support for universal functionality.** Behavior common to virtually
  all Qualtrics services is a good candidate for inclusion in `app`, particularly if it can be
  provided automatically (e.g., graceful shutdown). Functionality that is common but not universal
  should not be included in `app`.

- **Avoid implementing original features.** Functionality provided by the app package should
  generally be implemented by some other package, which `app` uses. This is to avoid a scenario
  where a user is forced to use `app` because it is infeasible to obtain some particular behavior
  without it.

The scope allowed by this criteria is intentionally small, as very few features are truly universal
in nature. Features outside this criteria should not be included in `app` even if they're useful
or convenient.

## How

Clients generally create a single `Application` and configure its behavior declaratively using
arguments to `app.New()` (see the [godoc](http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/app)
for a complete list of built-in options). Each option configures the `Application` struct, but
the application itself takes no action until one of the lifecycle methods `Run` or `Start` is
invoked.

Servers may be registered with the `app.WithServer()` API. This helper accepts any server that
implements the [server.Server](http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/app/server#Server)
interface.

Built-in servers include HTTP, gRPC, and Thrift servers. Their implementations are relatively
straightforward and should be understandable by anyone with the relevant HTTP, gRPC, or Thrift
domain experience.

Also included is the `server/servertest` helper package, which provides a basic mock of the
`server.Server` interface for use in testing. The entirety of that package is code generated
by `moq`; see the associated `go generate` comment in `server.go`.

Usage of HTTP servers interact with two external packages:

- [gitlab-app.eng.qops.net/golang/transaction](https://gitlab-app.eng.qops.net/golang/transaction) associates
  standard transaction headers with incoming requests.
- [gitlab-app.eng.qops.net/golang/accesslog](https://gitlab-app.eng.qops.net/golang/transaction)
  formats access logs according to our specification.
