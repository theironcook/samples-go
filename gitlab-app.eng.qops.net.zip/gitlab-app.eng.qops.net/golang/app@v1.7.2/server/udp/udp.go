package udp

import (
	"context"
	"errors"
	"fmt"
	"log"
	"net"
	"os"
	"time"

	"gitlab-app.eng.qops.net/golang/app/server"
)

type (
	// Handler is implemented by users to provide the behavior of the UDP server.
	Handler interface {
		// HandlePacket is provided each received UDP packet as it is received,
		// along with that packet's source address.
		//
		// Because HandlePacket is called in the same goroutine as the connection
		// handler, implementors should be aware that implementing long-running
		// logic will block processing of future packets.
		HandlePacket(addr net.Addr, p []byte)
	}

	UDPServer struct {
		handler Handler
		conn    *net.UDPConn

		stop      chan struct{} // closed when we want to stop the server
		serveDone chan struct{} // closed when the serve loop completes
	}

	UDPOption func(*UDPServer)
)

const readTimeout = 50 * time.Millisecond

// New creates a new UDP server.
func New(opts ...UDPOption) *UDPServer {

	// Create a UDP server, with initialized maps and channels
	s := &UDPServer{
		stop:      make(chan struct{}),
		serveDone: make(chan struct{}),
	}

	// Apply options
	for _, opt := range opts {
		opt(s)
	}

	return s

}

// Addr returns the address on which the server is listening.
func (s *UDPServer) Addr() net.Addr {
	return s.conn.LocalAddr()
}

func (s *UDPServer) Start(addr string, _ server.AppContext) error {

	udpAddr, err := net.ResolveUDPAddr("udp", addr)
	if err != nil {
		return err
	}

	s.conn, err = net.ListenUDP("udp", udpAddr)
	if err != nil {
		return err
	}

	go func() {
		if err := s.serve(); err != nil {
			log.Printf("server stopped uncleanly: %s", err)
		}
	}()

	return nil
}

func (s *UDPServer) serve() error {

	defer close(s.serveDone)

	// Declare a reusable buffer
	var buf [65536]byte

readLoop:
	for {
		// Abort when the server is stopped
		select {
		case <-s.stop:
			break readLoop
		default:
		}

		// Set a read deadline, so the udpConn Read will not block indefinitely
		s.conn.SetReadDeadline(time.Now().Add(readTimeout))

		n, remoteAddr, err := s.conn.ReadFrom(buf[0:])
		switch {
		case errors.Is(err, os.ErrDeadlineExceeded):
			continue
		case err != nil:
			return fmt.Errorf("failed to read from udp connection: %w\n", err)
		}

		s.handler.HandlePacket(remoteAddr, buf[0:n])
	}

	return nil

}

func (s *UDPServer) Stop(ctx context.Context, graceful bool) error {

	close(s.stop) // signal that we want to stop accepting new connections
	<-s.serveDone // wait until the serve() goroutine ends (blocks for under readTimeout)

	return s.conn.Close()
}

// WithHandler configures the UDPServer to respond to new
// connection using h.
func WithHandler(h Handler) UDPOption {
	return UDPOption(func(s *UDPServer) {
		s.handler = h
	})
}
