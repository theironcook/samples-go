package tcp

import (
	"context"
	"errors"
	"log"
	"net"
	"os"
	"time"

	"gitlab-app.eng.qops.net/golang/app/server"
)

type (
	Handler interface {
		HandleConn(net.Conn)
		Shutdown(ctx context.Context) error
	}

	TCPServer struct {
		handler  Handler
		listener *net.TCPListener

		accept    chan net.Conn
		stop      chan struct{} // closed when we want to stop the server
		serveDone chan struct{} // closed when the serve loop completes
		abort     chan struct{} // closed when all goroutines have been forcibly closed
		done      chan struct{} // closed when the manage loop finishes all active connections
	}

	TCPOption func(*TCPServer)
)

const (
	acceptTimeout  = 50 * time.Millisecond
	regulationRate = 50 * time.Millisecond
)

// New creates a new TCP server.
func New(opts ...TCPOption) *TCPServer {

	// Create a TCP server, with initialized maps and channels
	s := &TCPServer{
		accept:    make(chan net.Conn),
		stop:      make(chan struct{}),
		serveDone: make(chan struct{}),
		abort:     make(chan struct{}),
		done:      make(chan struct{}),
	}

	// Apply options
	for _, opt := range opts {
		opt(s)
	}

	return s

}

// Addr returns the address on which the server is listening.
func (s *TCPServer) Addr() net.Addr {
	return s.listener.Addr()
}

func (s *TCPServer) Start(addr string, _ server.AppContext) error {

	listener, err := net.Listen("tcp", addr)
	if err != nil {
		panic(err)
	}

	s.listener = listener.(*net.TCPListener)

	go s.manage()

	go func() {
		if err := s.serve(); err != nil {
			log.Printf("server stopped uncleanly: %s", err)
		}
	}()

	return nil
}

func (s *TCPServer) serve() error {

acceptLoop:
	for {
		// Abort when the server is stopped
		select {
		case <-s.stop:
			break acceptLoop
		default:
		}

		s.listener.SetDeadline(time.Now().Add(acceptTimeout))

		conn, err := s.listener.Accept()
		if errors.Is(err, os.ErrDeadlineExceeded) {
			continue
		} else if err != nil {
			return err
		}

		// Pass the new connection off to the manage goroutine,
		// which will invoke the configured handler
		s.accept <- conn
	}

	close(s.serveDone)
	return nil
}

func (s *TCPServer) Stop(ctx context.Context, graceful bool) error {

	close(s.stop) // signal that we want to stop accepting new connections
	<-s.serveDone // wait until the serve() goroutine ends (blocks for under acceptTimeout)

	if err := s.listener.Close(); err != nil {
		return err
	}

	ctx, cancel := context.WithCancel(ctx)
	defer cancel()

	// cancel context immediately if not graceful
	if !graceful {
		cancel()
	}

	// notify the handler that it should start shutting down; it has until the ctx expires to do so cleanly
	go s.handler.Shutdown(ctx)

	select {
	case <-s.done: // great, we shut down gracefully
		return nil

	case <-ctx.Done():
		// when the context expires, just kill everything
		close(s.abort)
		<-s.done
		return ctx.Err()
	}
}

func (s *TCPServer) manage() {

	clients := make(map[net.Conn]bool) // tracks the number of outstanding connections
	finish := make(chan net.Conn)      // allows communication between this method and its goroutines

	regulator := time.NewTicker(regulationRate)
	defer regulator.Stop()

manageLoop:
	for {
		select {

		case conn := <-s.accept:
			clients[conn] = true
			go func() {
				s.handler.HandleConn(conn)
				select {
				case finish <- conn: // this case is taken while the server is still under normal operation
				case <-s.done: // this case is taken after the server has been aborted and stopped
				}
			}()

		case conn := <-finish:
			delete(clients, conn)
			conn.Close()

		// There's nothing we can do to FORCE all the Handler goroutines to end,
		// but we can try to hasten it by closing all the underlying connections
		case <-s.abort:
			for conn := range clients {
				delete(clients, conn)
				conn.Close()
			}
			break manageLoop

		case <-regulator.C:
			// If the server has stopped and we're not waiting for connections
			// to complete, we can break the loop. This check is nested within a
			// regulator to avoid a tight, CPU-intensive loop
			select {
			case <-s.serveDone:
				if len(clients) == 0 {
					break manageLoop
				}
			default:
			}
		}
	}

	close(s.done)
}

// WithHandler configures the TCPServer to respond to new
// connection using h.
func WithHandler(h Handler) TCPOption {
	return TCPOption(func(s *TCPServer) {
		s.handler = h
	})
}
