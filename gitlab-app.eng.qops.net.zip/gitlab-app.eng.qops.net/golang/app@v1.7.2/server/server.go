//go:generate moq -pkg servertest -out server_mock.go . Server
//go:generate mv server_mock.go ./servertest

// Package server implements servers of various protocols for use with the app package.
package server

import (
	"context"
	"net"
)

// Server of any protocol must implement this interface of lifecycle hooks to
// enable the app package to start and interrupt them.
type Server interface {
	// Start starts the Server on the given network address.
	Start(addr string, appCtx AppContext) error

	// Stop shuts the server down in a potentially graceful way. If ctx is canceled
	// during the shutdown process, Stop() returns promptly.
	Stop(ctx context.Context, graceful bool) error

	// Addr indicates the network address on which the Server is listening. If
	// Start() has not yet been invoked, the return value of Addr() is undefined.
	//
	// Note that the return value of Addr() may not exactly match the addr provided
	// to Start(). For example, with TCP servers addr may have been ":0" while the
	// return value of Addr() correctly indicates the system-assigned port.
	Addr() net.Addr
}

// AppContext carries information from the application that may be of interest
// to individual servers.
type AppContext struct {
	Name string
}
