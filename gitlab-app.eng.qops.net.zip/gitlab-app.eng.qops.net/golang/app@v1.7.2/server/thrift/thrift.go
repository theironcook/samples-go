package thrift

import (
	"context"
	"log"
	"net"

	"gitlab-app.eng.qops.net/golang/app/server"

	"github.com/apache/thrift/lib/go/thrift"
)

type (
	// A ThriftServer implements a Server using the Thrift protocol.
	ThriftServer struct {
		processor thrift.TProcessor

		transport thrift.TTransport
		server    *thrift.TSimpleServer
		address   net.Addr
	}

	// An ThriftOption codifies a piece of configuration that should be applied to
	// an ThriftServer to influence its behavior.
	ThriftOption func(*ThriftServer)
)

// New prepares a Thrift server for use.
//
// See the ThriftOption constructors for additional information about
// ways a ThriftServer can be configured.
func New(opts ...ThriftOption) *ThriftServer {

	// create a Thrift server with defaults
	s := &ThriftServer{}

	// Apply options
	for _, opt := range opts {
		opt(s)
	}

	return s

}

// Addr returns the address on which the server is listening.
func (s *ThriftServer) Addr() net.Addr {
	return s.address
}

// Start binds the HTTPServer to the provided addr and asynchronously begins
// servicing requests.
func (s *ThriftServer) Start(addr string, appCtx server.AppContext) error {

	// configure the thrift server they way we do
	protocolFactory := thrift.NewTBinaryProtocolFactoryDefault()
	transportFactory := thrift.NewTFramedTransportFactory(thrift.NewTTransportFactory())

	// open a server
	transport, err := thrift.NewTServerSocket(addr)
	if err != nil {
		return err
	}

	s.address = transport.Addr()

	s.server = thrift.NewTSimpleServer4(s.processor, transport, transportFactory, protocolFactory)

	go func() {
		if err := s.server.Serve(); err != nil {
			log.Printf("server stopped uncleanly: %s", err)
		}
	}()

	return nil

}

// Stop shuts down the ThriftServer. Graceful shutdown of a ThriftServer is not
// yet supported.
func (s *ThriftServer) Stop(ctx context.Context, graceful bool) error {
	return s.server.Stop()
}

// WithProcessor configures the TProcessor to use for servicing incoming RPC calls.
// All ThriftServers should be configured with a TProcessor using WithProcessor.
func WithProcessor(p thrift.TProcessor) ThriftOption {
	return ThriftOption(func(s *ThriftServer) {
		s.processor = p
	})
}
