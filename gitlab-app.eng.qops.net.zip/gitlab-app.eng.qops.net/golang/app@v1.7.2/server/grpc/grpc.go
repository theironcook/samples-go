package grpc

import (
	"context"
	"log"
	"net"

	"gitlab-app.eng.qops.net/golang/app/server"

	"google.golang.org/grpc"
)

type (
	GRPCServer struct {
		server   *grpc.Server
		listener net.Listener
	}

	GRPCOption func(*GRPCServer)
)

// New creates a new gRPC server.
func New(opts ...GRPCOption) *GRPCServer {
	return NewWithServerOptions([]grpc.ServerOption{}, opts...)
}

// NewWithServerOptions creates a new gRPC server with the given server options.
//
// Example:
//
//	serverOpts := []grpc.ServerOption{
//		grpc.StatsHandler(otelgrpc.NewClientHandler()),
//	}
//
// fooApp := app.New(
//
//	app.WithName("foo"),
//	app.WithServer(fmt.Sprintf(":%d", grpcPort), grpcserver.NewWithServerOptions(
//		serverOpts,
//		grpcserver.WithRegistrator(func(server *grpc.Server) {
//			pb.RegisterBarBazServer(server, bar.NewClient(baz))
//		}),
//	)),
//
// )
func NewWithServerOptions(serverOpts []grpc.ServerOption, opts ...GRPCOption) *GRPCServer {

	s := &GRPCServer{
		server: grpc.NewServer(serverOpts...),
	}

	// Apply options
	for _, opt := range opts {
		opt(s)
	}

	return s

}

// Addr returns the address on which the server is listening.
func (s *GRPCServer) Addr() net.Addr {
	return s.listener.Addr()
}

func (s *GRPCServer) Start(addr string, _ server.AppContext) error {

	rpcSocket, err := net.Listen("tcp", addr)
	if err != nil {
		panic(err)
	}

	s.listener = rpcSocket

	go func() {
		if err := s.server.Serve(rpcSocket); err != nil {
			log.Printf("server stopped uncleanly: %s", err)
		}
	}()

	return nil

}

func (s *GRPCServer) Stop(ctx context.Context, graceful bool) error {

	if !graceful {
		s.server.Stop()
		return nil
	}

	stop := make(chan struct{})

	go func() {
		s.server.GracefulStop()
		close(stop)
	}()

	select {
	case <-stop: // great, we shut down gracefully
	case <-ctx.Done(): // context canceled, kill it now
		s.server.Stop()
	}

	return nil
}

// WithRegistrator allows the gRPC server to be configured with a gRPC handler:
//
//     WithRegistrator(func(s *grpc.Server) {
//         pb.RegisterInternalCacheServer(rpcServer, cacheServerHandler)
//     })
//
// Multiple handlers may be registered on a single gRPC server instance.
func WithRegistrator(registrator func(server *grpc.Server)) GRPCOption {
	return GRPCOption(func(s *GRPCServer) {
		registrator(s.server)
	})
}
