package grpc

import (
	"context"
	"gitlab-app.eng.qops.net/golang/app/server"
	"testing"

	"google.golang.org/grpc"
)

func TestNewDefaultOptions(t *testing.T) {
	grpcServer := New()

	if grpcServer == nil {
		t.Errorf("expected non-nil GRPCServer")
	}
}

func TestNewWithCustomOptions(t *testing.T) {
	var invoked uint32

	option := func(gs *GRPCServer) {
		invoked++
	}

	grpcServer := New(option)

	if grpcServer == nil {
		t.Errorf("expected non-nil GRPCServer")
	}

	if invoked != 1 {
		t.Errorf("expected option to be invoked once, got %d", invoked)
	}
}

func TestNewWithServerOptions(t *testing.T) {
	serverOption := grpc.MaxConcurrentStreams(10)
	grpcServer := NewWithServerOptions([]grpc.ServerOption{serverOption})

	if grpcServer == nil {
		t.Errorf("expected non-nil GRPCServer")
	}
}

func TestNewWithMultipleOptions(t *testing.T) {
	var invoked1, invoked2 uint32

	option1 := func(gs *GRPCServer) {
		invoked1++
	}

	option2 := func(gs *GRPCServer) {
		invoked2++
	}

	grpcServer := New(option1, option2)

	if grpcServer == nil {
		t.Errorf("expected non-nil GRPCServer")
	}

	if invoked1 != 1 || invoked2 != 1 {
		t.Errorf("expected both options to be invoked once, got %d and %d", invoked1, invoked2)
	}
}

func TestGRPCStopAndStop(t *testing.T) {
	tests := []struct {
		name     string
		graceful bool
	}{
		{
			name:     "non graceful stop",
			graceful: false,
		},
		{
			name:     "graceful stop",
			graceful: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			grpcServer := New(func(gs *GRPCServer) {

			})
			if grpcServer == nil {
				t.Fatalf("expected non-nil GRPCServer")
			}

			err := grpcServer.Start(":0", server.AppContext{Name: "test"})
			if err != nil {
				t.Errorf("expected no error, got %v", err)
			}

			addr := grpcServer.Addr()
			if addr == nil {
				t.Errorf("expected non-nil address")
			}

			err = grpcServer.Stop(context.Background(), tt.graceful)
			if err != nil {
				t.Errorf("expected no error, got %v", err)
			}
		})
	}
}

func TestWithRegistrator(t *testing.T) {
	var registered1, registered2 bool

	registrator1 := func(s *grpc.Server) {
		registered1 = true
	}

	registrator2 := func(s *grpc.Server) {
		registered2 = true
	}

	option1 := WithRegistrator(registrator1)
	option2 := WithRegistrator(registrator2)
	grpcServer := New(option1, option2)

	if grpcServer == nil {
		t.Errorf("expected non-nil GRPCServer")
	}

	if !registered1 || !registered2 {
		t.Errorf("expected both registrators to be invoked")
	}
}
