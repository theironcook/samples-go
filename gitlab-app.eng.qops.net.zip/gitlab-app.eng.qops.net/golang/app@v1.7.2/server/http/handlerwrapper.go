package http

import (
	"encoding/json"
	"fmt"
	"net/http"

	"gitlab-app.eng.qops.net/golang/app/build"
	"gitlab-app.eng.qops.net/golang/app/server"
	"gitlab-app.eng.qops.net/golang/http/accesslog"
	"gitlab-app.eng.qops.net/golang/transaction"
)

type handlerWrapper func(http.Handler) http.Handler

const versionRoute = "/qualtrics/v1/version"

// statusOK is the response for the default healthcheck
var statusOK = []byte(`{"status": "ok"}`)

// wrapHandler attaches handlerWrappers (healthcheck, version, transaction, etc.)
// to the given handler. Note that the handlerWrappers will run in reverse order;
// that is, []handlerWrapper{A, B, C} will be run as C, B, A.
func (s *HTTPServer) wrapHandler(handler http.Handler, appCtx server.AppContext) http.Handler {
	var wrappers []handlerWrapper

	wrappers = append(wrappers, wrapWithTransactionHeaders())

	// If an access log sink is provided, configure access logs to go there.
	if s.accessLogSink != nil {
		wrappers = append(wrappers, s.wrapWithAccessLog())
	}

	// If the version route is enabled, attempt to handle it.
	if s.enableVersionRoute {
		wrappers = append(wrappers, wrapWithVersionRoute(versionRoute))
	}

	// If the healthcheck route is enabled, handle it
	if s.healthcheck != nil {
		healthcheckRoute := fmt.Sprintf("/%s/healthcheck", appCtx.Name)
		wrappers = append(wrappers, s.wrapWithHealthcheck(healthcheckRoute))
	}

	// apply all wrappers to the handler
	return chain(handler, wrappers...)
}

// chain applies wrappers to an http.Handler
func chain(f http.Handler, wrappers ...handlerWrapper) http.Handler {
	for _, m := range wrappers {
		f = m(f)
	}
	return f
}

//
// handlerWrapper
//

// wrapWithHealthcheck responds to the healthcheck route
func (s *HTTPServer) wrapWithHealthcheck(path string) handlerWrapper {
	return func(f http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			if r.URL.Path == path {
				s.healthcheck.ServeHTTP(w, r)
				return
			}

			f.ServeHTTP(w, r)
		})
	}
}

// wrapWithVersionRoute writes a response with version information (ServiceName, SHA, etc.)
func wrapWithVersionRoute(path string) handlerWrapper {
	return func(f http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			if r.URL.Path == path {
				DefaultVersionHandlerFunc(w, r)
				return
			}

			f.ServeHTTP(w, r)
		})
	}
}

// wrapWithAccessLog attaches an access log
func (s *HTTPServer) wrapWithAccessLog() handlerWrapper {
	return func(f http.Handler) http.Handler {
		return accesslog.Handler{
			Writer:  s.accessLogSink,
			Handler: f,
		}
	}
}

// wrapWithTransactionHeaders sets transaction data on the request's context
// and sets the outgoing transaction headers
func wrapWithTransactionHeaders() handlerWrapper {
	return func(f http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			t := transaction.FromRequest(r)

			// set headers on context and request
			ctx := transaction.SetOnContext(r.Context(), t)

			// set outgoing headers
			transaction.SetResponseHeaders(w, t)

			// ensure access log includes entries for transaction data
			accesslog.SetReserved(r.Context(), accesslog.TransactionID, t.TransactionID)
			accesslog.SetReserved(r.Context(), accesslog.RequestID, t.RequestID)
			if t.ParentRequestID != "" {
				accesslog.SetReserved(r.Context(), accesslog.ParentRequestID, t.ParentRequestID)
			}

			f.ServeHTTP(w, r.WithContext(ctx))
		})
	}
}

// DefaultHealthCheckHandlerFunc will respond with health information according to the Qualtrics API version endpoint standard.
func DefaultHealthCheckHandlerFunc(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(statusOK)
}

// DefaultVersionHandlerFunc will respond with version information from the app/build package according to the Qualtrics API version endpoint standard.
func DefaultVersionHandlerFunc(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(struct {
		ServiceName string `json:"id"`
		Branch      string `json:"branch,omitempty"`
		SHA         string `json:"sha"`
		Version     string `json:"version"`
		BuildDate   string `json:"build_date,omitempty"`
		CommitDate  string `json:"commit_date,omitempty"`
	}{
		ServiceName: build.ServiceName,
		Branch:      build.BuildBranch,
		SHA:         build.BuildSHA,
		Version:     build.Version,
		BuildDate:   build.BuildDate,
		CommitDate:  build.CommitDate,
	})
}
