package http

import (
	"context"
	"crypto/tls"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"time"

	"gitlab-app.eng.qops.net/golang/app/server"
)

type (
	// An HTTPServer implements a Server using the HTTP protocol.
	HTTPServer struct {
		handler           http.Handler // handler implements the logic for this server
		healthcheck       http.Handler // healthcheck is called when this server's healthcheck is hit
		server            *http.Server // server is populated when the application is started
		listener          net.Listener
		certFile          string        // option path to cert file to be used with http.Server.ServeTLS
		keyFile           string        // option path to key file to be used with http.Server.ServeTLS
		idleTimeout       time.Duration // maximum wait period between requests on a keepalive connection
		readHeaderTimeout time.Duration // maximum time allowed to read request headers

		enableVersionRoute bool      // whether to enable the qualtrics-standard "version" route
		accessLogSink      io.Writer // where we should send access logs
		shutdownCallback   func(context.Context, bool)
	}

	// An HTTPOption codifies a piece of configuration that should be applied to
	// an HTTPServer to influence its behavior.
	HTTPOption func(*HTTPServer)
)

// New prepares an HTTPServer for use.
//
// Unless overridden with disabling options, the returned HTTPServer will be
// configured with the following behavior:
//
// * the healthcheck always returns {"status":"ok"}
// * the version route uses values from gitlab-app.eng.qops.net/golang/app/build
// * all other requests result in 404 Not Found
// * access logs are written to os.Stdout
//
// See the various HTTPOption constructors for additional information about
// ways an HTTPServer can be configured.
func New(opts ...HTTPOption) *HTTPServer {

	// create an HTTP server with defaults
	s := &HTTPServer{
		handler: http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			http.Error(w, http.StatusText(http.StatusNotFound), http.StatusNotFound)
		}),
		healthcheck:        http.HandlerFunc(DefaultHealthCheckHandlerFunc),
		idleTimeout:        1 * time.Minute,
		enableVersionRoute: true,
		accessLogSink:      os.Stdout,
	}

	// Apply options
	for _, opt := range opts {
		opt(s)
	}

	return s

}

// Start binds the HTTPServer to the provided addr and asynchronously begins
// servicing requests.
func (s *HTTPServer) Start(addr string, appCtx server.AppContext) error {

	s.server = &http.Server{
		Addr:              addr,
		Handler:           s.wrapHandler(s.handler, appCtx),
		IdleTimeout:       s.idleTimeout,
		ReadHeaderTimeout: s.readHeaderTimeout,
	}

	// default to a system-assigned port
	if addr == "" {
		addr = ":0"
	}

	// listen on a TCP socket
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		return err
	}

	// file the listener away
	s.listener = ln

	go func() {

		var err error
		if s.certFile != "" && s.keyFile != "" {
			// set TLS config
			// see https://blog.bracebin.com/achieving-perfect-ssl-labs-score-with-go
			s.server.TLSConfig = &tls.Config{
				MinVersion:               tls.VersionTLS12,
				CurvePreferences:         []tls.CurveID{tls.CurveP521, tls.CurveP384, tls.CurveP256},
				PreferServerCipherSuites: true,
				CipherSuites: []uint16{
					tls.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,
					tls.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,
				},
			}

			err = s.server.ServeTLS(tcpKeepAliveListener{ln.(*net.TCPListener)}, s.certFile, s.keyFile)
		} else {
			err = s.server.Serve(tcpKeepAliveListener{ln.(*net.TCPListener)})
		}

		if err != nil && err != http.ErrServerClosed {
			log.Printf("server stopped uncleanly: %s", err) // TODO how to log
		}
	}()

	return nil

}

// Stop shuts down the HTTPServer. If a graceful shutdown is requested, the
// underlying http.Server's Shutdown method is invoked with ctx. Otherwise,
// the http.Server's Close method is invoked.
func (s *HTTPServer) Stop(ctx context.Context, graceful bool) error {
	if s.shutdownCallback != nil {
		s.shutdownCallback(ctx, graceful)
	}
	if graceful {
		return s.server.Shutdown(ctx)
	}
	return s.server.Close()
}

// Addr returns the address on which the server is listening.
func (s *HTTPServer) Addr() net.Addr {
	return s.listener.Addr()
}

// WithoutVersionRoute disables the automatic registration of the Qualtrics-standard
// version route at /qualtrics/v1/version.
func WithoutVersionRoute() HTTPOption {
	return HTTPOption(func(s *HTTPServer) {
		s.enableVersionRoute = false
	})
}

// WithHandler configures the HTTPServer to respond to HTTP requests using h.
func WithHandler(h http.Handler) HTTPOption {
	return HTTPOption(func(s *HTTPServer) {
		s.handler = h
	})
}

// WithHealthcheck configures the HTTPServer to respond to healthcheck requests
// using hc.
//
// It is not necessary to use WithHealthcheck to enable healthchecks. The
// typical use of WithHealthcheck is to implement deeper healthcheck logic than
// simply returning {"status":"ok"}, for example by validating that database
// handles are still valid.
func WithHealthcheck(hc http.Handler) HTTPOption {
	return HTTPOption(func(s *HTTPServer) {
		s.healthcheck = hc
	})
}

// WithoutHealthcheck disables the automatic registration of the Qualtrics-standard
// healthcheck route at /<service_name>/healthcheck.
func WithoutHealthcheck() HTTPOption {
	return HTTPOption(func(s *HTTPServer) {
		s.healthcheck = nil
	})
}

// WithAccessLog configures access logs for the HTTPServer to be written to w instead
// of os.Stdout. It is valid, though unnecessary, to invoke "WithAccessLog(os.Stdout)".
func WithAccessLog(w io.Writer) HTTPOption {
	return HTTPOption(func(s *HTTPServer) {
		s.accessLogSink = w
	})
}

// WithTLS configures the server to server HTTP by passing paths to the cert and key files.
// When used, HTTPServer.Run will invoke ServeTLS instead of Serve.
func WithTLS(certFile, keyFile string) HTTPOption {
	return HTTPOption(func(s *HTTPServer) {
		s.certFile = certFile
		s.keyFile = keyFile
	})
}

// WithIdleTimeout configures the maximum amount of time to wait for the next request
// when keep-alives are enabled. It is implemented by configuring the IdleTimeout
// property of the underlying *http.Server.
func WithIdleTimeout(t time.Duration) HTTPOption {
	return HTTPOption(func(s *HTTPServer) {
		s.idleTimeout = t
	})
}

// WithReadHeaderTimeout configures the maximum time allowed to read request headers.
// It is implemented by configuring the ReadHeaderTimeout property of the
// underlying *http.Server.
func WithReadHeaderTimeout(t time.Duration) HTTPOption {
	return HTTPOption(func(s *HTTPServer) {
		s.readHeaderTimeout = t
	})
}

// WithShutdownCallback registers a function to call before shutting down servers.
func WithShutdownCallback(foo func(context.Context, bool)) HTTPOption {
	return HTTPOption(func(s *HTTPServer) {
		s.shutdownCallback = foo
	})
}

// tcpKeepAliveListener sets TCP keep-alive timeouts on accepted
// connections. It's used by ListenAndServe and ListenAndServeTLS so
// dead TCP connections (e.g. closing laptop mid-download) eventually
// go away.
type tcpKeepAliveListener struct {
	*net.TCPListener
}

func (ln tcpKeepAliveListener) Accept() (c net.Conn, err error) {
	tc, err := ln.AcceptTCP()
	if err != nil {
		return
	}
	tc.SetKeepAlive(true)
	tc.SetKeepAlivePeriod(3 * time.Minute)
	return tc, nil
}
