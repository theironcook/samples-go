## v1.7.2

- grpc:  Added function (NewWithServerOptions) to create new grpc server with provided server options.

## v1.7.1

- The deprecated `git.apache.org/thrift.git` dependency was replaced with `github.com/apache/thrift` and upgraded to the latest version.

## v1.7.0

- Add `CommitDate` variable to `golang/app/build`
- Return `CommitDate` as `commit_date` in `server.http.DefaultVersionHandlerFunc`

## v1.6.3

- Added a log to reveal the system-chosen port for servers that requested to be started on port 0.

## v1.6.2

- Upgraded dependencies google.golang.org/grpc and golang.org/x/net to resolve security vulnerabilities.

## v1.6.1

- http: Allowed the server's ReadHeaderTimeout to be configured with the `http.WithReadHeaderTimeout` option.

## v1.6.0

- Explicitly upgraded Go language requirement in `go.mod` to 1.17. This was already an implicit requirement in `v1.5.2` and `v1.5.3` due to a dependency upgrade in `v1.5.2`, but they failed to build with go 1.16 so they were left untagged.

## v1.5.3 (Untagged)

- Set `golang/http`'s `DefaultQRN` on app creation from environment variables. This value can be overridden using the `WithQRN` option.
- Set `golang/http`'s `DefaultClientID` on app creation if a name is provided

## v1.5.2 (Untagged)

- The `gitlab-app.eng.qops.net/golang/http` dependency was bumped to `v1.3.4` to pull in a vuln fix.

## v1.5.1 (August 18, 2021)

- Updated dependencies github.com/prometheus/client_golang and gitlab-app.eng.qops.net/golang/http

## v1.5.0

- Added support for new server type: UDP

## v1.4.1

- Improve graceful shutdown of the TCP server type by signaling the intent to shut down to the Handler

## v1.4.0

- Added support for new server type: TCP
- Updated to Go 1.16

## v1.3.0

- Updated direct dependencies
- Updated to Go 1.15

## v1.2.1

- In the HTTP server, use an IdleTimeout of 1 minute by default (can still be overridden with the http.WithIdleTimeout option).

## v1.2.0

- Declared dependency on gitlab-app.eng.qops.net/golang/http v1.1.0, as that package was updated to use Go modules
- Updated to Go 1.14

## v1.1.1

- Added Changelog.md to start documenting changes
- Removed `README` file since there is an existing `README.md`
- Removed `TLS_RSA_WITH_AES_256_GCM_SHA384` and `TLS_RSA_WITH_AES_256_CBC_SHA` ciphers since they are flagged by Nexpose when using a cert and key with an `app/http/HTTPServer`.
- Change `TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256` to be the least prefered cipher
