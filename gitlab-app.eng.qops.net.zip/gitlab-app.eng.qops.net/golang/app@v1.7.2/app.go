// Package app implements a stable foundation for building services in Go.
package app

import (
	"context"
	"fmt"
	"log"
	"net"
	"net/http"
	"net/http/pprof"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"

	"github.com/prometheus/client_golang/prometheus/promhttp"

	"gitlab-app.eng.qops.net/golang/app/server"
	httpserver "gitlab-app.eng.qops.net/golang/app/server/http"
	qhttp "gitlab-app.eng.qops.net/golang/http"
)

type (
	// Application represents a runnable Application. It may be configured with
	// Servers or additional functionality.
	//
	// For documentation of the many ways an Application can be configured, refer
	// to the documentation of the Option type.
	Application struct {
		name    string
		servers []netserver

		enablePprof      bool
		enablePrometheus bool
		shutdownTimeout  time.Duration
		shutdownCallback func(ctx context.Context, graceful bool)
		qrn              string
	}

	// netserver is a network server listening on a particular address, and is
	// agnostic of the server's protocol.
	netserver struct {
		Address string
		Server  server.Server
	}

	// An Option codifies a piece of configuration that should be applied to
	// Application to influence its behavior.
	//
	// Options may be either IDEMPOTENT or ADDITIVE. Idempotent options may be
	// reapplied any number of times without a change in behavior, while
	// additive options accumulate new functionality for each invocation of the
	// For example, an option to disable the maintenance server is idempotent,
	// while one to register a new HTTP server is additive.
	//
	// When not documented, the behavior of an Option should be assumed to be
	// idempotent.
	Option func(*Application)
)

const (
	// debugAddress indicates the address on which the embedded maintenance services
	// should listen.
	debugAddress = ":22500"

	// defaultShutdownTimeout defines the default grace period that should be waited
	// out for connections to close before forcibly stopping the application; it can
	// be overridden with the WithShutdownGracePeriod option.
	defaultShutdownTimeout = 5 * time.Second

	// envQrn is the name of the environment variable where QRN is injected
	envQrn = "COMPONENT_QRN"
)

// New declares a new Application and configures its specific behavior using
// the variadic argument opts.
//
// Unless overridden with disabling options, the returned Application will be
// configured with the following behavior:
//
// * pprof server
// * prometheus metrics
// * graceful shutdown with a 10-second timeout
//
// See the various Option implementations for additional information about ways
// an Application can be configured.
//
// Cases where more than a single Application is necessary should be rare.
func New(opts ...Option) *Application {
	// configure an application with sane defaults
	app := &Application{
		enablePprof:      true,
		enablePrometheus: true,
		shutdownTimeout:  defaultShutdownTimeout,
		qrn:              os.Getenv(envQrn),
	}

	// apply the options
	for _, opt := range opts {
		opt(app)
	}

	// set the default qrn for outbound http requests
	qhttp.DefaultQRN = app.qrn

	// set default client id for outbound http requests
	if app.name != "" {
		qhttp.DefaultClientID = app.name
	}

	// create a debug/metrics server on a standard port
	if app.enablePprof || app.enablePrometheus {
		mux := http.NewServeMux()

		// attach pprof routes to enable profiling and debugging
		if app.enablePprof {
			mux.Handle("/debug/pprof/", http.HandlerFunc(pprof.Index))
			mux.Handle("/debug/pprof/cmdline", http.HandlerFunc(pprof.Cmdline))
			mux.Handle("/debug/pprof/profile", http.HandlerFunc(pprof.Profile))
			mux.Handle("/debug/pprof/symbol", http.HandlerFunc(pprof.Symbol))
			mux.Handle("/debug/pprof/trace", http.HandlerFunc(pprof.Trace))
		}

		// attach prometheus so telegraf can pull metrics like number of goroutines
		if app.enablePrometheus {
			mux.Handle("/metrics", promhttp.Handler())
		}

		app.servers = append(app.servers, netserver{
			Address: debugAddress,
			Server: httpserver.New(
				httpserver.WithHandler(mux),
				httpserver.WithAccessLog(nil),
				httpserver.WithoutHealthcheck(),
				httpserver.WithoutVersionRoute(),
			),
		})
	}

	return app
}

// Run starts the Application and performs a graceful shutdown upon SIGINT
// or SIGTERM.
//
// Run is a convenience wrapper around Start(), graceful shutdown, and Stop().
func (app *Application) Run() error {
	if err := app.Start(); err != nil {
		return err
	}

	// wait for a shutdown signal
	stopChan := make(chan os.Signal)
	signal.Notify(stopChan, os.Interrupt, syscall.SIGTERM)
	<-stopChan

	// enforce that we wait no longer than the app.shutdownTimeout to stop
	ctx, cancel := context.WithTimeout(context.Background(), app.shutdownTimeout)
	defer cancel()

	return app.Stop(ctx)
}

// Start invokes the Start method on all registered servers. As servers are
// expected to start asynchronously, this method should return once the servers
// are running.
func (app *Application) Start() error {
	// starts all servers associated with this application
	for _, srv := range app.servers {
		if err := srv.Server.Start(srv.Address, server.AppContext{
			Name: app.name,
		}); err != nil && srv.Address == debugAddress {
			// if the debug server failed to start, try again with system-decided port
			if err := srv.Server.Start(":0", server.AppContext{}); err != nil {
				return err
			}

			fmt.Printf("debug server: Address %s not available; falling back to %s instead.\n", debugAddress, srv.Server.Addr())
			continue
		} else if err != nil {
			return err
		}

		// A process may listen on port 0 and be assigned to a random available port
		// by the system. If a server does this, log out the port the system chose.
		if _, port, _ := net.SplitHostPort(srv.Address); port == "0" {
			log.Printf("Server %T started on system-selected address %q\n", srv.Server, srv.Server.Addr())
		}
	}

	return nil
}

// Stop invokes the Stop method on all registered servers, which are expected to
// perform graceful shutdown by honoring the provided ctx.
//
// All servers are stopped concurrently.
func (app *Application) Stop(ctx context.Context) error {
	var (
		wg       sync.WaitGroup
		wait     = make(chan struct{})
		graceful = app.shutdownTimeout > time.Duration(0)
	)

	// provide the guarantee that context agrees with the shutdownTimeout
	if !graceful {
		var cancel context.CancelFunc
		ctx, cancel = context.WithTimeout(ctx, time.Duration(0))
		defer cancel()
	}

	// calls custom shutdown logic concurrently
	if app.shutdownCallback != nil {
		wg.Add(1)
		go func() {
			app.shutdownCallback(ctx, graceful)
			close(wait)
		}()

		go func() {
			// wait until either the context expires or the shutdownCallback returns
			select {
			case <-ctx.Done():
			case <-wait:
			}
			wg.Done()
		}()
	}

	// stops all servers associated with this application
	for _, srv := range app.servers {
		wg.Add(1)
		go func(s server.Server) {
			defer wg.Done()
			if err := s.Stop(ctx, graceful); err != nil {
				log.Printf("shutdown failure: %s", err)
			}
		}(srv.Server)
	}

	// waits for shutdown logic to complete
	wg.Wait()
	return nil
}

// WithName configures the name of the Application.
//
// WithName is an idempotent Option.
func WithName(name string) Option {
	return Option(func(app *Application) {
		app.name = name
	})
}

// WithServer registers server with the Application and configures it to listen
// on addr.
//
// WithServer is an additive Option.
func WithServer(addr string, server server.Server) Option {
	return Option(func(app *Application) {
		app.servers = append(app.servers, netserver{
			Address: addr,
			Server:  server,
		})
	})
}

// WithoutPprof disables the automatic registration of the standard net/http/pprof
// endpoints on the maintenance port.
//
// WithoutPprof is an idempotent Option.
func WithoutPprof() Option {
	return Option(func(app *Application) {
		app.enablePprof = false
	})
}

// WithoutPrometheus disables the automatic registration of the Prometheus metrics
// endpoint on the maintenance port.
//
// WithoutPrometheus is an idempotent Option.
func WithoutPrometheus() Option {
	return Option(func(app *Application) {
		app.enablePrometheus = false
	})
}

// WithShutdownGracePeriod configures the graceful shutdown timeout window to
// the value of timeout. When the Application is Stopped, individual Servers
// will be asked to complete their termination procedure within this duration.
//
// WithShutdownGracePeriod is an idempotent Option.
func WithShutdownGracePeriod(timeout time.Duration) Option {
	return Option(func(app *Application) {
		app.shutdownTimeout = timeout
	})
}

// WithShutdownCallback configures the application to perform custom shutdown
// logic when the Application is Stopped.
//
// The context.Context provided to the shutdown callback will be configured to
// expire with the Application's shutdown grace period. The Application will not
// wait for the shutdown callback to return beyond the cancelation of the ctx.
//
// The shutdown callback runs concurrently with the Stop method of any Servers.
// Closing persistent file handles and service clients inside the shutdown callback
// is therefore not recommended, as it can introduce subtle race conditions
// where a not-yet-stopped Server is suddenly unable to access a dependent resource.
// If such resources are configured in main() prior to creating the Application,
// instead defer their closures from there. Alternatively, you could handle these
// events after the Stop() (or Run()) method returns.
//
// WithShutdownCallback is an idempotent Option: only one shutdown callback can
// be registered.
func WithShutdownCallback(cb func(ctx context.Context, graceful bool)) Option {
	return Option(func(app *Application) {
		app.shutdownCallback = cb
	})
}

// WithQRN configures the application's QRN. By default this value is pulled from
// an environment variable, but this option can be used to override that value.
// This value is used to set `golang/http.DefaultQRN`, which sets an identifying
// header on outbound HTTP requests. This behavior can be disabled by providing
// an empty string value to this option.
func WithQRN(qrn string) Option {
	return Option(func(app *Application) {
		app.qrn = qrn
	})
}

// WithOptions is a meta-option that allows the selection of relevant Options
// at runtime. For example, WithOptions could be used to choose how long to wait
// for graceful shutdowns by checking an environment variable to determine whether
// the Application is running in development or production:
//
//	app.WithOptions(func() []app.Option {
//
//		// if ABRUPT_SHUTDOWN is set, die immediately
//		if _, set := os.LookupEnv("ABRUPT_SHUTDOWN"); set {
//			return []app.Option{app.WithShutdownGracePeriod(0 * time.Second)}
//		}
//
//		// otherwise, use a longer timeout
//		return []app.Option{app.WithShutdownGracePeriod(5 * time.Second)}
//
//	}),
//
// WithOptions itself is an additive Option, but the options returned by the
// callback may be either additive or idempotent as documented.
func WithOptions(cb func() []Option) Option {
	// dynamically obtain options
	options := cb()

	// apply all the options that were returned
	return Option(func(app *Application) {
		for _, opt := range options {
			opt(app)
		}
	})
}
