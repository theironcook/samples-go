package app

import (
	"context"
	"io/ioutil"
	"net/http"
	"testing"
	"time"

	"gitlab-app.eng.qops.net/golang/app/server"
	httpserver "gitlab-app.eng.qops.net/golang/app/server/http"
	"gitlab-app.eng.qops.net/golang/app/server/servertest"
	qhttp "gitlab-app.eng.qops.net/golang/http"
)

func TestExpectedDefaults(t *testing.T) {
	app := New()

	if actual, expected := app.enablePprof, true; actual != expected {
		t.Errorf("unexpected default: enablePprof = %t (not %t)\n", actual, expected)
	}

	if actual, expected := app.enablePrometheus, true; actual != expected {
		t.Errorf("unexpected default: enablePrometheus = %t (not %t)\n", actual, expected)
	}

	if actual, expected := app.shutdownTimeout, defaultShutdownTimeout; actual != expected {
		t.Errorf("unexpected default: shutdownTimeout = %s (not %s)\n", actual, expected)
	}

	if app.shutdownCallback != nil {
		t.Errorf("unexpected default: shutdownCallback = [%T] (not nil)\n", app.shutdownCallback)
	}
}

func TestConstructorAppliesOptions(t *testing.T) {
	var invoked uint32

	_ = New(
		Option(func(a *Application) {
			invoked++
		}),
		Option(func(a *Application) {
			invoked++
		}),
	)

	if invoked != 2 {
		t.Errorf("failed to execute options in constructor")
	}
}

func TestStartStop(t *testing.T) {
	app := New(
		WithName("some-name"),
		WithoutPprof(),
		WithoutPrometheus(),
		WithServer(":0", httpserver.New(
			httpserver.WithAccessLog(ioutil.Discard),
			httpserver.WithHandler(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				w.WriteHeader(http.StatusTeapot)
			})),
		)),
	)

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	app.Start()
	defer app.Stop(ctx)

	// make an HTTP request to our test server
	address := app.servers[len(app.servers)-1].Server.Addr()
	req, _ := http.NewRequest("GET", "http://"+address.String()+"/just/a/test/route", nil)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Errorf("unexpected error: %s", err)
	}

	// assert that we got our response
	if resp.StatusCode != http.StatusTeapot {
		t.Errorf("failed to start server")
	}
}

func TestShutdownCallback(t *testing.T) {
	var invoked uint32

	app := New(
		WithName("some-name"),
		WithShutdownCallback(func(ctx context.Context, graceful bool) {
			invoked |= 0x01 << 0
		}),
	)

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	app.Start()
	app.Stop(ctx)

	if invoked&0x01<<0 == 0 {
		t.Errorf("failed to execute shutdown callback")
	}
}

func TestWithName(t *testing.T) {
	app := New()
	WithName("some-name")(app)

	if actual, expected := app.name, "some-name"; actual != expected {
		t.Errorf("failed to set application name")
	}
}

func TestWithServer(t *testing.T) {
	s := &servertest.ServerMock{
		StartFunc: func(addr string, appCtx server.AppContext) error {
			return nil
		},
	}

	app := New()
	defaultServers := len(app.servers) // note how many servers existed _before_ WithServer

	WithServer(":1234", s)(app)

	if len(app.servers) != defaultServers+1 {
		t.Fatalf("failed to add new server")
	}

	expected := netserver{Address: ":1234", Server: s}
	if actual := app.servers[len(app.servers)-1]; actual != expected {
		t.Errorf("unexpected server added")
	}
}

func TestWithoutPprof(t *testing.T) {
	app := New()
	WithoutPprof()(app)

	if actual, expected := app.enablePprof, false; actual != expected {
		t.Errorf("failed to disable pprof")
	}
}

func TestWithoutPrometheus(t *testing.T) {
	app := New()
	WithoutPrometheus()(app)

	if actual, expected := app.enablePrometheus, false; actual != expected {
		t.Errorf("failed to disable prometheus")
	}
}

func TestWithShutdownGracePeriod(t *testing.T) {
	app := New()
	WithShutdownGracePeriod(32 * time.Millisecond)(app)

	if app.shutdownTimeout != 32*time.Millisecond {
		t.Errorf("failed to set shutdown grace period")
	}
}

func TestWithShutdownCallback(t *testing.T) {
	var invoked bool

	cb := func(ctx context.Context, graceful bool) {
		invoked = true
	}

	app := New()
	WithShutdownCallback(cb)(app)

	if app.shutdownCallback == nil {
		t.Errorf("failed to set shutdown callback")
	} else {
		app.shutdownCallback(nil, true)
		if invoked != true {
			t.Errorf("failed to set shutdown callback")
		}
	}
}

func TestWithQRN(t *testing.T) {
	app := New()
	WithQRN("some-qrn")(app)

	if actual, expected := app.qrn, "some-qrn"; actual != expected {
		t.Errorf("failed to set application qrn")
	}
}

func TestWithOptions(t *testing.T) {
	var invoked uint32
	var options []Option

	// generate some mock options
	for i := uint32(0); i < 3; i++ {
		ii := i
		options = append(options, Option(func(a *Application) {
			invoked |= (0x01 << ii)
		}))
	}

	// evaluate our mock options
	app := New()
	WithOptions(func() []Option { return options })(app)

	// verify that each option was executed
	for i := uint32(0); i < 3; i++ {
		if invoked&(0x01<<i) == 0 {
			t.Errorf("option %d not executed", i)
		}
	}
}

func TestNewSetsClientID(t *testing.T) {
	New(WithName("foo-service"))

	if qhttp.DefaultClientID != "foo-service" {
		t.Errorf("http default client id not set")
	}
}
