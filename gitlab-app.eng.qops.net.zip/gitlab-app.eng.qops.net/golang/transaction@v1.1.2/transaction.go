// Package transaction provides a standard struct and methods
// to set and get transaction information from an http.Request or a context.Context.
package transaction

// Transaction defines a struct that contains the identifiers for a request.
type Transaction struct {
	TransactionID   string
	RequestID       string
	ParentRequestID string
}
