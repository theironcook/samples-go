package transaction

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"io"
)

// uuid represents a UUID, as defined by RFC 4122.
type uuid [16]byte

// newUUIDv4 generates a random (version 4) UUID. It panics if random bytes
// cannot be obtained from the system (though this case should be exceptionally
// rare in practice).
//
// The implementation is based on github.com/google/uuid:
// https://github.com/google/uuid/blob/dec09d789f3dba190787f8b4454c7d3c936fed9e/version4.go#L29
func newUUIDv4() uuid {
	var uuid uuid
	_, err := io.ReadFull(rand.Reader, uuid[:])
	if err != nil {
		panic(fmt.Errorf("failed to generate UUIDv4: %v", err))
	}

	uuid[6] = (uuid[6] & 0x0f) | 0x40 // Version 4
	uuid[8] = (uuid[8] & 0x3f) | 0x80 // Variant is 10
	return uuid
}

// String returns the hex-encoded string form of this UUID.
//
// The implementation is based on github.com/google/uuid:
// https://github.com/google/uuid/blob/dec09d789f3dba190787f8b4454c7d3c936fed9e/uuid.go#L117
func (uuid uuid) String() string {
	var dst [36]byte

	hex.Encode(dst[:], uuid[:4])
	dst[8] = '-'
	hex.Encode(dst[9:13], uuid[4:6])
	dst[13] = '-'
	hex.Encode(dst[14:18], uuid[6:8])
	dst[18] = '-'
	hex.Encode(dst[19:23], uuid[8:10])
	dst[23] = '-'
	hex.Encode(dst[24:], uuid[10:])

	return string(dst[:])
}
