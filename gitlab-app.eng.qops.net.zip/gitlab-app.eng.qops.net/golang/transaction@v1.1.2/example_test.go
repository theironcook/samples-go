package transaction_test

import (
	"gitlab-app.eng.qops.net/golang/transaction"
	"net/http"
)

func Example() {
	http.Handle("/", MyHandlerFunc(http.HandlerFunc(HandlerFuncWithDownstreamCall)))
}

func MyHandlerFunc(fn http.HandlerFunc) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		t := transaction.FromRequest(r)

		// Provide info to other handlers
		ctx := transaction.SetOnContext(r.Context(), t)
		fn.ServeHTTP(w, r.WithContext(ctx))
	})
}

func HandlerFuncWithDownstreamCall(w http.ResponseWriter, r *http.Request) {
	// Get transaction from parent handler
	t, ok := transaction.FromContext(r.Context())
	if !ok {
		//No transaction set on context
	}

	// Some logic...

	// Fire off a new request
	req, _ := http.NewRequest("POST", "https://my.downstream.dependency", nil)
	transaction.SetRequestHeaders(req, t)
	// HTTPClient.Do(req)
}
