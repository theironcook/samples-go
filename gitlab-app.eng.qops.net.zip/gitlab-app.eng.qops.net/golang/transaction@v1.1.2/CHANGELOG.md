## v1.1.2 - 2019-02-22
- Added a basic `go.mod` to enable Go modules support (e.g. checkout outside of `$GOPATH`)

## v1.1.1 - 2018-07-19
- Removed dependency on https://github.com/satori/go.uuid for UUIDv4 generation (!4)

## v1.1.0 - 2017-10-04
- Added `SetResponseHeaders` to set the headers for a `Transaction` on a `http.ResponseWriter` (!3)

## v1.0.1 - 2017-08-02
- Fixed setting of `X-Parent-Request-ID` header to match the specification (!2)

## v1.0.0 - 2017-04-06
- Initial release (!1)
