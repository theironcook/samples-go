author: nates@qualtrics.com

[![GoDoc](http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/transaction?status.svg)](http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/transaction)

# Transaction Package
The transaction pkg provides a standard way to gain the benefits of using TransactionIDs as described [here](https://gitlab-app.eng.qops.net/misc/latency/blob/master/Transaction.md). This package provides a struct to represent the standard set of ids and methods for retrieval and storage.

Please refer to the [design doc](design.md) for questions about design.