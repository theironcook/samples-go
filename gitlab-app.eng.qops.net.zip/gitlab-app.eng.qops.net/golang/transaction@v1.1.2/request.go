package transaction

import "net/http"

const (
	headerTransactionID   string = "X-Transaction-ID"
	headerRequestID       string = "X-Request-ID"
	headerParentRequestID string = "X-Parent-Request-ID"
)

// FromRequest will read transaction information from an incoming
// http.Request and generate necessary or missing UUIDs.
func FromRequest(r *http.Request) Transaction {

	// Populate a transaction by reading values directly from headers.
	tx := Transaction{
		TransactionID:   r.Header.Get(headerTransactionID),
		RequestID:       newUUIDv4().String(),
		ParentRequestID: r.Header.Get(headerParentRequestID),
	}

	if tx.TransactionID == "" {
		tx.TransactionID = newUUIDv4().String()
	}

	return tx
}

// SetRequestHeaders will set transaction information on
// an outgoing http.Request using the appropriate headers.
func SetRequestHeaders(r *http.Request, t Transaction) {
	r.Header.Set(headerTransactionID, t.TransactionID)
	r.Header.Set(headerParentRequestID, t.RequestID)
}

// SetResponseHeaders will set transaction information on
// responding http.ResponseWriter using the appropriate headers.
func SetResponseHeaders(w http.ResponseWriter, t Transaction) {
	w.Header().Set(headerTransactionID, t.TransactionID)
	w.Header().Set(headerRequestID, t.RequestID)
}
