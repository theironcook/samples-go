package transaction

import (
	"context"
)

// unexported type and key for context storage
type ctxKeyType string

const ctxKey = ctxKeyType("transaction.context")

// FromContext returns transaction information from a context
func FromContext(c context.Context) (Transaction, bool) {
	v, ok := c.Value(ctxKey).(Transaction)
	if !ok {
		return Transaction{}, false
	}
	return v, true
}

// SetOnContext stores transaction information on a context to
// provide information down the request call stack.
func SetOnContext(c context.Context, t Transaction) context.Context {
	return context.WithValue(c, ctxKey, t)
}
