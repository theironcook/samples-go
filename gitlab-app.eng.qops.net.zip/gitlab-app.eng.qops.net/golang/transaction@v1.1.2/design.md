# Goals

The goals of the transaction package are the following:

1. Provide a standardized way for go microservices to read and write transaction information as a part of a request. The philosophy and reasoning behind transactions are described in detail [here](https://gitlab-app.eng.qops.net/misc/latency/blob/master/Transaction.md). All microservices should be logging transaction information, so this package aims to fill that use case in a standard shareable way.
2. Provide a canonical storage interface for use with contexts. Rather than re-inventing the wheel, services can easily leverage the set and get method to provide transaction information anywhere down the request call stack.