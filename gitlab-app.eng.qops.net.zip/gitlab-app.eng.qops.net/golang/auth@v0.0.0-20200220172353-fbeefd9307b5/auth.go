// Package auth provides a common struct for passing around authn/authz data.
// It used with the accesslog and jwt packages.
package auth

import "context"

type authContextKeyType string

const authContextKey = authContextKeyType("auth")

// SetDataOnContext will store Data on the context to be retreived later with GetDataFromContext
func SetDataOnContext(ctx context.Context, data Data) context.Context {
	return context.WithValue(ctx, authContextKey, data)
}

// GetDataFromContext will get Data from the context that was stored using SetDataFromContext
func GetDataFromContext(ctx context.Context) (Data, bool) {
	d, ok := ctx.Value(authContextKey).(Data)
	return d, ok
}

// These types are the enumerable type of authentication
const (
	TypeJWT      string = "JWT"
	TypeUDS      string = "UDS"
	TypeQToken   string = "QToken"
	TypeAPIToken string = "APIToken"

	// TypeBearerToken identifies an access token provided from XM Connect
	//
	// XM Connect is the Qualtrics implementation of OpenID Connect Core, which
	// "is a simple identity layer on top of the OAuth 2.0 protocol."
	// The spec for OpenID Connect Core can be found at https://openid.net/specs/openid-connect-core-1_0.html
	// The design doc for XM Connect can be found at https://docs.google.com/document/d/1p967NHyaM9fnCKMCNCR0KFJXFxDnvgqJk3Ki3agf6P4
	TypeBearerToken string = "BearerToken"
)

// Data represents the common information needed for authn/authz.
type Data struct {
	Type        string
	BrandID     string
	UserID      string
	JWTIssuer   string
	SessionID   string
	AccountType string
}
