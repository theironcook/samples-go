[![GoDoc](http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/auth?status.svg)](http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/auth)

# Auth Package
The auth pkg provides a common struct for passing around authn/authz data. It used with the [accesslog](http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/http/accesslog) and [jwt](http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/jwt) packages. 
