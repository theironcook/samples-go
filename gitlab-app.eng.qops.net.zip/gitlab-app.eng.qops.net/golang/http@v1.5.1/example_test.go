package http

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"time"

	"gitlab-app.eng.qops.net/golang/transaction"
)

func Example() {
	// Create a default client
	client := NewClient()

	// Set ClientID or QRN to be used by the default client
	DefaultClientID = "foo-service"
	DefaultQRN = os.Getenv("COMPONENT_QRN")

	// Or create a client with optional overrides
	client = NewClient(WithTimeout(30*time.Second), WithTransport(&Transport{
		ClientID: "bar-service",
		QRN:      "qrn:component::qamel-job:bar-service",
	}), WithJar(nil), WithCheckRedirect(nil))

	// Add transaction ids to the context
	ctx := context.Background()
	ctx = transaction.SetOnContext(ctx, transaction.Transaction{
		TransactionID: "123",
	})

	// Create a request
	req, err := http.NewRequest(http.MethodGet, "https://www.google.com", nil)
	if err != nil {
		fmt.Println(err)
		return
	}

	// Make the request
	res, err := client.Do(req.WithContext(ctx))
	if err != nil {
		fmt.Println(err)
		return
	}
	defer res.Body.Close()
}
