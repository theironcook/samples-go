package http

import (
	"net/http"
	"sync"

	"gitlab-app.eng.qops.net/golang/transaction"
)

const (
	headerClientID = "X-Client-ID"
	headerQRN      = "Q-Issuer-Qrn"
)

// Transport uses the standard library http.DefaultTransport but adds transactionID headers to all requests
type Transport struct {
	// DefaultTransport is the underlying roundtripper that actually performs the http request. By default
	// this is `http.DefaultTransport`.
	DefaultTransport http.RoundTripper

	// ClientID indicates the value to use for the `X-Client-ID` header on outbound requests. It should
	// match the following regular expression: `[a-z-_]{3,}`. More info can be found in this doc:
	// https://gitlab-app.eng.qops.net/misc/latency/-/blob/master/Transaction.md#requirements
	// Defaults to `DefaultClientID`
	ClientID string

	// QRN indicates the value to use for the `Q-Issuer-Qrn` header on outbound requests.
	// Defaults to `DefaultQRN`
	QRN  string
	once sync.Once
}

// RoundTrip adds transaction and service-to-service id headers to an http request
func (q *Transport) RoundTrip(req *http.Request) (*http.Response, error) {
	q.once.Do(q.init)

	ctx := req.Context()

	if t, ok := transaction.FromContext(ctx); ok {
		transaction.SetRequestHeaders(req, t)
	}

	q.setS2sIDHeaders(req)

	res, err := q.DefaultTransport.RoundTrip(req)
	return res, err
}

func (q *Transport) setS2sIDHeaders(req *http.Request) {
	if q.ClientID != "" {
		req.Header.Set(headerClientID, q.ClientID)
	}
	if q.QRN != "" {
		req.Header.Set(headerQRN, q.QRN)
	}
}

func (q *Transport) init() {
	if q.DefaultTransport == nil {
		q.DefaultTransport = http.DefaultTransport
	}

	if q.ClientID == "" {
		q.ClientID = DefaultClientID
	}

	if q.QRN == "" {
		q.QRN = DefaultQRN
	}

	q.ClientID = normalizeClientID(q.ClientID)
}
