package http

import (
	"testing"
	"time"
)

func TestNewClient(t *testing.T) {
	client := NewClient()
	if client.Timeout != (time.Second * 15) {
		t.Errorf("Failed to set default timeout want 15, got %d", client.Timeout/time.Second)
	}

	client = NewClient(WithTimeout(30*time.Second), WithTransport(&Transport{}), WithJar(nil), WithCheckRedirect(nil))
	if client.Timeout != (time.Second * 30) {
		t.Errorf("Failed to override default timeout want 15, got %d", client.Timeout/time.Second)
	}
}
