package accesslog

import (
	"io"
	"os"
)

// MustOpenWriter will open a io.WriteCloser for a file using the supplied path or panic.
// Consumers should remember to close the io.WriteCloser
// If path is "" os.Stdout will be returned.
func MustOpenWriter(path string) io.WriteCloser {
	if path == "" {
		return os.Stdout
	}
	f, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, os.ModePerm)
	if err != nil {
		panic(err)
	}
	return f
}
