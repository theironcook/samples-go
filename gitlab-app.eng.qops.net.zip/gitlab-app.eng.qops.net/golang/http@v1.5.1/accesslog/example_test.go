package accesslog_test

import (
	"io"
	"net/http"
	"os"

	"gitlab-app.eng.qops.net/golang/http/accesslog"
	"gitlab-app.eng.qops.net/golang/transaction"
)

func ExampleHandler(h http.Handler, w io.Writer, run func(http.Handler)) {
	// Wrap handler `h` with an accesslog handler that writes logs to `w`
	handler := accesslog.Handler{
		Handler: h,
		Writer:  w,
	}
	run(handler) // Fake method to run your server with the handler
}

func ExampleSet(w http.Response, r *http.Request) {
	// In your Handler
	accesslog.Set(r.Context(), "count.of.foo", 23)
	accesslog.Set(r.Context(), "tag.of.bar", "baz")
}

func ExampleSetReserved(w http.Response, r *http.Request) {
	// In your Handler
	t := transaction.FromRequest(r)
	accesslog.SetReserved(r.Context(), accesslog.TransactionID, t.TransactionID)
	accesslog.SetReserved(r.Context(), accesslog.RequestID, t.RequestID)
	accesslog.SetReserved(r.Context(), accesslog.ParentRequestID, t.ParentRequestID)

	// In your HandlerFunc
	accesslog.SetReserved(r.Context(), accesslog.Name, "my.route.name")
}

func ExampleMustOpenWriter(h http.Handler) {
	// Safe to use os.GetEnv since we want to default to ""
	w := accesslog.MustOpenWriter(os.Getenv("ACCESS_LOG_PATH"))
	defer w.Close()

	// Typically used to create a writer for an accesslog Handler
	alogger := accesslog.Handler{
		Writer:  w,
		Handler: h,
	}

	// Use it somewhere
	http.StripPrefix("/api", alogger)
}
