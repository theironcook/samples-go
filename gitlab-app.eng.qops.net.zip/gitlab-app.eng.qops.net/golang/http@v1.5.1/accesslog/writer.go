package accesslog

import (
	"bytes"
	"encoding/json"
	"fmt"
	"math"
	"strconv"
	"unicode/utf8"

	"github.com/pkg/errors"
)

const (
	_hex = "0123456789abcdef"
)

func writeValueOnWriter(key string, val interface{}, writer *bytes.Buffer) error {

	switch t := val.(type) {
	case bool:
		writeBool(key, t, writer)
	case float32:
		writeFloat64(key, float64(t), writer)
	case float64:
		writeFloat64(key, t, writer)
	case int:
		writeInt64(key, int64(t), writer)
	case int32:
		writeInt64(key, int64(t), writer)
	case int64:
		writeInt64(key, t, writer)
	case uint:
		writeUint64(key, uint64(t), writer)
	case uint32:
		writeUint64(key, uint64(t), writer)
	case uint64:
		writeUint64(key, t, writer)
	case string:
		writeString(key, t, writer)
	case json.Number:
		intVal, intErr := t.Int64()
		if intErr == nil {
			writeInt64(key, intVal, writer)
			return nil
		}
		floatVal, floatErr := t.Float64()
		if floatErr == nil {
			writeFloat64(key, floatVal, writer)
			return nil
		}
		writeString(key, t.String(), writer) //Same as fmt.Stringer
	case json.Marshaler:
		return writeMarshaler(key, t, writer)
	case json.RawMessage:
		return writeMarshaler(key, &t, writer)
	case fmt.Stringer:
		writeString(key, t.String(), writer)
	case error:
		writeString(key, t.Error(), writer)
	default:
		writeKey(key, writer)
		data, err := json.Marshal(t)
		if err != nil {
			return errors.Wrapf(err, "Error json marshalling value with key %s and type: %T", key, t)
		}
		writer.Write(data)
		return nil
	}
	return nil
}

func writeBool(key string, val bool, writer *bytes.Buffer) {
	writeKey(key, writer)
	writer.WriteString(strconv.FormatBool(val))
}

func writeFloat64(key string, val float64, writer *bytes.Buffer) {
	writeKey(key, writer)
	switch {
	case math.IsNaN(val):
		writer.WriteString(`"NaN"`)
	case math.IsInf(val, 1):
		writer.WriteString(`"+Inf"`)
	case math.IsInf(val, -1):
		writer.WriteString(`"-Inf"`)
	default:
		writer.WriteString(strconv.FormatFloat(val, 'f', -1, 64))
	}
}
func writeInt64(key string, val int64, writer *bytes.Buffer) {
	writeKey(key, writer)
	writer.WriteString(strconv.FormatInt(val, 10))
}

func writeUint64(key string, val uint64, writer *bytes.Buffer) {
	writeKey(key, writer)
	writer.WriteString(strconv.FormatUint(val, 10))
}
func writeString(key, val string, writer *bytes.Buffer) {
	writeKey(key, writer)
	writer.WriteByte('"')
	safeWriteString(val, writer)
	writer.WriteByte('"')
}
func writeMarshaler(key string, obj json.Marshaler, writer *bytes.Buffer) error {
	writeKey(key, writer)
	objData, err := obj.MarshalJSON()
	if err != nil {
		return errors.Wrap(err, "Error marshaling value for access log")
	}
	writer.Write(objData)
	return nil
}

func writeKey(key string, writer *bytes.Buffer) {
	if writer.Len() > 0 {
		writer.WriteByte(',')
	}
	writer.WriteByte('"')
	safeWriteString(key, writer)
	writer.WriteByte('"')
	writer.WriteByte(':')
}

func safeWriteString(s string, writer *bytes.Buffer) {
	for i := 0; i < len(s); {
		if b := s[i]; b < utf8.RuneSelf {
			i++
			if 0x20 <= b && b != '\\' && b != '"' {
				writer.WriteByte(b)
				continue
			}
			switch b {
			case '\\', '"':
				writer.WriteByte('\\')
				writer.WriteByte(b)
			case '\n':
				writer.WriteByte('\\')
				writer.WriteByte('n')
			case '\r':
				writer.WriteByte('\\')
				writer.WriteByte('r')
			case '\t':
				writer.WriteByte('\\')
				writer.WriteByte('t')
			default:
				writer.WriteString(`\u00`)
				writer.WriteByte(_hex[b>>4])
				writer.WriteByte(_hex[b&0xF])
			}
			continue
		}
		c, size := utf8.DecodeRuneInString(s[i:])
		if c == utf8.RuneError && size == 1 {
			writer.WriteString(`\ufffd`)
			i++
			continue
		}
		writer.WriteString(s[i : i+size])
		i += size
	}
}
