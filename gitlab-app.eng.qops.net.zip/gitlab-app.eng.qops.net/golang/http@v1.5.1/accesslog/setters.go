package accesslog

import (
	"context"
)

type reservedKey string

// These constants are used with SetReserved.
const (
	Name            reservedKey = "id"
	TransactionID   reservedKey = "transactionId"
	RequestID       reservedKey = "requestId"
	ParentRequestID reservedKey = "parentRequestId"
	AuthType        reservedKey = "authType"
	BrandID         reservedKey = "brandId"
	UserID          reservedKey = "userId"
	JWTIssuer       reservedKey = "issuer"
	Bytes           reservedKey = "bytes"
	BytesIn         reservedKey = "bytesIn"
	Status          reservedKey = "status"
)

// Set will set a key and value on the access log under a `meta` namespace in the JSON.
// Note that the Set func doesn't deduplicate keys, so it's possible to produce a
// log like
//
//	{"foo":"bar","foo":"baz"}
//
// This is permitted by the JSON specification, but not encouraged. Many
// libraries will ignore duplicate key-value pairs (typically keeping the last
// pair) when unmarshaling, but users should attempt to avoid adding duplicate
// keys. Set is safe to use concurrently.
func Set(ctx context.Context, key string, value interface{}) (bool, error) {
	accessLog, ok := AccessLogFromContext(ctx)
	if !ok {
		return false, nil
	}
	return true, accessLog.Set(key, value)
}

// SetReserved will set a key and value on the access log under a root namespace in the JSON.
// Note that the SetReserved func doesn't deduplicate keys, so it's possible to produce a
// log like
//
//	{"brandId":"one","brandId":"two"}
//
// This is permitted by the JSON specification, but not encouraged. Many
// libraries will ignore duplicate key-value pairs (typically keeping the last
// pair) when unmarshaling, but users should attempt to avoid adding duplicate
// keys. SetReserved is safe to use concurrently.
func SetReserved(ctx context.Context, key reservedKey, value interface{}) (bool, error) {
	accessLog, ok := AccessLogFromContext(ctx)
	if !ok {
		return false, nil
	}
	return true, accessLog.SetReserved(key, value)
}
