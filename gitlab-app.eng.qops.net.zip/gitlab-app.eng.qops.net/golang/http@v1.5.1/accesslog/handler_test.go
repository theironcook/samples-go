package accesslog

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"math"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/pkg/errors"
	"gitlab-app.eng.qops.net/golang/auth"
	"gitlab-app.eng.qops.net/golang/metrics/v2"
	"gitlab-app.eng.qops.net/golang/transaction"
)

type mockResponseWriter struct {
	Status  int
	Length  int
	Headers http.Header

	wroteHeader bool
	calledFlush bool
}

func (rw *mockResponseWriter) GetStatus() int {
	if !rw.wroteHeader {
		return http.StatusOK
	}
	return rw.Status
}

func (rw *mockResponseWriter) Header() http.Header {
	if rw.Headers == nil {
		rw.Headers = http.Header(make(map[string][]string))
	}
	return rw.Headers
}

func (rw *mockResponseWriter) Write(data []byte) (int, error) {
	rw.Length += len(data)
	return len(data), nil
}

func (rw *mockResponseWriter) WriteHeader(status int) {
	rw.wroteHeader = true
	rw.Status = status
}

func (rw *mockResponseWriter) Flush() {
	rw.calledFlush = true
}

type mockHandler struct {
	statusCode int
	body       []byte
	cb         func(*http.Request)
}

func (mock *mockHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	mock.cb(r)

	if mock.statusCode != 0 {
		w.WriteHeader(mock.statusCode)
	}
	if mock.body != nil && len(mock.body) > 0 {
		w.Write(mock.body)
	}
}

func handleMockRequest(req *http.Request, h http.Handler, writer io.Writer, cb func(r *http.Request)) {
	accessLogger := &Handler{
		Writer:  writer,
		Handler: h,
	}
	// create a mock response writer
	responseWriter := mockResponseWriter{}
	// simulate a request
	accessLogger.ServeHTTP(&responseWriter, req)
}

func makeMockRequest(req *http.Request, status int, body []byte, writer io.Writer, cb func(r *http.Request)) {
	// create a mock handler
	handler := &mockHandler{status, body, cb}
	handleMockRequest(req, handler, writer, cb)
}

func TestServeHTTPWithoutWriter(t *testing.T) {
	defer func() {
		if r := recover(); r == nil {
			t.Errorf("Expected ServeHTTP to panic without Writer")
		}
	}()

	h := &Handler{
		Handler: &mockHandler{},
	}
	r, _ := http.NewRequest(http.MethodGet, "/my/url", nil)
	w := httptest.NewRecorder()

	h.ServeHTTP(w, r)
}

func TestServeHTTPWithoutHandler(t *testing.T) {
	defer func() {
		if r := recover(); r == nil {
			t.Errorf("Expected ServeHTTP to panic without Handler")
		}
	}()

	h := &Handler{
		Writer: ioutil.Discard,
	}
	r, _ := http.NewRequest(http.MethodGet, "/my/url", nil)
	w := httptest.NewRecorder()

	h.ServeHTTP(w, r)
}

func TestSetWithInvalidContext(t *testing.T) {
	if ok, _ := Set(context.Background(), "foo", "bar"); ok {
		t.Fatal("Expected false when calling Set with invalid Context")
	}
}

func TestBareBonesAccessLog(t *testing.T) {
	body := []byte("mybody")
	r, _ := http.NewRequest(http.MethodGet, "/myurl", nil)

	var buf bytes.Buffer

	makeMockRequest(r, http.StatusNotFound, body, &buf, func(r *http.Request) {})

	actual := buf.String()
	contains1 := ` [access] {"httpVersion":"1.1","url":"","method":"GET",`

	if !strings.Contains(actual, contains1) {
		t.Fatalf("Expected Response\n%s\nTo Contain\n%s\n", actual, contains1)
	}

	contains2 := `","status":404,"bytesIn":0,"bytes":6,"time":`

	if !strings.Contains(actual, contains2) {
		t.Fatalf("Expected Response\n%s\nTo Contain\n%s\n", actual, contains2)
	}

	ending := `}
`

	if !strings.HasSuffix(actual, ending) {
		t.Fatalf("Expected Response\n%s\nTo End With\n%s\n", actual, ending)
	}
}

func TestHEADAccessLog(t *testing.T) {
	body := []byte("mybody")
	r, err := http.NewRequest("HEAD", "/myurl", nil)
	if err != nil {
		t.Fatal(err)
	}

	var buf bytes.Buffer

	makeMockRequest(r, http.StatusNotFound, body, &buf, func(r *http.Request) {})

	actual := buf.String()
	contains1 := ` [access] {"httpVersion":"1.1","url":"","method":"HEAD","clientId":"unknown","status":`

	if !strings.Contains(actual, contains1) {
		t.Fatalf("Expected Response\n%s\nTo Contain\n%s\n", actual, contains1)
	}

	contains2 := `","status":404,"bytesIn":0,"bytes":0,"time":`

	if !strings.Contains(actual, contains2) {
		t.Fatalf("Expected Response\n%s\nTo Contain\n%s\n", actual, contains2)
	}

	ending := `}
`

	if !strings.HasSuffix(actual, ending) {
		t.Fatalf("Expected Response\n%s\nTo End With\n%s\n", actual, ending)
	}
}

func TestFullAccessLog(t *testing.T) {
	body := []byte("mybody")
	r, _ := http.NewRequest(http.MethodGet, "/myurl", nil)
	r.RemoteAddr = "four"
	r.Header.Add("X-Forwarded-For", "one , two , three")
	r.Header.Add("Referer", "my.referer")
	r.Header.Add("User-Agent", "my.user.agent")
	r.Header.Add("X-Transaction-ID", "TID-01")
	r.Header.Add("X-Parent-Request-ID", "RID-01")

	var buf bytes.Buffer

	makeMockRequest(r, http.StatusOK, body, &buf, func(r *http.Request) {
		name := "my.route.name"
		SetReserved(r.Context(), Name, name)

		Set(r.Context(), "bool", true)

		t := transaction.FromRequest(r)
		SetReserved(r.Context(), TransactionID, t.TransactionID)
		SetReserved(r.Context(), ParentRequestID, t.ParentRequestID)
		SetReserved(r.Context(), RequestID, t.RequestID)

		d := auth.Data{
			Type:      auth.TypeJWT,
			BrandID:   "mybrand",
			UserID:    "UR_01",
			JWTIssuer: "me",
		}
		SetReserved(r.Context(), AuthType, d.Type)
		SetReserved(r.Context(), JWTIssuer, d.JWTIssuer)
		SetReserved(r.Context(), BrandID, d.BrandID)
		SetReserved(r.Context(), UserID, d.UserID)

		var flt32 float32
		flt32 = 12.32
		Set(r.Context(), "float32", flt32)
		var flt64 float64
		flt64 = 12.64
		Set(r.Context(), "float64", flt64)

		Set(r.Context(), "NaN", math.NaN())
		Set(r.Context(), "+Inf", math.Inf(1))
		Set(r.Context(), "-Inf", math.Inf(-1))

		var i int
		i = -16
		Set(r.Context(), "int", i)
		var i32 int32
		i32 = -32
		Set(r.Context(), "int32", i32)
		var i64 int64
		i64 = -64
		Set(r.Context(), "int64", i64)

		var ui uint
		ui = 16
		Set(r.Context(), "uint", ui)
		var ui32 uint32
		ui32 = 32
		Set(r.Context(), "uint32", ui32)
		var ui64 uint64
		ui64 = 64
		Set(r.Context(), "uint64", ui64)

		Set(r.Context(), "string1", `\\\r\n\t®string1\`)
		Set(r.Context(), "string2", "\\\r\n\t®string2")

		Set(r.Context(), "fmt.Stringer", &stringable{})

		Set(r.Context(), "json.Marshaler", &marshalable{})
		var raw json.RawMessage = []byte(`{"raw":"message"}`)
		Set(r.Context(), "json.Marshaler", raw)

		Set(r.Context(), "error", errors.New("my.error"))

		var jsonString json.Number = "json.Number.string"
		Set(r.Context(), "jsonString", jsonString)
		var jsonInt json.Number = "25"
		Set(r.Context(), "jsonInt", jsonInt)
		var jsonFloat json.Number = "25.6"
		Set(r.Context(), "jsonFloat", jsonFloat)

		slice1 := []string{"part1", "part2"}
		slice2 := []int{1, 2}
		Set(r.Context(), "slice1", slice1)
		Set(r.Context(), "slice2", slice2)
	})

	var contains string
	actual := buf.String()

	contains = ` [access] {"clientIp":"one","httpVersion":"1.1","url":"","method":"GET","userAgent":"my.user.agent","referer":"my.referer","via":"two, three, four"`
	if !strings.Contains(actual, contains) {
		t.Fatalf("Expected Response\n%s\nTo Contain\n%s\n", actual, contains)
	}

	contains = `,"transactionId":"TID-01","parentRequestId":"RID-01","requestId":`
	if !strings.Contains(actual, contains) {
		t.Fatalf("Expected Response\n%s\nTo Contain\n%s\n", actual, contains)
	}

	contains = `,"authType":"JWT","issuer":"me","brandId":"mybrand","userId":"UR_01"`
	if !strings.Contains(actual, contains) {
		t.Fatalf("Expected Response\n%s\nTo Contain\n%s\n", actual, contains)
	}

	contains = `,"status":200,"bytesIn":0,"bytes":6,"time":`
	if !strings.Contains(actual, contains) {
		t.Fatalf("Expected Response\n%s\nTo Contain\n%s\n", actual, contains)
	}

	ending := `,"meta":{"bool":true,"float32":12.319999694824219,"float64":12.64,"NaN":"NaN","+Inf":"+Inf","-Inf":"-Inf","int":-16,"int32":-32,"int64":-64,"uint":16,"uint32":32,"uint64":64,"string1":"\\\\\\r\\n\\t®string1\\","string2":"\\\r\n\t®string2","fmt.Stringer":"i.am.a.fmt.stringer","json.Marshaler":{"key":"i.am.a.json.marshaler"},"json.Marshaler":{"raw":"message"},"error":"my.error","jsonString":"json.Number.string","jsonInt":25,"jsonFloat":25.6,"slice1":["part1","part2"],"slice2":[1,2]}}
`
	if !strings.HasSuffix(actual, ending) {
		t.Fatalf("Expected Response\n%s\nTo End With\n%s\n", actual, ending)
	}
}

func TestMonitoredReadCloser(t *testing.T) {
	cases := []struct {
		ReadCloser     io.ReadCloser
		ExpectedLength int
		ReadFunc       func(io.ReadCloser)
	}{
		{
			ReadCloser:     ioutil.NopCloser(strings.NewReader("hello world")),
			ExpectedLength: 11,
			ReadFunc: func(rc io.ReadCloser) {
				n, err := io.Copy(ioutil.Discard, rc)
				fmt.Println(n, err)
			},
		},
		{
			ReadCloser:     ioutil.NopCloser(strings.NewReader("hello world")),
			ExpectedLength: 5,
			ReadFunc: func(rc io.ReadCloser) {
				io.Copy(ioutil.Discard, io.LimitReader(rc, 5))
			},
		},
	}

	for i, c := range cases {

		mrc := &MonitoredReadCloser{ReadCloser: c.ReadCloser}

		// do the test
		c.ReadFunc(mrc)

		if length := mrc.Length(); length != c.ExpectedLength {
			t.Errorf("[case %d] unexpected length: expected %d but got %d", i, c.ExpectedLength, length)
		}

	}
}

func TestMonitoredResponseWriter(t *testing.T) {
	cases := []struct {
		Handler        http.Handler
		ExpectedStatus int
		ExpectedLength int
	}{
		{
			Handler: &mockHandler{
				statusCode: 0,
				body:       []byte("hello world"),
				cb:         func(r *http.Request) {},
			},
			ExpectedStatus: http.StatusOK,
			ExpectedLength: 11,
		},
		{
			Handler: &mockHandler{
				statusCode: 0,
				body:       nil,
				cb:         func(r *http.Request) {},
			},
			ExpectedStatus: http.StatusOK,
			ExpectedLength: 0,
		},
		{
			Handler: &mockHandler{
				statusCode: 404,
				body:       nil,
				cb:         func(r *http.Request) {},
			},
			ExpectedStatus: http.StatusNotFound,
			ExpectedLength: 0,
		},
	}

	for i, c := range cases {

		mrw := &MonitoredResponseWriter{ResponseWriter: &mockResponseWriter{}}

		accessLogger := &Handler{Writer: ioutil.Discard, Handler: c.Handler}
		accessLogger.ServeHTTP(mrw, httptest.NewRequest("GET", "/foo/bar", nil))

		if mrw.Status() != c.ExpectedStatus {
			t.Errorf("[case %d] unexpected status: expected %d but got %d", i, c.ExpectedStatus, mrw.Status())
		}

		if mrw.Length() != c.ExpectedLength {
			t.Errorf("[case %d] unexpected length: expected %d but got %d", i, c.ExpectedLength, mrw.Length())
		}

	}
}

func TestMonitoredResponseWriterFlush(t *testing.T) {
	mw := &mockResponseWriter{}
	var f http.Flusher = &MonitoredResponseWriter{ResponseWriter: mw}
	if mw.calledFlush {
		t.Fatal("mockResponseWriter.calledFlush should be false to start")
	}
	f.Flush()
	if !mw.calledFlush {
		t.Fatal("monitoredResponseWriter.Flush should pass through to the underlying http.Flusher")
	}
}

type mockTimer struct{}

func (t *mockTimer) Record() {}

// A DiscardReporter implements the Reporter interface by providing a null sink.
type mockReporter struct {
	recordTimingCallCount int
}

func (r *mockReporter) IncCounter(name string, tags ...metrics.Meta)                 {}
func (r *mockReporter) AddToCounter(name string, value int64, tags ...metrics.Meta)  {}
func (r *mockReporter) UpdateGauge(name string, value float64, tags ...metrics.Meta) {}
func (r *mockReporter) RecordHistogram(name string, v float64, tags ...metrics.Meta) {}
func (r *mockReporter) RecordTiming(name string, d time.Duration, tags ...metrics.Meta) {
	r.recordTimingCallCount++
}

func (r *mockReporter) NewTimer(name string, tags ...metrics.Meta) metrics.Timer {
	return &mockTimer{}
}
func (r *mockReporter) Flush()       {}
func (r *mockReporter) Close() error { return nil }

func TestOptionalReporterOnHandler(t *testing.T) {
	r, _ := http.NewRequest(http.MethodGet, "/myurl", nil)
	m := &mockReporter{}
	metrics.DefaultReporter = m
	makeMockRequest(r, http.StatusNotFound, []byte("mybody"), bytes.NewBuffer([]byte{}), func(r *http.Request) {})
	metrics.DefaultReporter = metrics.DefaultReporter

	if m.recordTimingCallCount != 1 {
		t.Error("expected metrics reporter to have been called")
	}
}
