package accesslog

import (
	"bytes"
	"fmt"
	"io/ioutil"
	"net/http"
	"strings"
	"sync"
	"testing"

	"gitlab-app.eng.qops.net/golang/auth"
	"gitlab-app.eng.qops.net/golang/transaction"
)

type stringable struct{}

func (s stringable) String() string {
	return "i.am.a.fmt.stringer"
}

type marshalable struct{}

func (s marshalable) MarshalJSON() ([]byte, error) {
	return []byte(`{"key":"i.am.a.json.marshaler"}`), nil
}

type marshalableStringable struct{}

func (s marshalableStringable) MarshalJSON() ([]byte, error) {
	return []byte(`{"key":"i.am.also.a.json.marshaler"}`), nil
}

func (s marshalableStringable) String() string {
	return "i.am.also.a.fmt.stringer"
}

func TestFlushToNil(t *testing.T) {
	r, _ := http.NewRequest(http.MethodGet, "/muyrl", nil)
	alog := New(r)
	if err := alog.Flush(nil); err == nil {
		t.Fatal("Expected error when flushing access log to nil")
	}
}

func TestJSONMarshalerPrioritiyOverStringer(t *testing.T) {
	r, _ := http.NewRequest(http.MethodGet, "/muyrl", nil)
	alog := New(r)
	alog.Set("marshalableStringable", &marshalableStringable{})
	var buf bytes.Buffer

	if err := alog.Flush(&buf); err != nil {
		t.Fatal("Unexpected error when flushing access log")
	}
	if !strings.HasSuffix(buf.String(), `"meta":{"marshalableStringable":{"key":"i.am.also.a.json.marshaler"}}}
`) {
		t.Fatal("json.Marshaler should have priority over fmt.Stringer")
	}
}

func TestSettingReservedKeyWithInvalidValue(t *testing.T) {
	r, _ := http.NewRequest("GET", "/muyrl", nil)
	alog := New(r)
	err := alog.Set("mychan", make(chan bool))
	if err == nil {
		t.Fatal("Expected error from setting a reserved key with an invalid value")
	}
}

func TestSettingTransactionData(t *testing.T) {
	r, _ := http.NewRequest(http.MethodGet, "/muyrl", nil)
	parentRequestID := "43423432432-32423432432-43223"
	r.Header.Set("X-Parent-Request-ID", parentRequestID)
	alog := New(r)

	transaction := transaction.FromRequest(r)
	alog.SetReserved(TransactionID, transaction.TransactionID)
	alog.SetReserved(ParentRequestID, transaction.ParentRequestID)
	alog.SetReserved(RequestID, transaction.RequestID)

	var buf bytes.Buffer
	if alog.Flush(&buf) != nil {
		t.Fatal("unexpected error when flushing for TestSettingTransactionData")
	}

	logStr := buf.String()

	if !strings.Contains(logStr, `"transactionId":"`+transaction.TransactionID) {
		t.Fatal("expected log to have transaction id")
	}
	if !strings.Contains(logStr, `"requestId":"`+transaction.RequestID) {
		t.Fatal("expected log to have request id")
	}
	if !strings.Contains(logStr, `"parentRequestId":"`+parentRequestID) {
		t.Fatal("expected log to have parent request id")
	}
}

func TestSettingJWTAuthData(t *testing.T) {
	r, _ := http.NewRequest(http.MethodGet, "/muyrl", nil)
	alog := New(r)

	data := auth.Data{
		Type:      auth.TypeJWT,
		BrandID:   "mybrand",
		UserID:    "UR_01",
		JWTIssuer: "myservice",
		SessionID: "79127839834",
	}
	alog.SetReserved(AuthType, data.Type)
	alog.SetReserved(BrandID, data.BrandID)
	alog.SetReserved(UserID, data.UserID)
	alog.SetReserved(JWTIssuer, data.JWTIssuer)

	var buf bytes.Buffer
	if alog.Flush(&buf) != nil {
		t.Fatal("unexpected error when flushing for TestSettingAuthData")
	}

	logStr := buf.String()

	if !strings.Contains(logStr, `"authType":"`+string(data.Type)) {
		t.Fatal("expected log to have auth type")
	}
	if !strings.Contains(logStr, `"brandId":"`+data.BrandID) {
		t.Fatal("expected log to have brand id")
	}
	if !strings.Contains(logStr, `"userId":"`+data.UserID) {
		t.Fatal("expected log to have user id")
	}
	if !strings.Contains(logStr, `"issuer":"`+data.JWTIssuer) {
		t.Fatal("expected log to have jwt issuer")
	}
	if strings.Contains(logStr, data.SessionID) {
		t.Fatal("expected log to NOT have session id")
	}
}

func TestSettingUDSAuthData(t *testing.T) {
	r, _ := http.NewRequest(http.MethodGet, "/muyrl", nil)
	alog := New(r)

	data := auth.Data{
		Type:      auth.TypeUDS,
		SessionID: "79127839834",
	}
	alog.SetReserved(AuthType, data.Type)

	var buf bytes.Buffer
	if alog.Flush(&buf) != nil {
		t.Fatal("unexpected error when flushing for TestSettingAuthData")
	}

	logStr := buf.String()

	if !strings.Contains(logStr, `"authType":"`+string(data.Type)) {
		t.Fatal("expected log to have auth type")
	}
	if strings.Contains(logStr, `"brandId":"`+data.BrandID) {
		t.Fatal("expected log to NOT have brand id")
	}
	if strings.Contains(logStr, `"userId":"`+data.UserID) {
		t.Fatal("expected log to NOT have user id")
	}
	if strings.Contains(logStr, `"issuer":"`+data.JWTIssuer) {
		t.Fatal("expected log to NOT have jwt issuer")
	}
	if strings.Contains(logStr, data.SessionID) {
		t.Fatal("expected log to NOT have session id")
	}
}

func TestGetClientID(t *testing.T) {
	cases := []struct {
		name             string
		r                *http.Request
		expectedClientID string
	}{
		{
			name: "should use QRN if provided",
			r: &http.Request{
				Header: map[string][]string{
					"Q-Issuer-Qrn": {"qrn:component::qamel-job:bar-service"},
					"X-Client-Id":  {"foo-service"},
					"X-Jwt":        {"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJteWlzcyIsImF1ZCI6ImxhcGkiLCJleHAiOjE2ODM3MjkzMDIsIm1ldGhvZCI6IlBPU1QiLCJ1cmxIYXNoIjoiSWIyS0dCYlIwVTBpdmJYMlJWeGplcFhxX3RZbmthMGR0aWZ3OEt6SWxMdyIsInVzZXJJZCI6IlVSXzBTeHJrUDJxSVNHcVlhOSIsImJyYW5kSWQiOiJqdXN0aW5yIiwiYm9keUhhc2giOiJyTGNqcjl4bkthWkpOY05zamNlbXZ2d3JBVklabmxWZDE5Ymp5TVVTNmhFIn0.-uuEQbkXEtlsuyed8Nvg80FkQC4CSeQXtx3avy5ZmD8"},
				},
			},
			expectedClientID: "qrn:component::qamel-job:bar-service",
		},
		{
			name: "should use clientID if QRN not provided",
			r: &http.Request{
				Header: map[string][]string{
					"X-Client-Id": {"foo-service"},
					"X-Jwt":       {"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJteWlzcyIsImF1ZCI6ImxhcGkiLCJleHAiOjE2ODM3MjkzMDIsIm1ldGhvZCI6IlBPU1QiLCJ1cmxIYXNoIjoiSWIyS0dCYlIwVTBpdmJYMlJWeGplcFhxX3RZbmthMGR0aWZ3OEt6SWxMdyIsInVzZXJJZCI6IlVSXzBTeHJrUDJxSVNHcVlhOSIsImJyYW5kSWQiOiJqdXN0aW5yIiwiYm9keUhhc2giOiJyTGNqcjl4bkthWkpOY05zamNlbXZ2d3JBVklabmxWZDE5Ymp5TVVTNmhFIn0.-uuEQbkXEtlsuyed8Nvg80FkQC4CSeQXtx3avy5ZmD8"},
				},
			},
			expectedClientID: "foo-service",
		},
		{
			name: "should use jwt iss if QRN and clientID not provided",
			r: &http.Request{
				Header: map[string][]string{
					"X-Jwt": {"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJteWlzcyIsImF1ZCI6ImxhcGkiLCJleHAiOjE2ODM3MjkzMDIsIm1ldGhvZCI6IlBPU1QiLCJ1cmxIYXNoIjoiSWIyS0dCYlIwVTBpdmJYMlJWeGplcFhxX3RZbmthMGR0aWZ3OEt6SWxMdyIsInVzZXJJZCI6IlVSXzBTeHJrUDJxSVNHcVlhOSIsImJyYW5kSWQiOiJqdXN0aW5yIiwiYm9keUhhc2giOiJyTGNqcjl4bkthWkpOY05zamNlbXZ2d3JBVklabmxWZDE5Ymp5TVVTNmhFIn0.-uuEQbkXEtlsuyed8Nvg80FkQC4CSeQXtx3avy5ZmD8"},
				},
			},
			expectedClientID: "myiss",
		},
		{
			name: "should use unknown if JWT is invalid",
			r: &http.Request{
				Header: map[string][]string{
					"X-Jwt": {"invalid"},
				},
			},
			expectedClientID: clientIDUnknown,
		},
		{
			name:             "should use unknown if jwt iss, QRN, and clientID not provided",
			r:                &http.Request{},
			expectedClientID: clientIDUnknown,
		},
	}
	for _, tt := range cases {
		t.Run(tt.name, func(t *testing.T) {
			actual := getClientID(tt.r)
			if actual != tt.expectedClientID {
				t.Errorf("expected clientID to be %s, got %s", tt.expectedClientID, actual)
			}
		})
	}
}

func BenchmarkLogFlush(b *testing.B) {
	r, _ := http.NewRequest(http.MethodGet, "/muyrl", nil)
	b.ResetTimer()

	alog := New(r)
	alog.SetReserved(Name, "my.route.name")

	alog.Set("bool", true)

	var flt32 float32
	flt32 = 12.32
	alog.Set("float32", flt32)
	var flt64 float64
	flt64 = 12.64
	alog.Set("float64", flt64)

	var i int
	i = -16
	alog.Set("int", i)
	var i32 int32
	i32 = -32
	alog.Set("int32", i32)
	var i64 int64
	i64 = -64
	alog.Set("int64", i64)

	var ui uint
	ui = 16
	alog.Set("uint", ui)
	var ui32 uint32
	ui32 = 32
	alog.Set("uint32", ui32)
	var ui64 uint64
	ui64 = 64
	alog.Set("uint64", ui64)

	alog.Set("string", "foo")

	alog.Set("fmt.Stringer", &stringable{})

	alog.Set("json.Marshaler", &marshalable{})

	alog.Flush(ioutil.Discard)
}

func TestAccessLog_Set(t *testing.T) {
	r, _ := http.NewRequest(http.MethodGet, "/muyrl", nil)

	alog := New(r)

	var wg sync.WaitGroup

	defer func() {
		if r := recover(); r != nil {
			t.Fatalf("unexpected panic: %v", r)
		}
	}()

	for i := 0; i <= 1000; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			if err := alog.Set("same_key", fmt.Sprintf("%d", i)); err != nil {
				t.Errorf("AccessLog.Set() error = %v", err)
			}
		}(i)
	}

	wg.Wait()
}
