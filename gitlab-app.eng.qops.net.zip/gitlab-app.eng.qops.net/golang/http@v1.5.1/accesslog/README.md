author: alexanderh@qualtrics.com, wesb@qualtrics.com

Setting up access logs with `golang/http/accesslog`
===

This guide will walk you through how to set up access logs in your HTTP application that conform to the [Qualtrics latency spec](https://gitlab-app.eng.qops.net/misc/latency/blob/master/README.md).

Click here for the full <a href="http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/http/accesslog"><img src="http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/http/accesslog?status.svg" alt="GoDoc"></a>

## Configuring Hiera

In the Hiera configuration for your app you need to add a `logs` entry whose `log_path` matches an environment variable pass to the docker container.

!!! info "Tip"
	Using `latency` in your `log_category` (aka Sumo source category) name will match a generic Sumologic field extraction rule that will index fields according to the Qualtrics latency spec.


```yaml
docker::apps:
  app:
  	logs:
      <log_name>:
        log_path: /var/log/<service_name>/access
        log_category: <service_name>_latency_access
      ...
      docker_args: >
        -e ACCESS_LOG_PATH=/var/log/<service_name>/access
        ...
```

## Using `golang/http/accesslog`

There are three primary ways to set up access logs:

1. Using the `golang/app/server/http` package which internally uses `golang/http/accesslog`.
2. Mounting the `Handler` from `golang/http/accesslog`.
3. Using the `New` constructor to create an instance of an `AccessLog` from `golang/http/accesslog` in your own custom `http.Handler`.


!!! info "Tip"
	In all three cases the `accesslog.MustOpenWriter` function is helpful in reading the envionment variable set in hiera with a fallack to `os.Stdout` (ie `accessWriter := accesslog.MustOpenWriter(os.Getenv("ACCESS_LOG_PATH"))`).

### Using the `golang/app/server/http` package

When creating an application using the `golang/app` package you can create a new server using the `golang/app/server/http` package. One of the options is `WithAccessLog` which will wrap the provided `http.Handler` with an instance of `Handler` from `golang/http/accesslog`.

```go
import (
	"gitlab-app.eng.qops.net/golang/app"
	httpserver "gitlab-app.eng.qops.net/golang/app/server/http"
)

app.New(
	app.WithServer(addr, httpserver.New(
		httpserver.WithHandler(router),
		httpserver.WithAccessLog(accessWriter),
	)),
)
```

### Mounting the `Handler` struct

When serving static files, the method above will create access log entries for requests to static files. If you wish to exclude the static file routes from access logs use this method.

```go
import (
	"gitlab-app.eng.qops.net/golang/app"
	httpserver "gitlab-app.eng.qops.net/golang/app/server/http"
	"gitlab-app.eng.qops.net/golang/http/accesslog"
)

accesslogHandler := &accesslog.Handler{
		Handler: router,
		Writer:  accessWriter,
	}
app.New(
	app.WithServer(addr, httpserver.New(
		httpserver.WithHandler(router),
		httpserver.WithHandler(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			// Don't record an access log if this is a JS/HTML/image asset
			if strings.Contains(r.URL.Path, "assets") {
				router.ServeHTTP(w, r)
			} else {
				accesslogHandler.ServeHTTP(w, r)
			}
		})),
	)),
)
```

### Using the `AccessLog` struct

If you need more control over your access logs or don't want to send timing metrics of each request handled (see [using `metrics.EnableStatsDReporter` when creating a package-level reporter](https://corpus.eng.qops.net/docs/packages_&_service_apis/packages/go/metrics/#package-level-reporter)). 


```go
import (
	"gitlab-app.eng.qops.net/golang/http/accesslog"
)

func (h Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	// other code before responding
	
	ctx := accesslog.NewContextFromAccessLog(r.Context(), accesslog.New(r))
	// wrap and run the request
	h.Handler.ServeHTTP(w, r.WithContext(ctx))

	// other code after responding
}

```

Now your logs can be queried in Sumologic and will have key fields indexed (ie no need to use `| json auto`).