//go:build go1.7
// +build go1.7

// Package accesslog implements the http.Handler interface to wrap existing handlers in order to log access logs according to the Qualtrics Server Access Log Format (https://gitlab-app.eng.qops.net/misc/latency#server-access-logs).
// Logs are written in such a way to minimize allocations.
// Setter functions are provided to write values to the access log.
package accesslog

import (
	"io"
	"net/http"
	"strconv"
	"time"

	"gitlab-app.eng.qops.net/golang/metrics/v2"
)

// Handler wraps another http.Handler and writes the access logs to an io.Writer.
// If a reporter is defined, timing metrics will be sent using the "http_request_time" key

type Handler struct {
	Writer  io.Writer
	Handler http.Handler
	// TODO a status, and duration callback handler (for hooking into stats)
}

// ServerHTTP holds the pre and post handling logic to gather access log data and flush it to the Handler's io.Writer. If an io.Writer or http.Handler is not provided, the method will panic.
func (h Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	start := time.Now()
	accessLog := New(r)
	ctx := NewContextFromAccessLog(r.Context(), accessLog)

	// wrap and run the request
	myW := &MonitoredResponseWriter{ResponseWriter: w}
	myR := &MonitoredReadCloser{ReadCloser: r.Body}
	r = r.WithContext(ctx)
	r.Body = myR
	h.Handler.ServeHTTP(myW, r)

	accessLog.SetReserved(Status, myW.Status())
	accessLog.SetReserved(BytesIn, myR.Length())

	// The stdlib HTTP server special-cases HEAD request handling by eating
	// bytes written to their response[1], which allows it to offer correct
	// HEAD-handling semantics even for non-participating handlers. In these
	// cases, the stdlib does NOT write bytes to the response even if the handler
	// does. We'll account for this the same way here by logging {"bytes":0}.
	//
	// [1] https://github.com/golang/go/blob/release-branch.go1.8/src/net/http/server.go#L349
	if r.Method == http.MethodHead {
		accessLog.SetReserved(Bytes, 0)
	} else { // We use an else otherwise the bytes get added twice to the access log
		accessLog.SetReserved(Bytes, myW.Length())
	}

	accessLog.Flush(h.Writer)

	metrics.RecordTiming(
		"http_request_time",
		time.Since(start),
		metrics.Tag("status_code", strconv.FormatInt(int64(myW.Status()), 10)),
		metrics.Tag("name", accessLog.name),
	)
}

// MonitoredReadCloser is a wrapper around an io.ReadCloser
// allowing access to the body length.
type MonitoredReadCloser struct {
	io.ReadCloser

	length int // total count of bytes read so far
}

func (mr *MonitoredReadCloser) Read(p []byte) (n int, err error) {
	n, err = mr.ReadCloser.Read(p)
	mr.length += n
	return n, err
}

// Length returns the total count of bytes written to the response so far.
func (mr *MonitoredReadCloser) Length() int {
	return mr.length
}

// MonitoredResponseWriter is a wrapper around the http.ResponseWriter
// allowing access to the response status and length.
type MonitoredResponseWriter struct {
	http.ResponseWriter

	wroteHeader bool // reply header has been (logically) written
	status      int  // status code passed to WriteHeader
	length      int  // total count of bytes written so far
}

func (rw *MonitoredResponseWriter) Write(data []byte) (int, error) {
	rw.length += len(data)
	return rw.ResponseWriter.Write(data)
}

func (rw *MonitoredResponseWriter) WriteHeader(status int) {
	rw.wroteHeader = true
	rw.status = status
	rw.ResponseWriter.WriteHeader(status)
}

// Flush will test for the http.Flusher interface in the wrapped ResponseWriter
// and pass through if the http.Flusher interface is satisfied.
func (rw *MonitoredResponseWriter) Flush() {
	// Per the Go documentation: The default HTTP/1.x and HTTP/2 ResponseWriter
	// implementations support Flusher, but ResponseWriter wrappers may not.
	// Handlers should always test for this ability at runtime.
	flushableResponseWriter, ok := rw.ResponseWriter.(http.Flusher)
	if !ok {
		return
	}

	flushableResponseWriter.Flush()
}

// Status imitates the behavior of the stdlib's net/http package, in which an
// http.StatusOK response code is sent if no other status is explicitly set.
func (rw *MonitoredResponseWriter) Status() int {
	if !rw.wroteHeader {
		return http.StatusOK
	}
	return rw.status
}

// Length returns the total count of bytes written to the response so far.
func (rw *MonitoredResponseWriter) Length() int {
	return rw.length
}
