## v2.1.0 (Jan-2022)

Adding the `MonitoredResponseWriter` and `MonitoredReadCloser` types which can be helpful when managing access logs using a custom implementation.

## v2.0.2 (15-Jun-2018)

Making the `MustOpenWriter` func return a `io.WriteCloser` instead of a `io.Writer` so consumers can correctly close the file.

## v2.0.1

This version is a breaking version (sorry). The getter methods for retriving specific data set on the access log were removed since an access log should not be the authoritative source for transaction or auth data. The `Set` func was also change and now there are two setters.

Removed:

- `Set(ctx context.Context, key, value interface{}) error`
- `Get(ctx context.Context, key reservedKey) (string, bool)`
- `NewHandler(writer io.Writer, handler http.Handler) (*Handler, error)`
- `accesslog.Handler` no longer has an embedded `io.Writer`

Added/Changed:

- `Set(ctx context.Context, key string, value interface{}) (bool, error)`
- `SetReserved(ctx context.Context, key reservedKey, value interface{}) (bool, error)`
- `MustOpenFile(path string) io.Writer`
- Added constant `Bytes reservedKey = "bytes"`
- Added constant `BytesIn reservedKey = "bytesIn"`
- Added constant `Status reservedKey = "status"`
- AccessLog is now a public Struct
