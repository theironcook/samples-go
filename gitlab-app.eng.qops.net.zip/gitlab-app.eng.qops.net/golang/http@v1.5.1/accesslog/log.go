package accesslog

import (
	"bufio"
	"bytes"
	"context"
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/golang-jwt/jwt/v4"
	"github.com/pkg/errors"
)

type accessLogKeyT string

const (
	accessLogKey         = accessLogKeyT("gitlab-app.eng.qops.net/golang/log/accesslog.accessLog")
	defaultAccessLogName = "unknown"

	headerClientID = "X-Client-Id"
	headerQRN      = "Q-Issuer-Qrn"
	headerJWT      = "X-JWT"

	clientIDUnknown = "unknown"
)

var jwtParser = jwt.Parser{}

type AccessLog struct {
	reservedDataMu    sync.Mutex
	reservedData      bytes.Buffer
	nonReservedDataMu sync.Mutex
	nonReservedData   bytes.Buffer
	start             time.Time
	name              string
}

// New will create a new AccessLog by pulling pertinant information from the given http.Request.
func New(r *http.Request) *AccessLog {
	alog := &AccessLog{}
	// start a timer
	alog.start = time.Now()
	alog.name = defaultAccessLogName

	// determine the host and via headers
	via := make([]string, 0, 1)
	if r.Header.Get("X-Forwarded-For") != "" {
		via = append(via, strings.Split(r.Header.Get("X-Forwarded-For"), ",")...)
	}
	via = append(via, r.RemoteAddr)
	// trim whitespace from each IP
	for idx, v := range via {
		via[idx] = strings.TrimSpace(v)
	}

	if via[0] != "" {
		writeString("clientIp", via[0], &alog.reservedData)
	}
	writeString("httpVersion", fmt.Sprintf("%d.%d", r.ProtoMajor, r.ProtoMinor), &alog.reservedData)

	writeString("url", r.RequestURI, &alog.reservedData)
	writeString("method", r.Method, &alog.reservedData)

	// add the User Agent if there is one
	if len(r.Header["User-Agent"]) > 0 {
		writeString("userAgent", strings.Join(r.Header["User-Agent"], ", "), &alog.reservedData)
	}
	// add the Referer if there is one
	if len(r.Header["Referer"]) > 0 {
		writeString("referer", strings.Join(r.Header["Referer"], ", "), &alog.reservedData)
	}
	// add the proxy hops if there are any
	if len(via[1:]) > 0 {
		writeString("via", strings.Join(via[1:], ", "), &alog.reservedData)
	}

	// add the clientId
	clientID := getClientID(r)
	if len(clientID) > 0 {
		writeString("clientId", clientID, &alog.reservedData)
	}

	return alog
}

// NewContextFromAccessLog will wrap an existing context.Context using context.WithValue to set the given AccessLog.
func NewContextFromAccessLog(ctx context.Context, alog *AccessLog) context.Context {
	return context.WithValue(ctx, accessLogKey, alog)
}

// AccessLogFromContext return an AccessLog if it exists on the given context.Context.
func AccessLogFromContext(ctx context.Context) (*AccessLog, bool) {
	d, ok := ctx.Value(accessLogKey).(*AccessLog)
	return d, ok
}

// Set will set the key/val on an internal buffer for non-reserved data. It is safe to use concurrently.
func (alog *AccessLog) Set(key string, val interface{}) error {
	alog.nonReservedDataMu.Lock()
	defer alog.nonReservedDataMu.Unlock()
	return writeValueOnWriter(key, val, &alog.nonReservedData)
}

// SetReserved will set the key/val on an internal buffer for reserved data. It is safe to use concurrently.
func (alog *AccessLog) SetReserved(key reservedKey, val interface{}) error {
	if key == Name {
		name, ok := val.(string)
		if !ok {
			return fmt.Errorf("value for key (%s) must be a string, got (%v)", key, val)
		}
		alog.name = name
		return nil
	}
	alog.reservedDataMu.Lock()
	defer alog.reservedDataMu.Unlock()
	return writeValueOnWriter(string(key), val, &alog.reservedData)
}

func (alog *AccessLog) Flush(sink io.Writer) error {
	if sink == nil {
		return errors.New("can't write encoded message a nil Writer")
	}
	buff := bufio.NewWriter(sink)
	defer buff.Flush()
	buff.Write([]byte(time.Now().Format(time.RFC3339Nano)))
	buff.Write([]byte(" [access] {"))

	writeFloat64("time", float64(time.Now().Sub(alog.start))/float64(time.Millisecond), &alog.reservedData)
	writeString(string(Name), alog.name, &alog.reservedData)

	if _, err := io.Copy(buff, &alog.reservedData); err != nil {
		return errors.Wrap(err, "error writing reservedData to provided Writer")
	}

	if alog.nonReservedData.Len() > 0 {
		buff.Write([]byte(`,"meta":{`))
		if _, err := io.Copy(buff, &alog.nonReservedData); err != nil {
			return errors.Wrap(err, "error writing nonReservedData to provided Writer")
		}
		buff.Write([]byte{'}'})
	}

	buff.Write([]byte("}\n"))

	return nil
}

func getClientID(r *http.Request) string {
	if len(r.Header.Get(headerQRN)) > 0 {
		return r.Header.Get(headerQRN)
	}

	if len(r.Header.Get(headerClientID)) > 0 {
		return r.Header.Get(headerClientID)
	}

	jwtVal := r.Header.Get(headerJWT)
	if jwtVal != "" {
		// ParseUnverified is used because the accesslogger doesn't have access to the
		// secret to verify the jwt. This in fine because we just need the iss claim.
		token, _, err := jwtParser.ParseUnverified(jwtVal, jwt.MapClaims{})
		if err != nil {
			// fall back to "unknown"
			return clientIDUnknown
		}
		if token.Claims != nil {
			mapClaims, claimsAreMap := token.Claims.(jwt.MapClaims)
			if !claimsAreMap {
				return clientIDUnknown
			}
			iss, issExists := mapClaims["iss"]
			if !issExists {
				return clientIDUnknown
			}
			issString, issIsString := iss.(string)
			if issIsString {
				return issString
			}
		}
	}

	// fall back to "unknown"
	return clientIDUnknown
}
