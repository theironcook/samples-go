package http

import "strings"

var (
	// DefaultClientID indicates the value to use for the `X-Client-ID` header on outbound requests. It should
	// match the following regular expression: `[a-z-_]{3,}`. More info can be found in this doc:
	// https://gitlab-app.eng.qops.net/misc/latency/-/blob/master/Transaction.md#requirements
	DefaultClientID string

	// DefaultQRN indicates the value to use for the `Q-Issuer-Qrn` header on outbound requests
	DefaultQRN string
)

// opportunity for light transformation. won't return an error, just here to fix any comon issues.
func normalizeClientID(s string) string {
	return strings.ToLower(s)
}
