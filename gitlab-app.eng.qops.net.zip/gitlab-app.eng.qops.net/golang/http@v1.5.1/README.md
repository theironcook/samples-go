author: treverh@qualtrics.com


# HTTP

This repo contians various packages useful for when creating an http client or service.

Packages currently avaiable:

- [http](https://gitlab-app.eng.qops.net/golang/http/tree/master)
- [accesslog](https://gitlab-app.eng.qops.net/golang/http/blob/master/accesslog/)