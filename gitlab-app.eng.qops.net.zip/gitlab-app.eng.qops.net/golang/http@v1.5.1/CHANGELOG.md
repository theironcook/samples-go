## v1.5.1

Updated:

- Downgrade dependency on `github.com/golang-jwt/jwt` to `v4` from `v5` (`v5` requires go 1.18+)

## v1.5.0 (Retracted)

Added:

- `http.Transport` has new `ClientID` and `QRN` fields for specifying values to use for service-to-service identification.
- `http.DefaultClientID` and `http.DefaultQRN` which are used to specify values used by the default `http.Transport` for service-to-service identification.

Updated:

- `accesslog.New(r *http.Request)` adds a `clientId` field based on the inbound request's headers according to the [access log spec](https://gitlab-app.eng.qops.net/misc/latency).

## v1.4.1

Fixed:

- `accesslog.Set`, `accesslog.SetReserved`, `accesslog.AccessLog.Set`, and `accesslog.AccessLog.SetReserved` are now safe for concurrent use.

## v1.4.0

Added:

- `accesslog.MonitoredResponseWriter` and `accesslog.MonitoredReadCloser` types which can be helpful when managing access logs using a custom implementation.

## v1.3.4

Updated:

- The `gitlab-app.eng.qops.net/golang/metrics/v2` dependency was bumped to `v2.1.2` to pull in a vuln fix.

## v1.1.0

This version adds a new constructor for creating a http.Client with sane defaults and a transport that adds transaction information.

Added:

- `NewClient(options ...Option) *http.Client`
- `type Transport`

## v1.0.0

Initial release.
