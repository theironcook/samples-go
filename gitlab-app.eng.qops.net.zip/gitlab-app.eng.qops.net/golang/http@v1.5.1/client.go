// Package http provides a quick way to create an http client that plays well in the Qualtrics ecosystem. It does things like sets a default timeout
// and forwards transaction information.
package http

import (
	"net/http"
	"time"
)

// An Option codifies a piece of configuration that can be applied to NewClient to overwrite default values on the returned *http.Client
type Option func(*http.Client)

// DefaultTimeout defines the default timeout for the http client. Default is 15 seconds.
const DefaultTimeout = 15 * time.Second

// NewClient creates and returns an *http.Client. Optional Options can be passed in to override default behavior.
//
//	Defaults are set as follows:
//		- Transport     - The transport in this package
//		- Timeout       - 15 seconds
//		- Jar           - nil
//		- CheckRedirect - nil
func NewClient(options ...Option) *http.Client {
	client := &http.Client{
		Transport: &Transport{},
		Timeout:   DefaultTimeout,
	}
	for _, option := range options {
		option(client)
	}
	return client
}

// WithTransport configures the Transport property of the *http.Client. The default transport is the transport defined in this package.
func WithTransport(transport http.RoundTripper) Option {
	return Option(func(client *http.Client) {
		client.Transport = transport
	})
}

// WithCheckRedirect configures the CheckRedirect property of the *http.Client. The default is nil.
func WithCheckRedirect(checkRedirect func(req *http.Request, via []*http.Request) error) Option {
	return Option(func(client *http.Client) {
		client.CheckRedirect = checkRedirect
	})
}

// WithJar configures the Jar property of the *http.Client. The default value is nil.
func WithJar(jar http.CookieJar) Option {
	return Option(func(client *http.Client) {
		client.Jar = jar
	})
}

// WithTimeout configures the Timeout property of the *http.Client. The default value is 15 seconds as defined by the constant in this file.
func WithTimeout(timeout time.Duration) Option {
	return Option(func(client *http.Client) {
		client.Timeout = timeout
	})
}
