package http

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"

	"gitlab-app.eng.qops.net/golang/transaction"
)

func TestRoundTripper(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		trans := transaction.FromRequest(r)
		if trans.TransactionID != "123" {
			t.Errorf("invalid transaction data got '%s', want '123'", trans.TransactionID)
		}

		if r.Header.Get(headerClientID) != "foo-service" {
			t.Errorf("invalid clientID header got '%s', want 'foo-service'", r.Header.Get(headerClientID))
		}

		if r.Header.Get(headerQRN) != "qrn:component::qamel-job:fam-server" {
			t.Errorf("invalid clientID header got '%s', want 'qrn:component::qamel-job:fam-server'", r.Header.Get(headerQRN))
		}

		w.Header().Set("Content-Type", "application/json")
		fmt.Fprint(w, `{"status":"test"}`)
	}))
	defer ts.Close()

	client := &http.Client{
		Transport: &Transport{
			ClientID: "foo-service",
			QRN:      "qrn:component::qamel-job:fam-server",
		},
	}

	ctx := context.Background()
	ctx = transaction.SetOnContext(ctx, transaction.Transaction{
		TransactionID: "123",
	})

	req, err := http.NewRequest(http.MethodGet, ts.URL, nil)
	res, err := client.Do(req.WithContext(ctx))
	if err != nil {
		fmt.Println(err)
		return
	}
	defer res.Body.Close()
}
