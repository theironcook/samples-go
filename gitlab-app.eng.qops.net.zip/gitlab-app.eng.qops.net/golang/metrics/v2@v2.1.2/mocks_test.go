package metrics

import "github.com/alexcesaro/statsd"

type mockClient struct {
	errorhandler  func(error)
	mockClone     func([]statsd.Option)
	mockCount     func(string, interface{})
	mockIncrement func(string)
	mockGauge     func(string, interface{})
	mockHistogram func(string, interface{})
	mockTiming    func(string, interface{})
	mockFlush     func()
	mockClose     func()
}

func (mc *mockClient) Clone(opts ...statsd.Option) *statsd.Client {
	mc.mockClone(opts)
	c, _ := statsd.New(statsd.Mute(true))
	return c
}

func (mc *mockClient) Count(s string, i interface{}) {
	mc.mockCount(s, i)
}

func (mc *mockClient) Increment(s string) {
	mc.mockIncrement(s)
}

func (mc *mockClient) Gauge(s string, i interface{}) {
	mc.mockGauge(s, i)
}

func (mc *mockClient) Histogram(s string, i interface{}) {
	mc.mockHistogram(s, i)
}

func (mc *mockClient) Timing(s string, i interface{}) {
	mc.mockTiming(s, i)
}

func (mc *mockClient) Flush() {
	mc.mockFlush()
}

func (mc *mockClient) Close() {
	mc.mockClose()
}

var _ client = &mockClient{}
