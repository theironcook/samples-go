package metrics_test

import (
	"fmt"

	"gitlab-app.eng.qops.net/golang/metrics/v2"
)

func ExampleTag(reporter metrics.Reporter) {
	reporter.IncCounter(
		"counter_name",
		metrics.Tag("meta_key", "meta_value"),
	)
}

func ExampleEnableDefaultReporter() {
	// In main.main func if metrics are critical
	if err := metrics.EnableDefaultReporter("my_cannonical_service_id"); err != nil {
		panic(err)
	}
	// OR
	// In main.main func if metrics are NOT critical
	if err := metrics.EnableDefaultReporter("my_cannonical_service_id"); err != nil {
		fmt.Printf("unable to connect to statsd: %v", err)
	}
	// OR
	// In main.main func you need to configure the address from an env var
	metrics.EnableDefaultReporter(
		"my_cannonical_service_id",
		metrics.AddressFromEnv("ENV_FOR_TELEGRAF_ADDRESS"),
	)

	// Somewhere in the application
	metrics.IncCounter("my_request", metrics.Tag("foo", "bar"))
}

func ExampleEnableReporter_StatsD() {
	// To configure StatsD metrics using the default StatsD endpoint address ("telegraf:8125")
	sr, err := metrics.NewStatsDReporter(
		"my_cannonical_service_id",
		metrics.AddressFromEnv("ENV_FOR_TELEGRAF_ADDRESS"),
	)

	// OR
	// To explicitly configure the StatsD endpoint address
	sr, err = metrics.NewStatsDReporter(
		"my_cannonical_service_id",
		metrics.Address("telegraf:8125"),
	)

	// OR
	// To explicitly configure the address from an env var (e.g., supposing ENV_FOR_TELEGRAF_ADDRESS=telegraf:8125)
	sr, err = metrics.NewStatsDReporter(
		"my_cannonical_service_id",
		metrics.AddressFromEnv("ENV_FOR_TELEGRAF_ADDRESS"),
	)

	// In main.main, enable the StatsD reporter as the default reporter
	err = metrics.EnableReporter(sr)

	// remember to handle err somehow
	_ = err

	// Somewhere in the application
	metrics.IncCounter("my_request", metrics.Tag("foo", "bar"))
}

func ExampleEnablePrometheusReporter() {
	// To configure Prometheus metrics using the default Prometheus registrator
	pr, err := metrics.NewPrometheusReporter("my_cannonical_service_id")

	// To use customized buckets (instead of `metrics.HistogramBuckets`) for reporting histograms:
	pr, err = metrics.NewPrometheusReporter(
		"my_cannonical_service_id",
		metrics.WithHistogramBuckets([]float64{
			0.1, // 100ms
			0.5, // 500ms
			1.0, // 1s
			5.0, // 5s
		}),
	)

	// In main.main, enable the StatsD reporter as the default reporter
	err = metrics.EnableReporter(pr)

	// remember to handle err somehow
	_ = err

	// Somewhere in the application
	metrics.IncCounter("my_request", metrics.Tag("foo", "bar"))
}
