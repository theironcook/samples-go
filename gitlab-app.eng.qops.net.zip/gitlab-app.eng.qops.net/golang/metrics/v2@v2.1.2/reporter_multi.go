package metrics

import (
	"time"
)

type MultiReporter []Reporter

func (mr MultiReporter) IncCounter(name string, tags ...Meta) {
	for _, r := range mr {
		r.IncCounter(name, tags...)
	}
}

func (mr MultiReporter) AddToCounter(name string, value int64, tags ...Meta) {
	for _, r := range mr {
		r.AddToCounter(name, value, tags...)
	}
}

func (mr MultiReporter) UpdateGauge(name string, value float64, tags ...Meta) {
	for _, r := range mr {
		r.UpdateGauge(name, value, tags...)
	}
}

func (mr MultiReporter) RecordHistogram(name string, v float64, tags ...Meta) {
	for _, r := range mr {
		r.RecordHistogram(name, v, tags...)
	}
}

func (mr MultiReporter) RecordTiming(name string, d time.Duration, tags ...Meta) {
	for _, r := range mr {
		r.RecordTiming(name, d, tags...)
	}
}

type multiTimer []Timer

func (mt multiTimer) Record() {
	for _, t := range mt {
		t.Record()
	}
}

func (mr MultiReporter) NewTimer(name string, tags ...Meta) Timer {
	var mt multiTimer
	for _, r := range mr {
		mt = append(mt, r.NewTimer(name, tags...))
	}
	return mt
}

func (mr MultiReporter) Flush() {
	for _, r := range mr {
		r.Flush()
	}
}

func (mr MultiReporter) Close() error {
	for _, r := range mr {
		if err := r.Close(); err != nil {
			return err
		}
	}
	return nil
}
