author: alexanderh@qualtrics.com, wesb@qualtrics.com

Sending Metrics with `golang/metrics`
===

This guide will walk you through how to configure a Go client to send metrics to the [metrics service](https://odo.corp.qualtrics.com/wiki/index.php/Metrics_As_A_Service).

If you are looking for how to record runtime metrics about your Go application check out the [_____ guide found _____](TODO insert link).

Click here for the full <a href="http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/metrics"><img src="http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/metrics?status.svg" alt="GoDoc"></a>

## Configuring hiera

### For Prometheus metrics

Each production host has a telegraf agent that can be configured to scrape metrics from a local Prometheus endpoint. This requires your app to expose Prometheus metrics at some HTTP endpoint. The example below assumes that metrics are exposed on `localhost:22500/metrics`, as is the case by default for apps built with [`golang/app`](http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/app).

```yaml
role::telegraf::inputs:
  prometheus:
    urls:
      - "http://localhost:22500/metrics"
    name_prefix: "my_service_"
```

Note that Prometheus imposes constraints on legal metric names: they must match the regex `[a-zA-Z_:][a-zA-Z0-9_:]*`. Metric names provided to this package which contain illegal characters will be rewritten with each illegal character replaced by the `_` character. ("Character" here means the Unicode thing, so more precisely: each illegal _rune_ will be replaced by the `_` rune).

### For StatsD metrics

Each production host has a telegraf agent that accepts statsD UDP packets to be forwarded on to the metrics service. In the hiera confiuration for your app you need to add telegraf to the container's host file and inject the local telegraf address as an environment variable.

```yaml
docker::apps:
  app:
      ...
      docker_args: >
        --add-host="telegraf:%{::ipaddress}"
        -e STATS_REPORTER_ADDRESS="telegraf:8125"
```

## Using `golang/metrics`

You can use the the package-level `DefaultReporter` or create an instance of a `Reporter` to be passed to you application's types.

### Package-level Reporter

To use the `DefaultReporter` you need to enable it. In your main func, enable the reporter before your app starts. Note that you will use the environment variable that you configured in hiera.

```go
func main() {
	if err := metrics.EnableDefaultReporter(
	    "my_canonical_service_id",
	    metrics.AddressFromEnv("STATS_REPORTER_ADDRESS"),
	); err != nil {
		fmt.Printf("unable to connect to statsd: %v", err)
	}

	// Ensure that metrics are flushed on shutdown
	defer metrics.DefaultReporter.Close()
}

// Somewhere in the application
metrics.IncCounter("my_request", metrics.Tag("foo", "bar"))
```

!!! warning
    Metrics are buffered before being sent to StatsD. If your application does not close the DefaultReporter before shutdown, some collected metrics may be lost. (In the future, this package's API may be updated to better reflect this.)

Then within your application you can call the other package-level funcs to send metrics.

```go
metrics.IncCounter("my_request", metrics.Tag("foo", "bar"))
// or
defer metrics.NewTimer("http_request", Tag("protocol", "http2")).Record()

```

!!! info
    Note that when a `DefaultReporter` is configured, the `golang/http/accesslog` package will use it to send timing metrics of each request handled. The sent `http_request_time` metric will be tagged with `status_code` and `name` (which is the id/name provided by the consumer with `accesslog.SetReserved(ctx, accesslog.Name, ...)`)

Configuring `DefaultReporter` with `EnableDefaultReporter` results in both a StatsD Reporter and a Prometheus Reporter being configured. To enable only one or the other, configure the desired Reporter explicitly with `EnableReporter`:

```go
// enable only a statsd reporter
if sr, err := metrics.NewStatsDReporter(
    "my_canonical_service_id",
    metrics.AddressFromEnv("STATS_REPORTER_ADDRESS")
); err != nil {
    fmt.Printf("unable to create StatsD reporter: %v", err)
} else if err := metrics.EnableReporter(sr); err != nil {
    fmt.Printf("unable to configure Reporter: %v", err)
}

// enable only a Prometheus reporter
if pr, err := metrics.NewPrometheusReporter("my_canonical_service_id"); err != nil {
    fmt.Printf("unable to create Prometheus reporter: %v", err)
} else if err := metrics.EnableReporter(pr); err != nil {
    fmt.Printf("unable to configure Reporter: %v", err)
}
```

### Reporter Instance

To create an instance of a `Reporter` use either the `NewStatsDReporter` or `NewPrometheusReporter` constructor to obtain a `Reporter`:

```go
reporter, err := metrics.NewStatsDReporter(
	"my_canonical_service_id",
	metrics.AddressFromEnv("STATS_REPORTER_ADDRESS"),
)
if err != nil {
	fmt.Printf("unable to connect to statsd: %v", err)
}
```

Then within your application pass the `reporter` variable to your types and call the methods rather than the package-level funcs.

```go
reporter.IncCounter("my_request", metrics.Tag("foo", "bar"))
// or
defer reporter.NewTimer("http_request", Tag("protocol", "http2")).Record()

```

Now your metrics can be queried in grafana!