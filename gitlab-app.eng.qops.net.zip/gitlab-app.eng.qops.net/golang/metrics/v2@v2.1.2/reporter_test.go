package metrics

import (
	"math"
	"testing"
	"time"
)

func TestTag(t *testing.T) {
	k := "key"
	v := "value"
	tag := Tag(k, v)
	m := &Meta{
		Key:   k,
		Value: v,
	}
	if tag.Key != m.Key {
		t.Errorf("Tag create a Meta with a key of (%s) wanted (%s)", tag.Key, m.Key)
	}
	if tag.Value != m.Value {
		t.Errorf("Tag create a Meta with a value of (%s) wanted (%s)", tag.Value, m.Value)
	}
}

func TestDiscardReporter(t *testing.T) {
	var r Reporter = &discardReporter{}
	r.IncCounter("name string")
	r.AddToCounter("name string", 2)
	r.UpdateGauge("name string", 2.0)
	r.RecordHistogram("name string", math.Pi)
	r.RecordTiming("name string", time.Second)
	r.Flush()
	r.Close()
}

type mockTimer struct{}

func (t *mockTimer) Record() {}

// A mockReporter implements the Reporter interface by providing a null sink.
type mockReporter struct {
	incCounterCallCount      int
	addToCounterCallCount    int
	updateGaugeCallCount     int
	recordHistogramCallCount int
	recordTimingCallCount    int
	newTimerCallCount        int
	flushCallCount           int
}

func (mr *mockReporter) IncCounter(name string, tags ...Meta) {
	mr.incCounterCallCount++
}
func (mr *mockReporter) AddToCounter(name string, value int64, tags ...Meta) {
	mr.addToCounterCallCount++
}
func (mr *mockReporter) UpdateGauge(name string, value float64, tags ...Meta) {
	mr.updateGaugeCallCount++
}
func (mr *mockReporter) RecordHistogram(name string, v float64, tags ...Meta) {
	mr.recordHistogramCallCount++
}
func (mr *mockReporter) RecordTiming(name string, d time.Duration, tags ...Meta) {
	mr.recordTimingCallCount++
}
func (mr *mockReporter) NewTimer(name string, tags ...Meta) Timer {
	mr.newTimerCallCount++
	return &mockTimer{}
}
func (mr *mockReporter) Flush() {
	mr.flushCallCount++

}
func (mr *mockReporter) Close() error { return nil }

func TestPackageFuncs(t *testing.T) {
	r := &mockReporter{}
	DefaultReporter = r
	IncCounter("test")
	AddToCounter("test", 2)
	UpdateGauge("test", 2.0)
	RecordHistogram("test", 2.0)
	RecordTiming("test", time.Since(time.Now()))
	NewTimer("test")
	Flush()

	if r.incCounterCallCount != 1 {
		t.Error("expected IncCounter to have been called once")
	}
	if r.addToCounterCallCount != 1 {
		t.Error("expected AddToCounter to have been called once")
	}
	if r.updateGaugeCallCount != 1 {
		t.Error("expected UpdateGauge to have been called once")
	}
	if r.recordHistogramCallCount != 1 {
		t.Error("expected RecordHistogram to have been called once")
	}
	if r.recordTimingCallCount != 1 {
		t.Error("expected RecordTiming to have been called once")
	}
	if r.newTimerCallCount != 1 {
		t.Error("expected NewTimer to have been called once")
	}
	if r.flushCallCount != 1 {
		t.Error("expected Flush to have been called once")
	}
}
