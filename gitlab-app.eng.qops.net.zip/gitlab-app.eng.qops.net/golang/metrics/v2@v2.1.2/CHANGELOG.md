## v2.1.1
- Fixed an issue with Prometheus metric names where legal-in-StatsD names were rejected due to illegal-in-Prometheus characters. The problem is avoided by replacing illegal characters with `_`.

## v2.1.0
- Add a Prometheus implementation of the Reporter interface.
    - A `*PrometheusReporter` implements both the [`Reporter`](http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/metrics#Reporter) and [`prometheus.Collector`](https://pkg.go.dev/github.com/prometheus/client_golang/prometheus#Collector) interfaces. When enabled with `EnableDefaultReporter`, it is automatically registered with the default Prometheus registrator, so users will find metrics reported on the default Prometheus handler `promhttp.Handler()` (which, for example, is exposed by default by [golang/app](http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/app)).
- Deprecate `NewReporter`; it is now merely an alias for `NewStatsDReporter`.
- Deprecate `EnableStatsDReporter`; it is now merely an alias for `EnableDefaultReporter` which now implements equivalent but expanded functionality.

## v2.0.0
- Change Reporter interface method `UpdateGauge` to expect the parameter value to be of type `float64` instead of `int64`

## v1.1.0
- Add package-level `Close` function to close the singleton Reporter.

## v1.0.0
Initial versioned release, including:
- `RecordHistogram` API for recording non-timing scalars.
- Package-level functions if consumers prefer to use a singleton Reporter. See `DefaultReporter`, `EnableStatsDReporter`, `IncCounter`, `AddToCounter`, `UpdateGauge`, `RecordHistogram`, `RecordTiming`, `NewTimer`, `Flush`.
