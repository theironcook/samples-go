package metrics

import (
	"math"
	"testing"
	"time"
)

func TestTags(t *testing.T) {
	t.Skip("TODO wesb")
}
func TestNewReporter(t *testing.T) {
	t.Skip("TODO wesb")
}

func TestIncCounterWithInValidName(t *testing.T) {
	var foundErr error
	var callCount int
	r := &StatsDReporter{
		client: &mockClient{
			mockIncrement: func(s string) {
				callCount++
			},
		},
		errorHandler: func(err error) {
			foundErr = err
		},
	}
	r.IncCounter("")
	if foundErr == nil {
		t.Error("Expected IncCounter to handle an error, found nil")
	}
	if callCount != 0 {
		t.Error("Expected IncCounter to not have called internal client")
	}
}

func TestIncCounterWithValidName(t *testing.T) {
	var foundErr error
	var callCount int
	var callName string
	r := &StatsDReporter{
		client: &mockClient{
			mockIncrement: func(s string) {
				callName = s
				callCount++
			},
		},
		errorHandler: func(err error) {
			foundErr = err
		},
	}
	metricName := "my_metric"
	r.IncCounter(metricName)
	if foundErr != nil {
		t.Errorf("Expected IncCounter to NOT handle an error, found %v", foundErr)
	}
	if callCount != 1 {
		t.Error("Expected IncCounter to have called internal client")
	}
	if callName != metricName {
		t.Errorf("IncCounter called internal client with %s, wanted %s", callName, metricName)
	}
}

func TestAddToCounterWithInValidName(t *testing.T) {
	var foundErr error
	var callCount int
	r := &StatsDReporter{
		client: &mockClient{
			mockCount: func(s string, i interface{}) {
				callCount++
			},
		},
		errorHandler: func(err error) {
			foundErr = err
		},
	}
	r.AddToCounter("", int64(2))
	if foundErr == nil {
		t.Error("Expected AddToCounter to handle an error, found nil")
	}
	if callCount != 0 {
		t.Error("Expected AddToCounter to not have called internal client")
	}
}

func TestAddToCounterWithValidName(t *testing.T) {
	var foundErr error
	var callCount int
	var callName string
	var callVal interface{}
	r := &StatsDReporter{
		client: &mockClient{
			mockCount: func(s string, i interface{}) {
				callName = s
				callVal = i
				callCount++
			},
		},
		errorHandler: func(err error) {
			foundErr = err
		},
	}
	metricName := "my_metric"
	var metricVal int64 = 2
	r.AddToCounter(metricName, metricVal)
	if foundErr != nil {
		t.Errorf("Expected AddToCounter to NOT handle an error, found %v", foundErr)
	}
	if callCount != 1 {
		t.Error("Expected AddToCounter to have called internal client")
	}
	if callName != metricName {
		t.Errorf("AddToCounter called internal client with %s, wanted %s", callName, metricName)
	}
	if intVal, ok := callVal.(int64); !ok || intVal != metricVal {
		t.Errorf("AddToCounter called internal client with %d, wanted %d", intVal, metricVal)
	}
}

func TestUpdateGaugeWithInValidName(t *testing.T) {
	var foundErr error
	var callCount int
	r := &StatsDReporter{
		client: &mockClient{
			mockGauge: func(s string, i interface{}) {
				callCount++
			},
		},
		errorHandler: func(err error) {
			foundErr = err
		},
	}
	r.UpdateGauge("", float64(2))
	if foundErr == nil {
		t.Error("Expected UpdateGauge to handle an error, found nil")
	}
	if callCount != 0 {
		t.Error("Expected UpdateGauge to not have called internal client")
	}
}

func TestUpdateGaugeWithValidName(t *testing.T) {
	var foundErr error
	var callCount int
	var callName string
	var callVal interface{}
	r := &StatsDReporter{
		client: &mockClient{
			mockGauge: func(s string, i interface{}) {
				callName = s
				callVal = i
				callCount++
			},
		},
		errorHandler: func(err error) {
			foundErr = err
		},
	}
	metricName := "my_metric"
	var metricVal float64 = 2
	r.UpdateGauge(metricName, metricVal)
	if foundErr != nil {
		t.Errorf("Expected UpdateGauge to NOT handle an error, found %v", foundErr)
	}
	if callCount != 1 {
		t.Error("Expected UpdateGauge to have called internal client")
	}
	if callName != metricName {
		t.Errorf("UpdateGauge called internal client with %s, wanted %s", callName, metricName)
	}
	if floatVal, ok := callVal.(float64); !ok || floatVal != metricVal {
		t.Errorf("UpdateGauge called internal client with %f, wanted %f", floatVal, metricVal)
	}
}

func TestRecordHistogramWithInValidName(t *testing.T) {
	var foundErr error
	var callCount int
	r := &StatsDReporter{
		client: &mockClient{
			mockHistogram: func(s string, i interface{}) {
				callCount++
			},
		},
		errorHandler: func(err error) {
			foundErr = err
		},
	}
	r.RecordHistogram("", math.Pi)
	if foundErr == nil {
		t.Error("Expected RecordHistogram to handle an error, found nil")
	}
	if callCount != 0 {
		t.Error("Expected RecordHistogram to not have called internal client")
	}
}

func TestRecordHistogramWithValidName(t *testing.T) {
	var foundErr error
	var callCount int
	var callName string
	var callVal interface{}
	r := &StatsDReporter{
		client: &mockClient{
			mockHistogram: func(s string, i interface{}) {
				callName = s
				callVal = i
				callCount++
			},
		},
		errorHandler: func(err error) {
			foundErr = err
		},
	}
	metricName := "my_metric"
	metricVal := 2 * math.Pi
	r.RecordHistogram(metricName, metricVal)
	if foundErr != nil {
		t.Errorf("Expected RecordHistogram to NOT handle an error, found %v", foundErr)
	}
	if callCount != 1 {
		t.Error("Expected RecordHistogram to have called internal client")
	}
	if callName != metricName {
		t.Errorf("RecordHistogram called internal client with %s, wanted %s", callName, metricName)
	}
	if floatVal, ok := callVal.(float64); !ok || floatVal != metricVal {
		t.Errorf("RecordHistogram called internal client with %f, wanted %f", floatVal, metricVal)
	}
}

func TestRecordTimingWithInValidName(t *testing.T) {
	var foundErr error
	var callCount int
	r := &StatsDReporter{
		client: &mockClient{
			mockTiming: func(s string, i interface{}) {
				callCount++
			},
		},
		errorHandler: func(err error) {
			foundErr = err
		},
	}
	r.RecordTiming("", time.Second)
	if foundErr == nil {
		t.Error("Expected RecordTiming to handle an error, found nil")
	}
	if callCount != 0 {
		t.Error("Expected RecordTiming to not have called internal client")
	}
}

func TestRecordTimingWithValidName(t *testing.T) {
	var foundErr error
	var callCount int
	var callName string
	var callVal interface{}
	r := &StatsDReporter{
		client: &mockClient{
			mockTiming: func(s string, i interface{}) {
				callName = s
				callVal = i
				callCount++
			},
		},
		errorHandler: func(err error) {
			foundErr = err
		},
	}
	metricName := "my_metric"
	metricVal := 2 * time.Second
	r.RecordTiming(metricName, metricVal)
	if foundErr != nil {
		t.Errorf("Expected RecordTiming to NOT handle an error, found %v", foundErr)
	}
	if callCount != 1 {
		t.Error("Expected RecordTiming to have called internal client")
	}
	if callName != metricName {
		t.Errorf("RecordTiming called internal client with %s, wanted %s", callName, metricName)
	}
	expectedVal := metricVal.Nanoseconds() / time.Millisecond.Nanoseconds()
	if intVal, ok := callVal.(int64); !ok || intVal != expectedVal {
		t.Errorf("RecordTiming called internal client with %d, wanted %d", intVal, expectedVal)
	}
}

func TestNewTimer(t *testing.T) {
	var callCount int
	var callName string
	var callVal interface{}
	r := &StatsDReporter{
		client: &mockClient{
			mockTiming: func(s string, i interface{}) {
				callName = s
				callVal = i
				callCount++
			},
		},
		errorHandler: func(err error) {},
	}
	metricName := "my_metric"
	timer := r.NewTimer(metricName)
	metricVal := 50 * time.Millisecond
	time.Sleep(metricVal)
	timer.Record()

	if callCount != 1 {
		t.Error("Expected RecordTiming to have called internal client")
	}
	if callName != metricName {
		t.Errorf("RecordTiming called internal client with %s, wanted %s", callName, metricName)
	}
	minVal := metricVal.Nanoseconds() / time.Millisecond.Nanoseconds()
	maxVal := (metricVal + (5 * time.Millisecond)).Nanoseconds() / time.Millisecond.Nanoseconds()
	if intVal, ok := callVal.(int64); !ok || intVal < minVal || intVal > maxVal {
		t.Errorf("NewTimer should have recording value matching %d < %d < %d", minVal, intVal, maxVal)
	}

}

func TestFlush(t *testing.T) {
	var callCount int
	r := &StatsDReporter{
		client: &mockClient{
			mockFlush: func() {
				callCount++
			},
		},
	}
	r.Flush()
	if callCount != 1 {
		t.Errorf("Expected Flush to call internal client.Flush")
	}
}

func TestClose(t *testing.T) {
	var callCount int
	r := &StatsDReporter{
		client: &mockClient{
			mockClose: func() {
				callCount++
			},
		},
	}
	err := r.Close()
	if err != nil {
		t.Errorf("Expected Close to always return nil, found %v.", err)
	}
	if callCount != 1 {
		t.Error("Expected Close to call internal client.Close")
	}
}
