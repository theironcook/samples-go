# Goals

The goals of the metrics package are the following:

1. Provide a `Reporter` interface so we standardize what our shared packages accept to make it easier to use Qualtrics packages. It will also make the transition easier when we extract a pkg from an existing service to make it a shared package.
2. Provide a client with good defaults to store items in DevOps’ metrics service.
3. Provide a `DiscardReporter` similar to [`ioutil.Discard`](https://godoc.org/io/ioutil#pkg-variables) for testing and dev environments.

# Implementation
The current implementation of `StatsDReporter` wraps an existing statsd client. In the future we can remove this dependency by writing our own while keeping the same `Reporter` interface. We also hope to change the `NewReporter` behavior to still return a "retrying" reporter if there is an error establishing a connection during creation.