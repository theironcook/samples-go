package metrics

import (
	"fmt"
	"sort"
	"sync"
	"time"

	"github.com/prometheus/client_golang/prometheus"
)

// HistogramBuckets is a reasonable set of histogram buckets from 1ms to 10m on an approximately
// exponential scale (each bucket is close to 2X the size of the previous one).
//
// This seemed like a reasonable balance of bucket count and histogram accuracy, which I
// corroborated with latency data from SumoLogic showing that this range covers 99.995%
// of our requests under normal operation.
var HistogramBuckets = []float64{
	0.001,
	0.0025,
	0.005,
	0.01,
	0.025,
	0.05,
	0.1,
	0.25,
	0.5,
	1,
	2.5,
	5,
	10,
	30,
	60,
	150,
	300,
	600,
}

type PrometheusReporter struct {
	namespace string

	errorHandler func(error)

	// metrics tracks all metrics that have been seen so far, so they can be exposed
	// to Prometheus.
	//
	// The nature of our Reporter interface poses an unusual challenge to creating a
	// Prometheus-based implementation: the Prometheus API encourages the domain of all
	// metrics to be defined up-front, but our Reporter interface is such that the domain
	// of all metrics cannot be known up-front but rather forms at runtime when new
	// {name, label} combinations are first used.
	//
	// Regarding this value's type: the Go docs explain that
	//
	//     The Map type is optimized for ... when the entry for a given key
	//     is only ever written once but read many times....
	//
	// That accurately describes our use case here, and due to the nuances of
	// Prometheus types we don't lose anything from the lack of type safety since
	// we already need to type-assert the values anyway.
	metrics sync.Map // map[string]prometheus.Collector

	counterCreator, gaugeCreator, histogramCreator creators
}

// NewPrometheusReporter creates a new Prometheus reporter.
func NewPrometheusReporter(prefix string, opts ...Option) (*PrometheusReporter, error) {

	cfg := &config{
		prefix:       prefix,
		errorHandler: func(error) {},
		buckets:      HistogramBuckets,
	}

	for _, o := range opts {
		if err := o(cfg); err != nil {
			return nil, err
		}
	}

	return &PrometheusReporter{
		namespace:    promNormalizeMetricName(cfg.prefix),
		errorHandler: cfg.errorHandler,

		counterCreator: creators{
			Single: func(opts prometheus.Opts) prometheus.Collector {
				return prometheus.NewCounter(prometheus.CounterOpts(opts))
			},
			Vector: func(opts prometheus.Opts, labels []string) prometheus.Collector {
				return prometheus.NewCounterVec(prometheus.CounterOpts(opts), labels)
			},
		},

		gaugeCreator: creators{
			Single: func(opts prometheus.Opts) prometheus.Collector {
				return prometheus.NewGauge(prometheus.GaugeOpts(opts))
			},
			Vector: func(opts prometheus.Opts, labels []string) prometheus.Collector {
				return prometheus.NewGaugeVec(prometheus.GaugeOpts(opts), labels)
			},
		},

		histogramCreator: creators{
			Single: func(opts prometheus.Opts) prometheus.Collector {
				return prometheus.NewHistogram(prometheus.HistogramOpts{
					Namespace: opts.Namespace,
					Subsystem: opts.Subsystem,
					Name:      opts.Name,
					Help:      opts.Help,
					Buckets:   cfg.buckets,
				})
			},
			Vector: func(opts prometheus.Opts, labels []string) prometheus.Collector {
				return prometheus.NewHistogramVec(prometheus.HistogramOpts{
					Namespace: opts.Namespace,
					Subsystem: opts.Subsystem,
					Name:      opts.Name,
					Help:      opts.Help,
					Buckets:   cfg.buckets,
				}, labels)
			},
		},
	}, nil
}

// WithHistogramBuckets configures a PrometheusReporter to use the given set of buckets for
// histogram metrics. When this option is not used, HistogramBuckets is used as a default.
//
// This Option is honored only by PrometheusRepoter.
func WithHistogramBuckets(buckets []float64) Option {
	return Option(func(c *config) error {
		c.buckets = buckets
		return nil
	})
}

func (pr *PrometheusReporter) Describe(chan<- *prometheus.Desc) { return }
func (pr *PrometheusReporter) Collect(out chan<- prometheus.Metric) {
	pr.metrics.Range(func(_, v interface{}) bool {
		v.(prometheus.Collector).Collect(out)
		return true
	})
}

func (pr *PrometheusReporter) IncCounter(name string, tags ...Meta) {
	switch c := pr.metric(name, tags, pr.counterCreator).(type) {
	case prometheus.Counter:
		c.Inc()
	default:
		pr.IncCounter("dropped_metric")
		pr.errorHandler(fmt.Errorf("metric is for a mismatched type: expected prometheus.Counter but got %T", c))
	}
}

func (pr *PrometheusReporter) AddToCounter(name string, value int64, tags ...Meta) {
	switch c := pr.metric(name, tags, pr.counterCreator).(type) {
	case prometheus.Counter:
		c.Add(float64(value))
	default:
		pr.IncCounter("dropped_metric")
		pr.errorHandler(fmt.Errorf("metric is for a mismatched type: expected prometheus.Counter but got %T", c))
	}
}

func (pr *PrometheusReporter) UpdateGauge(name string, value float64, tags ...Meta) {
	switch g := pr.metric(name, tags, pr.gaugeCreator).(type) {
	case prometheus.Gauge:
		g.Set(float64(value))
	default:
		pr.IncCounter("dropped_metric")
		pr.errorHandler(fmt.Errorf("metric is for a mismatched type: expected prometheus.Gauge but got %T", g))
	}
}

func (pr *PrometheusReporter) RecordHistogram(name string, v float64, tags ...Meta) {
	switch h := pr.metric(name, tags, pr.histogramCreator).(type) {
	case prometheus.Histogram:
		h.Observe(float64(v))
	default:
		pr.IncCounter("dropped_metric")
		pr.errorHandler(fmt.Errorf("metric is for a mismatched type: expected prometheus.Histogram but got %T", h))
	}
}

func (pr *PrometheusReporter) RecordTiming(name string, d time.Duration, tags ...Meta) {
	switch h := pr.metric(name, tags, pr.histogramCreator).(type) {
	case prometheus.Histogram:
		h.Observe(d.Seconds())
	default:
		pr.IncCounter("dropped_metric")
		pr.errorHandler(fmt.Errorf("metric is for a mismatched type: expected prometheus.Histogram but got %T", h))
	}
}

type prometheusTimer struct {
	internal *prometheus.Timer
}

func (pt prometheusTimer) Record() {
	if pt.internal != nil {
		pt.internal.ObserveDuration()
	}
}

func (pr *PrometheusReporter) NewTimer(name string, tags ...Meta) Timer {
	var pt prometheusTimer
	switch h := pr.metric(name, tags, pr.histogramCreator).(type) {
	case prometheus.Histogram:
		pt.internal = prometheus.NewTimer(h)
	default:
		pr.IncCounter("dropped_metric")
	}
	return pt
}

// Flush is a no-op for the Prometheus reporter due to Prometheus' pull-based model.
func (pr *PrometheusReporter) Flush() {}

// Close is a no-op for the Prometheus reporter due to Prometheus' pull-based model.
func (pr *PrometheusReporter) Close() error { return nil }

type creators struct {
	Single func(opts prometheus.Opts) prometheus.Collector
	Vector func(opts prometheus.Opts, labels []string) prometheus.Collector
}

func (pr *PrometheusReporter) metric(name string, tags []Meta, creators creators) prometheus.Collector {

	// Normalize the metric name to remove possible unpermitted characters;
	// this is unfortunately necessary because (a) we don't know a priori what
	// the metric names will be, and (b) because we are trying to stay compatible
	// with the statsd implementation which didn't impose as strict of rules.
	name = promNormalizeMetricName(name)

	m, ok := pr.metrics.Load(name)
	if !ok {
		opts := prometheus.Opts{Namespace: pr.namespace, Name: name}

		if len(tags) == 0 {
			m = creators.Single(opts)
		} else {
			m = creators.Vector(opts, labelNames(tags...))
		}

		// save it
		pr.metrics.Store(name, m)
	}

	// if m is a Counter and len(tags) == 0: OK!
	// if m is a CounterVec and len(tags) > 0: OK!
	// otherwise: dropped metric!

	if len(tags) == 0 {
		switch m := m.(type) {
		case prometheus.Gauge:
			return m
		case prometheus.Counter:
			return m
		case prometheus.Histogram:
			return m
		case prometheus.Summary:
			return m
		}
	} else {
		switch m := m.(type) {
		case *prometheus.GaugeVec:
			if m, err := m.GetMetricWith(promLabels(tags...)); err == nil {
				return m
			}
		case *prometheus.CounterVec:
			if m, err := m.GetMetricWith(promLabels(tags...)); err == nil {
				return m
			}
		case *prometheus.HistogramVec:
			if m, err := m.GetMetricWith(promLabels(tags...)); err == nil {
				return m.(prometheus.Histogram)
			}
		case *prometheus.SummaryVec:
			if m, err := m.GetMetricWith(promLabels(tags...)); err == nil {
				return m.(prometheus.Summary)
			}
		}
	}

	return nil
}

// labelNames returns all label names from tags in sorted order.
func labelNames(tags ...Meta) []string {
	var fields []string
	for _, tag := range tags {
		fields = append(fields, tag.Key)
	}
	sort.Strings(fields)
	return fields
}

func promLabels(tags ...Meta) prometheus.Labels {
	vs := make(prometheus.Labels)
	for _, t := range tags {
		vs[t.Key] = t.Value
	}
	return vs
}

// promNormalizeMetricName normalizes a string to consist only of characters that are
// permitted to appear at the beginning of a Prometheus metric name, which the
// Prometheus docs suggest is [a-zA-Z0-9_:] but cannot begin with a number.
//
// As a special case, promNormalizeMetricName will also accept "" as a valid string.
func promNormalizeMetricName(name string) string {

	// pretty fast version: 60ns
	// handles unicode correctly

	buf := []byte(name)

	// Replace all unpermitted runes with _
	var l int
	for i, c := range name {
		if (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == ':' {

			// For a modest ~9% performance gain, only set the byte if we need to.
			// (Since `i` is the byte where `c` begins and we know `c` to be a
			// 1-byte rune, `i == l` implies that `c` is already in the l`th byte.)
			if i != l {
				buf[l] = byte(c)
			}

		} else {
			buf[l] = '_'
		}
		l++
	}

	switch {
	// Prepend an extra _ if the name contains a leading numeric value
	case l > 0 && buf[0] >= '0' && buf[0] <= '9':
		return "_" + string(buf[:l])

	default:
		return string(buf[:l])
	}
}
