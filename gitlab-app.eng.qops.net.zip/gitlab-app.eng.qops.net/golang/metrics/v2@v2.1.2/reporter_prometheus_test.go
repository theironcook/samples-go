package metrics

import (
	"bufio"
	"bytes"
	"regexp"
	"testing"
	"testing/quick"
	"time"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/common/expfmt"
	prommodel "github.com/prometheus/common/model"
)

var SimplerHistogramBuckets = []float64{
	0.1,
	0.5,
	1,
	5,
}

func TestPrometheusReporter_Metric(t *testing.T) {

	r, expect := PrepareReporter(t, "countertest")

	r.IncCounter("test:counter")  // should not be rewritten
	r.IncCounter("test+counter1") // should be rewritten to "test_counter1"
	r.IncCounter("aサンプル")         // should be rewritten to "____"
	r.IncCounter("2testcounter2") // should be rewritten to "_2testcounter2"

	expect(map[string]string{
		`countertest_test:counter`:   "1",
		`countertest_test_counter1`:  "1",
		`countertest_a____`:          "1",
		`countertest__2testcounter2`: "1",
	})

}

func TestPrometheusReporter_Counter(t *testing.T) {

	r, expect := PrepareReporter(t, "countertest")

	r.IncCounter("test_counter")                  // should work
	r.IncCounter("test_counter", Tag("k", "v"))   // should be dropped
	r.IncCounter("vector_counter", Tag("k", "v")) // should work
	r.IncCounter("vector_counter")                // should be dropped

	expect(map[string]string{
		`countertest_test_counter`:          "1",
		`countertest_vector_counter{k="v"}`: "1",
		`countertest_dropped_metric`:        "2",
	})

	r.AddToCounter("test_counter", 5)                  // should work
	r.AddToCounter("test_counter", 5, Tag("k", "v"))   // should be dropped
	r.AddToCounter("vector_counter", 5, Tag("k", "v")) // should work
	r.AddToCounter("vector_counter", 5)                // should be dropped

	expect(map[string]string{
		`countertest_test_counter`:          "6",
		`countertest_vector_counter{k="v"}`: "6",
		`countertest_dropped_metric`:        "4",
	})

}

func TestPrometheusReporter_Gauge(t *testing.T) {

	r, expect := PrepareReporter(t, "gaugetest")

	r.UpdateGauge("single_gauge", 25)                  // should work
	r.UpdateGauge("single_gauge", 50, Tag("k", "v"))   // should be dropped
	r.UpdateGauge("vector_gauge", 100, Tag("k", "v1")) // should work
	r.UpdateGauge("vector_gauge", 200, Tag("k", "v2")) // should work
	r.UpdateGauge("vector_gauge", 50)                  // should be dropped

	expect(map[string]string{
		`gaugetest_single_gauge`:         "25",
		`gaugetest_vector_gauge{k="v1"}`: "100",
		`gaugetest_vector_gauge{k="v2"}`: "200",
		`gaugetest_dropped_metric`:       "2",
	})

}

func TestPrometheusReporter_Histogram(t *testing.T) {

	r, expect := PrepareReporter(t, "histogramtest", WithHistogramBuckets(SimplerHistogramBuckets))

	r.RecordHistogram("single_histogram", 0.25)                // should work
	r.RecordHistogram("single_histogram", 1.5)                 // should work
	r.RecordHistogram("single_histogram", 0.5, Tag("k", "v"))  // should be dropped
	r.RecordHistogram("vector_histogram", 1.0, Tag("k", "v1")) // should work
	r.RecordHistogram("vector_histogram", 5.0, Tag("k", "v1")) // should work
	r.RecordHistogram("vector_histogram", 1.0)                 // should be dropped

	expect(map[string]string{
		`histogramtest_single_histogram_bucket{le="0.1"}`:  "0",
		`histogramtest_single_histogram_bucket{le="0.5"}`:  "1",
		`histogramtest_single_histogram_bucket{le="1"}`:    "1",
		`histogramtest_single_histogram_bucket{le="5"}`:    "2",
		`histogramtest_single_histogram_bucket{le="+Inf"}`: "2",
		`histogramtest_single_histogram_sum`:               "1.75",
		`histogramtest_single_histogram_count`:             "2",

		`histogramtest_vector_histogram_bucket{k="v1",le="0.1"}`:  "0",
		`histogramtest_vector_histogram_bucket{k="v1",le="0.5"}`:  "0",
		`histogramtest_vector_histogram_bucket{k="v1",le="1"}`:    "1",
		`histogramtest_vector_histogram_bucket{k="v1",le="5"}`:    "2",
		`histogramtest_vector_histogram_bucket{k="v1",le="+Inf"}`: "2",
		`histogramtest_vector_histogram_sum{k="v1"}`:              "6",
		`histogramtest_vector_histogram_count{k="v1"}`:            "2",
	})

}

func TestPrometheusReporter_Timing(t *testing.T) {

	r, expect := PrepareReporter(t, "timingtest", WithHistogramBuckets(SimplerHistogramBuckets))

	r.RecordTiming("single_timing", 250*time.Millisecond)                // should work
	r.RecordTiming("single_timing", 1500*time.Millisecond)               // should work
	r.RecordTiming("single_timing", 500*time.Millisecond, Tag("k", "v")) // should be dropped
	r.RecordTiming("vector_timing", 1*time.Second, Tag("k", "v1"))       // should work
	r.RecordTiming("vector_timing", 5*time.Second, Tag("k", "v1"))       // should work
	r.RecordTiming("vector_timing", 1*time.Second)                       // should be dropped

	expect(map[string]string{
		`timingtest_single_timing_bucket{le="0.1"}`:  "0",
		`timingtest_single_timing_bucket{le="0.5"}`:  "1",
		`timingtest_single_timing_bucket{le="1"}`:    "1",
		`timingtest_single_timing_bucket{le="5"}`:    "2",
		`timingtest_single_timing_bucket{le="+Inf"}`: "2",
		`timingtest_single_timing_sum`:               "1.75",
		`timingtest_single_timing_count`:             "2",

		`timingtest_vector_timing_bucket{k="v1",le="0.1"}`:  "0",
		`timingtest_vector_timing_bucket{k="v1",le="0.5"}`:  "0",
		`timingtest_vector_timing_bucket{k="v1",le="1"}`:    "1",
		`timingtest_vector_timing_bucket{k="v1",le="5"}`:    "2",
		`timingtest_vector_timing_bucket{k="v1",le="+Inf"}`: "2",
		`timingtest_vector_timing_sum{k="v1"}`:              "6",
		`timingtest_vector_timing_count{k="v1"}`:            "2",
	})

}

func TestPrometheusReporter_Timer(t *testing.T) {

	r, expect := PrepareReporter(t, "timertest", WithHistogramBuckets(SimplerHistogramBuckets))

	r.NewTimer("single_timer").Record()                 // should work
	r.NewTimer("single_timer", Tag("k", "v")).Record()  // should be dropped
	r.NewTimer("vector_timer", Tag("k", "v1")).Record() // should work
	r.NewTimer("vector_timer").Record()                 // should be dropped

	expect(map[string]string{
		`timertest_single_timer_bucket{le="0.1"}`:  "1",
		`timertest_single_timer_bucket{le="0.5"}`:  "1",
		`timertest_single_timer_bucket{le="1"}`:    "1",
		`timertest_single_timer_bucket{le="5"}`:    "1",
		`timertest_single_timer_bucket{le="+Inf"}`: "1",
		`timertest_single_timer_count`:             "1",
		// `timingtest_single_timer_sum`:               "???",

		`timertest_vector_timer_bucket{k="v1",le="0.1"}`:  "1",
		`timertest_vector_timer_bucket{k="v1",le="0.5"}`:  "1",
		`timertest_vector_timer_bucket{k="v1",le="1"}`:    "1",
		`timertest_vector_timer_bucket{k="v1",le="5"}`:    "1",
		`timertest_vector_timer_bucket{k="v1",le="+Inf"}`: "1",
		`timertest_vector_timer_count{k="v1"}`:            "1",
		// `timertest_vector_timer_sum{k="v1"}`:              "???",

		`timertest_dropped_metric`: "2",
	})

}

func PrepareReporter(t *testing.T, prefix string, opts ...Option) (Reporter, func(map[string]string)) {
	reg := prometheus.NewPedanticRegistry()

	r, err := NewPrometheusReporter(prefix, opts...)
	if err != nil {
		t.Fatal(err)
	}

	if err := reg.Register(r); err != nil {
		t.Fatal(err)
	}

	return r, func(expectations map[string]string) {
		ExpectMetrics(t, reg, expectations)
	}
}

// metricMatcher matches the format of a Prometheus metric and pulls out its component parts.
var metricMatcher = regexp.MustCompile(`^([a-zA-Z0-9_:][a-zA-Z0-9_:]*({.*})?) ([0-9e\.\-\+]+|NaN)$`)

// ExpectMetrics asserts that the Prometheus registry reg contains the metrics and values described by expected.
func ExpectMetrics(t *testing.T, reg prometheus.Gatherer, expected map[string]string) {

	// first, gather the values of all metrics
	mfs, err := reg.Gather()
	if err != nil {
		t.Fatal(err)
	}

	// second, serialize them into prometheus metrics format
	var buf bytes.Buffer
	enc := expfmt.NewEncoder(&buf, expfmt.FmtText)
	for _, mf := range mfs {
		if err := enc.Encode(mf); err != nil {
			t.Fatal(err)
		}
	}

	// third, iterate through to pull out the specific metrics and values
	actual := make(map[string]string)
	scanner := bufio.NewScanner(&buf)
	for scanner.Scan() {
		if matches := metricMatcher.FindStringSubmatch(scanner.Text()); matches != nil {
			t.Logf("metric: %s\n", scanner.Text())
			actual[matches[1]] = matches[3]
		}
	}
	if err := scanner.Err(); err != nil {
		t.Fatal(err)
	}

	// fourth, compare the expected values to the actual ones
	for k, v := range expected {
		if va, ok := actual[k]; !ok {
			t.Errorf("unexpected value for %q: expected %q but found nothing", k, v)
		} else if v != va {
			t.Errorf("unexpected value for %q: expected %q but found %q", k, v, va)
		}
	}

}

func TestNormalizeMetricName(t *testing.T) {

	cases := []struct {
		Input, Expect string
	}{
		// Test the cases reported as broken in v2.1.0;
		// these all fail for the same reason.
		{Input: "survey-version-service", Expect: "survey_version_service"},
		{Input: "library-monolith", Expect: "library_monolith"},
		{Input: "survey-api", Expect: "survey_api"},

		// Ensure that underscores and colons remain permitted.
		{Input: "our_service:server", Expect: "our_service:server"},
		{Input: "_metric", Expect: "_metric"},
		{Input: ":metric", Expect: ":metric"},

		// Ensure that leading numeric values are dealt with.
		{Input: "metric123", Expect: "metric123"},
		{Input: "123metric", Expect: "_123metric"},

		// Ensure that disallowed Unicode characters are collapsed correctly.
		{Input: "サンプル", Expect: "____"},
	}

	for i, c := range cases {
		if actual := promNormalizeMetricName(c.Input); actual != c.Expect {
			t.Errorf("[case %d] unexpected normalization result: expected %q but got %q", i, c.Expect, actual)
		} else if reference := promNormalizeMetricName_easierToVerify(c.Input); actual != reference {
			t.Errorf("[case %d] unexpected normalization result: canonical implementation gave %q but reference implementation gave %q", i, reference, actual)
		} else if !prommodel.MetricNameRE.MatchString(actual) {
			t.Errorf("[case %d] [BUGGY TEST] expected normalization violates Prometheus format: %q", i, c.Expect)
		}
	}

}

func TestNormalizeMetricName_Fuzz(t *testing.T) {

	// Can we find any input which does not result in a pattern matching
	// Prometheus's documented accepted character format?

	f := func(in string) bool {
		return in == "" || prommodel.MetricNameRE.MatchString(promNormalizeMetricName(in))
	}

	if err := quick.Check(f, nil); err != nil {
		t.Error(err)
	}

}

func BenchmarkNormalizeMetricName(b *testing.B) {

	run := func(b *testing.B, fn func(string) string) {

		var (
			input  = "survey-version-service"
			expect = "survey_version_service"
		)

		// verify that it works
		if actual := fn(input); actual != expect {
			b.Fatalf("unexpected normalization result: expected %q but got %q", expect, actual)
		}

		b.ResetTimer()

		for i := 0; i < b.N; i++ {
			_ = fn(input)
		}

	}

	b.Run("canonical", func(b *testing.B) { run(b, promNormalizeMetricName) })
	b.Run("reference", func(b *testing.B) { run(b, promNormalizeMetricName_easierToVerify) })

}

// promNormalizeMetricName_easierToVerify is intended to implement exactly the same
// logic as promNormalizeMetricName in a way that is much easier to verify; it isn't
// used as the canonical implementation because it's 75X slower but it serves
// as a good comparison test.
func promNormalizeMetricName_easierToVerify(name string) string {

	// Replace all non-alphanumeric characters with _
	name = regexp.MustCompile("[^A-Za-z0-9:_]").ReplaceAllString(name, "_")

	// Prepend an extra _ if the name contains a leading numeric value
	if regexp.MustCompile("^[0-9]").MatchString(name) {
		name = "_" + name
	}

	return name
}
