package metrics

import "github.com/alexcesaro/statsd"

type client interface {
	Clone(...statsd.Option) *statsd.Client
	Count(string, interface{})
	Increment(string)
	Gauge(string, interface{})
	Histogram(string, interface{})
	Timing(string, interface{})
	Flush()
	Close()
}
