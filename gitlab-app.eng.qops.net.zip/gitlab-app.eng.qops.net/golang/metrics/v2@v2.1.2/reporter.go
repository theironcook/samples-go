package metrics

import (
	"io"
	"time"

	"github.com/prometheus/client_golang/prometheus"
)

// DiscardReporter is a Reporter on which all calls succeed without doing anything. This is helpful for tests for dev environments.
var DiscardReporter = &discardReporter{}

// DefaultReporter is a package level reporter that consumers can use with package level functions.
// It will default to a DiscardReporter unless the consumer overrides or calls EnableStatsDReporter.
var DefaultReporter Reporter

func init() {
	DefaultReporter = DiscardReporter
}

// The Reporter interface is meant to be an interface that can be used in applications
// and shared packages so there is a common/consistent interface to facilitate using Qualtrics shared packages
type Reporter interface {
	// IncCounter increments the value of a counter metric.
	IncCounter(name string, tags ...Meta)
	// AddToCounter increments the value of a counter metric by the specified value.
	AddToCounter(name string, value int64, tags ...Meta)
	// UpdateGauge resets the state of a gauge to a new value.
	UpdateGauge(name string, value float64, tags ...Meta)
	// RecordHistogram records a histogram metric.
	RecordHistogram(name string, v float64, tags ...Meta)
	// RecordTiming records a timing metric.
	RecordTiming(name string, d time.Duration, tags ...Meta)
	// NewTimer provides a Timer with a Record method to record a timing metric.
	NewTimer(name string, tags ...Meta) Timer
	// Flush should process all metrics stored in an internal buffer.
	Flush()
	io.Closer
}

// Timer is an interface for recording timings.
type Timer interface {
	Record()
}

// Meta is a k/v pair of string data that can be store with a metric.
type Meta struct {
	Key   string
	Value string
}

// Tag is a helper func when reporting metric data.
func Tag(key string, value string) Meta {
	return Meta{
		Key:   key,
		Value: value,
	}
}

// EnableDefaultReporter will configure the default reporter for both StatsD and Prometheus,
// or return an error if that can't be done.
//
// To enable only one of StatsD or Prometheus, use EnableReporter directly with an instance
// of the appropriate Reporter.
func EnableDefaultReporter(prefix string, opts ...Option) error {
	sr, err := NewStatsDReporter(prefix, opts...)
	if err != nil {
		return err
	}
	pr, err := NewPrometheusReporter(prefix, opts...)
	if err != nil {
		return err
	}
	if err := prometheus.DefaultRegisterer.Register(pr); err != nil {
		return err
	}
	return EnableReporter(MultiReporter{sr, pr})
}

// EnableStatsDReporter is a deprecated alias for EnableDefaultReporter. It's recommended to
// use EnableReporter with an explicit Reporter instead.
func EnableStatsDReporter(prefix string, opts ...Option) error {
	return EnableDefaultReporter(prefix, opts...)
}

// EnableReporter sets the default reporter to r.
func EnableReporter(r Reporter) error {
	DefaultReporter = r
	return nil
}

// IncCounter will call IncCounter on the DefaultReporter.
func IncCounter(name string, tags ...Meta) {
	DefaultReporter.IncCounter(name, tags...)
}

// AddToCounter will call AddTzoCounter on the DefaultReporter.
func AddToCounter(name string, value int64, tags ...Meta) {
	DefaultReporter.AddToCounter(name, value, tags...)
}

// UpdateGauge will call UpdateGauge on the DefaultReporter.
func UpdateGauge(name string, value float64, tags ...Meta) {
	DefaultReporter.UpdateGauge(name, value, tags...)
}

// RecordHistogram will call RecordHistogram on the DefaultReporter.
func RecordHistogram(name string, v float64, tags ...Meta) {
	DefaultReporter.RecordHistogram(name, v, tags...)
}

// RecordTiming will call RecordTiming on the DefaultReporter.
func RecordTiming(name string, d time.Duration, tags ...Meta) {
	DefaultReporter.RecordTiming(name, d, tags...)
}

// NewTimer will call NewTimer on the DefaultReporter.
func NewTimer(name string, tags ...Meta) Timer {
	return DefaultReporter.NewTimer(name, tags...)
}

// Flush will call Flush on the DefaultReporter.
func Flush() {
	DefaultReporter.Flush()
}

// Close will call Close on the DefaultReporter
func Close() error {
	return DefaultReporter.Close()
}

type discardTimer struct{}

func (t *discardTimer) Record() {}

// A DiscardReporter implements the Reporter interface by providing a null sink.
type discardReporter struct{}

func (dr discardReporter) IncCounter(name string, tags ...Meta)                    {}
func (dr discardReporter) AddToCounter(name string, value int64, tags ...Meta)     {}
func (dr discardReporter) UpdateGauge(name string, value float64, tags ...Meta)    {}
func (dr discardReporter) RecordHistogram(name string, v float64, tags ...Meta)    {}
func (dr discardReporter) RecordTiming(name string, d time.Duration, tags ...Meta) {}
func (dr discardReporter) NewTimer(name string, tags ...Meta) Timer {
	return &discardTimer{}
}
func (dr discardReporter) Flush()       {}
func (dr discardReporter) Close() error { return nil }
