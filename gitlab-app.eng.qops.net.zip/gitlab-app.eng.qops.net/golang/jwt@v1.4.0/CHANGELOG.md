## v1.0.0

Use Go modules

## v1.0.1

We are using the form3tech-oss/jwt-go fork instead of the usual dgrijalva/jwt-go, hopefully temporarily, due to CVE-2020-26160. The fix hasn't been merged into the main repo yet, and the community coalesced on this fork as a temporary solution as documented in https://github.com/dgrijalva/jwt-go/issues/428. If and when the fix is merged in dgrijalva/jwt-go (or if another fork becomes the de-facto standard), we should switch to that.

## v1.1.0

- Adding a new type to provide a solution for dynamically defining a key to use for verification (ie `Keyfunc`).
- Adding helper func that uses `golang/qtoken.Keys` to generate a `Keyfunc` that will working with qtoken rotation logic.

## v1.2.0

- Signer now uses the Authorization header in addition to the X-JWT header (legacy) when signing a request. Additionally, the Verifier will accept both the Authorization and X-JWT headers when verifying a request.

## v1.2.1

- Reverts the change made in v1.2.0 that set the Authorization header in the Signer incorrectly. When there are no remaining consumers of v1.2.0, a new v1.2.2 version will be created that sets the Authorization header correctly. For backwards compatibility, the Verifier will allow the token to exist under `X-JWT` or `Authorization`.
- Bump version of gitlab-app.eng.qops.net/golang/qtoken to pull latest patch.

## v1.2.2

- Fixes an issue that omitted the requisite log when using an unknown QToken value.

## v1.2.3

- Fixes an issue that caused a panic when the "iss" (issuer) claim wasn't supplied

## v1.2.4

- Use community fork of `jwt-go` at github.com/golang-jwt/jwt/v4, which is the new de-facto standard.

## v1.3.0

- Adds support for default JWT Headers (e.g. "kid") to be used when signing requests

## v1.4.0

- Upgrades to `github.com/golang-jwt/jwt/v5`, which includes removing default validation of the `iat` claim. This fixes instances of "Token used before issued" due to clock skew.