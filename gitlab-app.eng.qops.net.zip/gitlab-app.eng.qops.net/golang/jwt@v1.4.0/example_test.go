package jwt_test

import (
	"bytes"
	"fmt"
	"net/http"
	"os"
	"strings"

	"gitlab-app.eng.qops.net/golang/jwt"
	"gitlab-app.eng.qops.net/golang/metrics/v2"
	"gitlab-app.eng.qops.net/golang/qtoken"
)

func ExampleSigner_Sign() {
	// signer is created once and can be used repeatedly to sign HTTP requests
	signer := &jwt.Signer{
		Key: []byte("secret_key"),
		DefaultClaims: jwt.Claims{
			Issuer: "eng",
		},
		IncludeBodyHash: true,
	}

	// claims will be used for this specific request, overwriting the signer's default claims
	claims := jwt.Claims{
		Audience: "qualtrics",
		UserID:   "qcorp",
		BrandID:  "qualtrics",
		Custom: map[string]interface{}{
			"userType": "UT_BRANDADMIN",
			"product":  "ControlPanel",
		},
	}

	// create a request to sign
	body := bytes.NewReader([]byte("Some random string of data"))
	r, _ := http.NewRequest("POST", "/some/url", body)

	// sign request with given claims
	if err := signer.Sign(r, claims); err != nil {
		fmt.Printf("unexpected signing error: %v\n", err)
	}

	// a JWT consists of three parts, separated by dots: header.payload.signature
	tokenStr := jwt.GetAuthorizationTokenStr(r)
	jwtHeader := strings.Split(tokenStr, ".")[0]
	fmt.Println(jwtHeader)

	// Output: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9
}

func ExampleVerifier_Verify() {
	signer := &jwt.Signer{
		Key: []byte("secret_key"),
		DefaultClaims: jwt.Claims{
			Issuer: "eng",
		},
	}

	claims := jwt.Claims{
		Audience: "qualtrics",
		UserID:   "qcorp",
		BrandID:  "qualtrics",
		Custom: map[string]interface{}{
			"userType": "UT_BRANDADMIN",
			"product":  "ControlPanel",
		},
	}

	body := bytes.NewReader([]byte("Some random string of data"))
	r, _ := http.NewRequest("POST", "/some/url", body)
	if err := signer.Sign(r, claims); err != nil {
		fmt.Printf("unexpected signing error: %v\n", err)
	}

	// verifier is created once and can be used repeatedly to verify the JWT of HTTP requests
	verifier := &jwt.Verifier{
		Key: []byte("secret_key"),
	}

	// verify the request's JWT
	claims, err := verifier.Verify(r)
	if err != nil {
		fmt.Printf("unexpected verifying error: %v\n", err)
	}

	// optionally use needed claims
	fmt.Println(claims.Audience)
	fmt.Println(claims.UserID)
	fmt.Println(claims.Issuer)
	fmt.Println(claims.Custom["userType"])

	// Output: qualtrics
	// qcorp
	// eng
	// UT_BRANDADMIN
}

func ExampleKeyfuncFromQTokenKeys() {

	signer := &jwt.Signer{
		Key: []byte("secret_key"),
		DefaultClaims: jwt.Claims{
			Issuer: "eng",
		},
	}

	claims := jwt.Claims{
		Audience: "qualtrics",
		UserID:   "system",
		BrandID:  "system",
	}

	body := bytes.NewReader([]byte("Some random string of data"))
	r, _ := http.NewRequest("POST", "/some/url", body)
	if err := signer.Sign(r, claims); err != nil {
		fmt.Printf("unexpected signing error: %v\n", err)
	}

	// Set these by reading from vault.
	os.Setenv("QTOKEN", "not_correct_key")
	os.Setenv("QTOKEN_ROTATED", "secret_key")
	os.Setenv("QTOKEN_CHECKSUM", "secret_key")

	// Create a verifier to be used with qtoken rotation logic.
	verifier := &jwt.Verifier{
		Keyfunc: jwt.KeyfuncFromQTokenKeys(
			qtoken.MustKeysFromEnv(),
			metrics.DiscardReporter, // Pass an actual reporter.
		),
	}

	claims, err := verifier.Verify(r)
	if err != nil {
		fmt.Printf("unexpected verifying error: %v\n", err)
	}

	fmt.Println(claims.Audience)
	fmt.Println(claims.UserID)
	fmt.Println(claims.Issuer)

	// Output: qualtrics
	// system
	// eng
}
