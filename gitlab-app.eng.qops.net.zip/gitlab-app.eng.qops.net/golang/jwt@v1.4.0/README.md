author: jaredr@qualtrics.com

Signing/verifying JWT requests using `golang/jwt`
===

This guide will walk you through how to sign and verify JWT requests (according to the [Qualtrics JWT Authentication Proposal](https://docs.google.com/document/d/1VfkZIxVUyix_rQEUEbiWA9T6z9eZwcZ-PcKig7dhDeY/edit)) using the `golang/jwt` package.

Click here for the full <a href="http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/jwt"><img src="http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/jwt?status.svg" alt="GoDoc"></a>

## Sign

The minimun steps to sign a request are 1) to create a `jwt.Signer` and 2) provide a secret. The example below shows the usage of more common options/values.

!!! warning "Best Practices"
	This code example does not handle errors, uses the `http.DefaultClient`, uses `os.Getenv` instead of `os.LookupEnv`, and does not provide a request context. These are not [best practices](https://gitlab-app.eng.qops.net/golang/docs/blob/master/best_practices.md) and the code has been modifed to succinctly provide example usage of the package.

```go
// signer is created once and can be used repeatedly to sign HTTP requests
signer := &jwt.Signer{
    Key: []byte(os.Getenv("JWT_SECRET")),
    DefaultClaims: jwt.Claims{
        Issuer: "<your_team_or_serivce_id>",
    },
    IncludeBodyHash: true,
}

// claims will be used for this specific request, overwriting the signer's default claims
claims := jwt.Claims{
	Audience: "<receiving_serivce_id>",
	UserID:   "qcorp",
	BrandID:  "qualtrics",
	Custom: map[string]interface{}{
		"userType": "UT_BRANDADMIN",
		"product":  "ControlPanel",
	},
}

// create a request to sign
r, _ := http.NewRequest("POST", "/some/url", bodyReader)

// sign request with given claims
_ := signer.Sign(r, claims)

res, _ http.DefaultClient.Do(r)

```

## Verify

The minimum steps to verify a request are 1) to create a `Verifier` and 2) provide a secret. 

!!! warning "Best Practices"
	This code example does not handle errors nor show how to switch on the [package level errors defined in the package](http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/jwt#pkg-variables).


```go
// verifier is created once and can be used repeatedly to verify the JWT of HTTP requests
verifier := &jwt.Verifier{
    Key: []byte(os.Getenv("JWT_SECRET")),
}

// verify the request's JWT
claims, err := verifier.Verify(r)
if err != nil {
    fmt.Printf("unexpected verifying error: %v\n", err)
}

// optionally use needed claims
fmt.Printf("%v\n", claims)
```