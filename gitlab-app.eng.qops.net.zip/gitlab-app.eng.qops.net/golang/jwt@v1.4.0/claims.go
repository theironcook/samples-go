package jwt

import (
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"net/http"
	"strings"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

var (
	// ErrIncompleteClaims indicates that a required claim was left unpopulated.
	ErrIncompleteClaims = errors.New("required claim left unpopulated")

	// ErrUnexpectedMethod indicates the JWT had an incorrect method on it.
	ErrUnexpectedMethod = errors.New("unexpected method found on JWT")

	// ErrExpiredJWT indicates the JWT was sent with an expired timestamp.
	ErrExpiredJWT = errors.New("expired JWT")

	// ErrUnexpectedURI indicates the JWT's URI did not match the one on the request.
	ErrUnexpectedURI = errors.New("unexpected URI found on JWT")

	// errInvalidTimeFormat indicates the JWT claim used an unexpected type for a timestamp.
	errInvalidTimeFormat = errors.New("invalid time format for claim")
)

// Claims encapsulates a standard set of required and/or recommended JWT claims, as specified
// by the Qualtrics Authentication Proposal.
type Claims struct {
	Issuer   string // iss
	Audience string // aud
	UserID   string // userId (Qualtrics-specific)
	BrandID  string // brandId (Qualtrics-specific)

	// Arbitrary additional claims may be specified here
	Custom map[string]interface{}
}

// GetIssuer retrieves the issuer field even if it is empty.
func (c *Claims) GetIssuer() (string, error) {
	return c.Issuer, nil
}

// GetAudience retrieves the audience field even if it is empty.
func (c *Claims) GetAudience() (jwt.ClaimStrings, error) {
	return jwt.ClaimStrings{c.Audience}, nil
}

// GetExpirationTime parses the exp field into a [jwt.NumericDate] or nil.
// for backwards compatibility, errors from parsing the numeric date are ignored
func (c *Claims) GetExpirationTime() (*jwt.NumericDate, error) {
	date, _ := c.parseNumericDate("exp")
	return date, nil
}

// GetIssuedAt parses the iat field into a [jwt.NumericDate] or nil.
// for backwards compatibility, errors from parsing the numeric date are ignored
func (c *Claims) GetIssuedAt() (*jwt.NumericDate, error) {
	date, _ := c.parseNumericDate("iat")
	return date, nil
}

// GetNotBefore parses the nbf field into a [jwt.NumericDate] or nil.
// for backwards compatibility, errors from parsing the numeric date are ignored
func (c *Claims) GetNotBefore() (*jwt.NumericDate, error) {
	date, _ := c.parseNumericDate("nbf")
	return date, nil
}

// parseNumericDate parses a [jwt.NumericDate] stored in custom claims as either an int64 or a float64.
// If the field is not found, nil is returned. If the field's value cannot be parsed, an error is returned.
func (c *Claims) parseNumericDate(key string) (*jwt.NumericDate, error) {
	var numericDate *jwt.NumericDate

	claim, isSet := c.Custom[key]
	if !isSet {
		return nil, nil
	}

	switch v := claim.(type) {
	case float64:
		expireTimeInt64 := int64(v)
		numericDate = jwt.NewNumericDate(time.Unix(expireTimeInt64, 0))
	case int64:
		numericDate = jwt.NewNumericDate(time.Unix(v, 0))
	default:
		return nil, errInvalidTimeFormat
	}

	return numericDate, nil
}

// GetSubject retrieves the sub custom claim or an empty string.
func (c *Claims) GetSubject() (string, error) {
	sub, _ := c.Custom["sub"].(string)
	return sub, nil
}

// Valid calls [Validate].
//
// Deprecated: Use Validate instead.
func (c *Claims) Valid() error {
	return c.Validate()
}

// Validate verifies that all required fields are populated.
// This method satisfies [jwt.ClaimsValidator] and will be called automatically when parsing.
func (c *Claims) Validate() error {
	if c.Issuer == "" || c.Audience == "" {
		return ErrIncompleteClaims
	}
	return nil
}

// combine returns a new set of claims whose values are a merging of this Claims
// object and another one, with the latter overriding properties in the former.
func (c Claims) combine(other Claims) Claims {
	if other.Issuer != "" {
		c.Issuer = other.Issuer
	}
	if other.Audience != "" {
		c.Audience = other.Audience
	}
	if other.UserID != "" {
		c.UserID = other.UserID
	}
	if other.BrandID != "" {
		c.BrandID = other.BrandID
	}

	// create a copied map
	if len(c.Custom) > 0 || len(other.Custom) > 0 {
		extras := make(map[string]interface{})
		for k, v := range c.Custom {
			extras[k] = v
		}
		for k, v := range other.Custom {
			extras[k] = v
		}
		c.Custom = extras
	}

	return c
}

type verificationClaims struct {
	Claims
	Req *http.Request
}

// Validate ensures that a claims object is valid in relation to a http.Request it was attached to.
func (vc *verificationClaims) Validate() error {
	if vc.Req == nil {
		return ErrInvalidJWT
	}

	// validate required fields
	if vc.Issuer == "" || vc.Audience == "" {
		return ErrIncompleteClaims
	}

	// for backwards compatibility, a token without exp is considered expired
	exp, _ := vc.GetExpirationTime()
	if exp == nil {
		return ErrExpiredJWT
	}

	if err := vc.verifyMethod(vc.Req.Method); err != nil {
		return err
	}
	if err := vc.verifyURI(vc.Req.URL.RequestURI()); err != nil {
		return err
	}

	// todo: include a bodyHash verification - skipping now due to complexities
	// See 3.e on: https://docs.google.com/document/d/1VfkZIxVUyix_rQEUEbiWA9T6z9eZwcZ-PcKig7dhDeY/edit#

	return nil
}

// verifyMethod verifies the HTTP method is as promised.
func (vc *verificationClaims) verifyMethod(expectedMethod string) error {
	if claimedMethod, ok := vc.Custom["method"].(string); ok {
		if strings.EqualFold(claimedMethod, expectedMethod) {
			return nil
		}
	}
	return ErrUnexpectedMethod
}

// verifyURI verifies the URL is as promised.
func (vc *verificationClaims) verifyURI(expectedURI string) error {
	if claimedURI, ok := vc.Custom["urlHash"].(string); ok {
		expectedURIHash := sha256.Sum256([]byte(expectedURI))
		if base64.RawURLEncoding.EncodeToString(expectedURIHash[:]) == claimedURI {
			return nil
		}

		// allow for leniency when a redirect may have added/removed a trailing slash
		var additionalURIHash [32]byte
		if strings.HasSuffix(expectedURI, "/") {
			additionalURIHash = sha256.Sum256([]byte(strings.TrimSuffix(expectedURI, "/")))
		} else {
			additionalURIHash = sha256.Sum256([]byte(expectedURI + "/"))
		}

		if base64.RawURLEncoding.EncodeToString(additionalURIHash[:]) == claimedURI {
			return nil
		}
	}

	return ErrUnexpectedURI
}

// UnmarshalJSON populates a claims object from a JSON byte array.
// Meant to be used in conjunction with github.com/golang-jwt/jwt/v5's ParseWithClaims.
func (vc *verificationClaims) UnmarshalJSON(data []byte) error {
	claimsMap := make(map[string]interface{})

	if err := json.Unmarshal(data, &claimsMap); err != nil {
		return err
	}

	// type check each one otherwise casting might panic
	if issuer, ok := claimsMap["iss"].(string); ok {
		vc.Issuer = issuer
		delete(claimsMap, "iss")
	}
	if audience, ok := claimsMap["aud"].(string); ok {
		vc.Audience = audience
		delete(claimsMap, "aud")
	}
	if userID, ok := claimsMap["userId"].(string); ok {
		vc.UserID = userID
		delete(claimsMap, "userId")
	}
	if brandID, ok := claimsMap["brandId"].(string); ok {
		vc.BrandID = brandID
		delete(claimsMap, "brandId")
	}

	vc.Custom = claimsMap
	return nil
}
