package jwt_test

import (
	"bytes"
	"fmt"
	"net/http"
	"os"
	"strings"
	"testing"

	"gitlab-app.eng.qops.net/golang/jwt"
	"gitlab-app.eng.qops.net/golang/metrics/v2"
	"gitlab-app.eng.qops.net/golang/qtoken"
)

func TestKeyfuncFromQTokenKeys(t *testing.T) {

	const (
		keyNew     = "secret_key"
		keyOld     = "old_key"
		keyInvalid = "invalid_key"
	)

	claims := jwt.Claims{
		Audience: "qualtrics",
		UserID:   "system",
		BrandID:  "system",
	}

	body := bytes.NewReader([]byte("Some random string of data"))

	// set this from vault
	os.Setenv("QTOKEN", keyOld)
	os.Setenv("QTOKEN_ROTATED", keyNew)
	os.Setenv("QTOKEN_CHECKSUM", keyNew)

	cases := []struct {
		key            string
		expectedMetric string
		expectValid    bool
	}{
		{
			key:            keyNew,
			expectedMetric: "jwt_pre_verify|iss:eng,key_name:new",
			expectValid:    true,
		},
		{
			key:            keyOld,
			expectedMetric: "jwt_pre_verify|iss:eng,key_name:old",
			expectValid:    true,
		},
		{
			key:            keyInvalid,
			expectedMetric: "jwt_pre_verify|iss:eng,key_name:invalid",
			expectValid:    false,
		},
	}

	for _, c := range cases {
		signer := &jwt.Signer{
			Key: []byte(c.key),
			DefaultClaims: jwt.Claims{
				Issuer: "eng",
			},
		}

		reporter := &MockReporter{}

		// Create a verifier to be used with qtoken rotation logic
		verifier := &jwt.Verifier{
			Keyfunc: jwt.KeyfuncFromQTokenKeys(
				qtoken.MustKeysFromEnv(),
				reporter,
			),
		}

		r, _ := http.NewRequest("POST", "/some/url", body)
		if err := signer.Sign(r, claims); err != nil {
			fmt.Printf("unexpected signing error: %v\n", err)
		}

		claims, err := verifier.Verify(r)
		if err != nil {
			fmt.Printf("unexpected verifying error: %v\n", err)
		}

		if (claims.Validate() == nil) != c.expectValid {
			t.Errorf("claim validity was %q; want %v", claims.Validate(), c.expectValid)
		}

		actualMetric := reporter.String()
		if actualMetric != c.expectedMetric {
			t.Errorf("expected correct metrics logged; got %q; want %q", actualMetric, c.expectedMetric)
		}
	}
}

type MockReporter struct {
	Name string
	Tags []metrics.Meta
	metrics.StatsDReporter
}

func (r *MockReporter) IncCounter(name string, tags ...metrics.Meta) {
	r.Name = name
	r.Tags = tags
}

func (r *MockReporter) String() string {

	tags := make([]string, len(r.Tags))
	for i, t := range r.Tags {
		tags[i] = t.Key + ":" + t.Value
	}
	return fmt.Sprintf("%s|%s", r.Name, strings.Join(tags, ","))

}
