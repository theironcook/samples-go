// Package jwt provides functionality to sign HTTP requests with a JWT. It implements
// Qualtrics-specific extensions like including URL and body hashes and user-related
// authentication data as claims.
package jwt

import (
	"bytes"
	"crypto/sha256"
	"encoding/base64"
	"io"
	"net/http"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

const defaultTimeout = 30 * time.Second

const (
	authorizationHeader = "Authorization"
	authorizationScheme = "Bearer "

	// XJWTHeader is a deprecated legacy header used for sending a JWT and verifying that
	// the sender is from a Qualtrics server that has the proper secret for signing requests.
	// The authorization header is now the preferred header for this same purpose but some
	// clients may still expect the X-JWT header.
	XJWTHeader = "X-JWT"
)

// Signer encapsulates JWT configuration parameters and can be used repeatedly to sign HTTP requests.
type Signer struct {
	// Key is an HS256 key with which web tokens are signed
	Key []byte

	// Timeout specifies a duration into the future for which a JWT is
	// considered valid. It's added to time.Now() and set as the 'exp' claim.
	Timeout time.Duration

	// DefaultClaims allows for universal claim values to be defined once for every signed
	// request. For example, the Issuer claim should probably be provided here.
	DefaultClaims Claims

	// DefaultHeaders allows for universal JWT header values to be defined once for every
	// signed request.
	DefaultHeaders Headers

	// IncludeBodyHash indicates whether the body should be hashed and included in the JWT.
	IncludeBodyHash bool
}

// Sign generates a signed JWT for an HTTP request and attaches it to said request as an X-JWT header.
// Sign may be called concurrently from multiple goroutines.
//
// Claims in both Signer's DefaultClaims and in the provided Claims object are added to the JWT and
// signed. If a claim is set in both places, the value provided as an argument to Sign is used.
func (s *Signer) Sign(req *http.Request, c Claims) error {

	// base64Encode is an internal convenience method that bridges the gap
	// between the array that a hash function returns and the slice that
	// base64 wants.
	base64Encode := func(data [32]byte) string {
		return base64.RawURLEncoding.EncodeToString(data[:])
	}

	// merge claims together
	claims := s.DefaultClaims.combine(c)

	// ensure a valid set of claims
	if claims.Issuer == "" || claims.Audience == "" {
		return ErrIncompleteClaims
	}

	// calculate the proper timeout
	exp := time.Now().UTC().Add(defaultTimeout)
	if s.Timeout > 0 {
		exp = time.Now().UTC().Add(s.Timeout)
	}

	// generate a JWT
	urlHash := sha256.Sum256([]byte(req.URL.RequestURI()))
	tokenClaims := jwt.MapClaims{
		"exp":     exp.Unix(),
		"method":  req.Method,
		"urlHash": base64.RawURLEncoding.EncodeToString(urlHash[:]),

		// add the required claims
		"iss": claims.Issuer,
		"aud": claims.Audience,
	}

	if s.IncludeBodyHash {
		body, err := copyBody(req)
		if err != nil {
			return err
		}

		// if the body is at least one byte, hash it and set the bodyHash
		if len(body) > 0 {
			tokenClaims["bodyHash"] = base64Encode(sha256.Sum256(body))
		} else {
			// ensures "bodyHash" field appears in JWT (with null value)
			tokenClaims["bodyHash"] = nil
		}
	}

	// these claims are recommended but optional
	if claims.UserID != "" {
		tokenClaims["userId"] = claims.UserID
	}
	if claims.BrandID != "" {
		tokenClaims["brandId"] = claims.BrandID
	}

	// add custom claims
	for k, v := range claims.Custom {
		tokenClaims[k] = v
	}

	// if we can manage to generate a JWT, set it as a header
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, tokenClaims)

	// Set optional headers
	if s.DefaultHeaders.KeyID != "" {
		token.Header["kid"] = s.DefaultHeaders.KeyID
	}

	tokenString, err := token.SignedString(s.Key)
	if err != nil {
		return err
	}

	// TODO: When there are no consumers of v1.2.0, set the Authorization header:
	// req.Header.Set(authorizationHeader, authorizationScheme+tokenString)
	req.Header.Set(XJWTHeader, tokenString)

	return nil
}

// copyBody consumes and returns the body of an http.Request, and resets said body so it can be re-read again.
func copyBody(r *http.Request) ([]byte, error) {
	if r.Body == nil {
		return nil, nil
	}

	body, err := io.ReadAll(r.Body)
	if err != nil {
		return []byte{}, err
	}

	// "reset" the body reader by replacing it with a new ReadCloser
	r.Body = io.NopCloser(bytes.NewBuffer(body))

	return body, nil
}
