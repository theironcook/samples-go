package jwt

import (
	"errors"
	"net/http"
	"strings"

	"github.com/golang-jwt/jwt/v5"
)

var (
	// ErrNoJWTOnHeader indicates that no header was found on HTTP request
	ErrNoJWTOnHeader = errors.New("no JWT on http header")

	// ErrInvalidJWT indicates that the JWT failed to parse
	ErrInvalidJWT = errors.New("invalid JWT")
)

type (
	// Keyfunc is an alternative method for suppling a key for verification.
	// The function receives the parsed, but unverified token in string format
	// and expects the key or an error to be returned. This allows you to use
	// logic to determine which key should be used (ex: like logic found in the
	// golang/qtoken package).
	Keyfunc func(tokenString string) (interface{}, error)

	// Verifier encapsulates JWT configuration parameters and can be used repeatedly
	// to verify JWTs attached to HTTP requests. Keyfunc is mutually exclusive with Key.
	// If both values are non-nil, Keyfunc will be used and Key will be ignored.
	Verifier struct {
		// Key is an HS256 key with which web tokens are signed.
		Key []byte

		// Keyfunc to get the HS256 key for verification.
		Keyfunc Keyfunc
	}
)

// Verify looks for the X-JWT header on the passed request and parses out the JWT into a claims object and
// verifies those claims. Verify is safe to call from multiple goroutines.
//
// Verify will produce a Claims object that represents the claims found on the JWT. If extra claims are
// found beyond basic Qualtrics-specific extensions, they will be avaliable in the Claims object's Custom
// map.
func (v *Verifier) Verify(req *http.Request) (Claims, error) {
	tokenString := GetAuthorizationTokenStr(req)

	if len(tokenString) == 0 {
		return Claims{}, ErrNoJWTOnHeader
	}
	claimsTemplate := verificationClaims{}
	claimsTemplate.Req = req

	token, err := jwt.ParseWithClaims(tokenString, &claimsTemplate, func(t *jwt.Token) (interface{}, error) {
		if v.Keyfunc != nil {
			return v.Keyfunc(tokenString)
		}
		return v.Key, nil
	})
	// translate expired token errors to our own error type
	if errors.Is(err, jwt.ErrTokenExpired) {
		return Claims{}, ErrExpiredJWT
	}
	if err != nil {
		return Claims{}, err
	}

	if !token.Valid {
		return Claims{}, ErrInvalidJWT
	}

	delete(claimsTemplate.Custom, "exp")
	delete(claimsTemplate.Custom, "method")
	delete(claimsTemplate.Custom, "urlHash")

	return claimsTemplate.Claims, nil
}

// GetAuthorizationTokenStr gets the JWT token string from the request.
//
// The JWT token is extracted from one of three locations:
//
// 1. Authorization: "Bearer <token>"
// 2. Authorization: "<token>"
// 3. X-JWT: "<token>"
//
// If no header for authorization is found, GetAuthorizationTokenStr returns "".
func GetAuthorizationTokenStr(req *http.Request) string {
	tokenString := strings.TrimPrefix(req.Header.Get(authorizationHeader), authorizationScheme)
	if tokenString == "" {
		tokenString = req.Header.Get(XJWTHeader)
	}
	return tokenString
}
