package jwt

import (
	"bytes"
	"crypto/sha256"
	"encoding/base64"
	"net/http"
	"reflect"
	"strings"
	"testing"

	"github.com/golang-jwt/jwt/v5"
)

func TestSign(t *testing.T) {
	bodyContents := []byte("Some random string of data")
	body := bytes.NewReader(bodyContents)

	r, _ := http.NewRequest("POST", "/some/url", body)

	signer := &Signer{
		Key: []byte("secret_key"),
	}

	claims := Claims{
		Issuer:   "eng",
		Audience: "qualtrics",
		UserID:   "qcorp",
		BrandID:  "qualtrics",
		Custom: map[string]interface{}{
			"userType": "UT_BRANDADMIN",
			"product":  "ControlPanel",
		},
	}

	if err := signer.Sign(r, claims); err != nil {
		t.Fatalf("unexpected signing error: %s", err)
	}

	expectedURLHash := jwtBase64Encode(sha256.Sum256([]byte(r.URL.RequestURI())))

	token, err := jwt.Parse(r.Header.Get(XJWTHeader), jwtSigningFunc)
	if err != nil {
		t.Fatalf("failed parsing the header: %s, JWT: %s, from: %s", XJWTHeader, err, r.Header.Get(XJWTHeader))
	}

	tokenClaims := token.Claims.(jwt.MapClaims)

	cases := []struct {
		Key      string
		Expected string
	}{
		{Key: "urlHash", Expected: expectedURLHash},
		{Key: "userId", Expected: claims.UserID},
		{Key: "brandId", Expected: claims.BrandID},
		{Key: "iss", Expected: claims.Issuer},
		{Key: "aud", Expected: claims.Audience},
		{Key: "userType", Expected: claims.Custom["userType"].(string)},
		{Key: "product", Expected: claims.Custom["product"].(string)},
	}

	for i, c := range cases {
		if v, ok := tokenClaims[c.Key]; !ok {
			t.Errorf("[case %d] expected claim '%s' but found none", i, c.Key)
		} else if v != c.Expected {
			t.Errorf("[case %d] expected claim '%s'='%s' but '%s'='%s'", i, c.Key, c.Expected, c.Key, v)
		}
	}
}

func TestSignWithDefaultJWTHeaders(t *testing.T) {
	bodyContents := []byte("Some random string of data")
	body := bytes.NewReader(bodyContents)

	r, _ := http.NewRequest("POST", "/some/url", body)

	signer := &Signer{
		Key:            []byte("secret_key"),
		DefaultHeaders: Headers{KeyID: "my_key"},
	}

	claims := Claims{
		Issuer:   "eng",
		Audience: "qualtrics",
		UserID:   "qcorp",
		BrandID:  "qualtrics",
		Custom: map[string]interface{}{
			"userType": "UT_BRANDADMIN",
			"product":  "ControlPanel",
		},
	}

	if err := signer.Sign(r, claims); err != nil {
		t.Fatalf("unexpected signing error: %s", err)
	}

	token, err := jwt.Parse(r.Header.Get(XJWTHeader), jwtSigningFunc)
	if err != nil {
		t.Fatalf("failed parsing the header: %s, JWT: %s, from: %s", XJWTHeader, err, r.Header.Get(XJWTHeader))
	}

	cases := []struct {
		Key      string
		Expected string
	}{
		{Key: "kid", Expected: "my_key"},
	}
	for i, c := range cases {
		if v, ok := token.Header[c.Key]; !ok {
			t.Errorf("[case %d] expected header '%s' but found none", i, c.Key)
		} else if v != c.Expected {
			t.Errorf("[case %d] expected header '%s'='%s' but '%s'='%s'", i, c.Key, c.Expected, c.Key, v)
		}
	}
}

func TestSignWithXJWTHeader(t *testing.T) {

	// TODO: When Authorization header is set, re-enable this test
	t.Skip()

	bodyContents := []byte("Some random string of data")
	body := bytes.NewReader(bodyContents)

	r, _ := http.NewRequest("POST", "/some/url", body)

	signer := &Signer{
		Key: []byte("secret_key"),
	}

	claims := Claims{
		Issuer:   "eng",
		Audience: "qualtrics",
		UserID:   "qcorp",
		BrandID:  "qualtrics",
		Custom: map[string]interface{}{
			"userType": "UT_BRANDADMIN",
			"product":  "ControlPanel",
		},
	}

	if err := signer.Sign(r, claims); err != nil {
		t.Errorf("unexpected signing error: %s", err)
	}

	XJWTHeader := r.Header.Get(XJWTHeader)
	authorizationHeader := r.Header.Get(authorizationHeader)
	if XJWTHeader != strings.TrimPrefix(authorizationHeader, authorizationScheme) {
		t.Errorf("Expected X-JWT and authorization headers in the signed request to have the same jwt value")
	}
}

func TestSignWithInvalidKey(t *testing.T) {
	signer := &Signer{
		Key: []byte("seekrit_key"),
	}

	claims := Claims{
		Issuer:   "eng",
		Audience: "qualtrics",
		UserID:   "qcorp",
		BrandID:  "qualtrics",
	}

	r, _ := http.NewRequest("POST", "/some/url", nil)

	if err := signer.Sign(r, claims); err != nil {
		t.Errorf("unexpected signing error: %s", err)
	}

	if _, err := jwt.Parse(r.Header.Get(authorizationHeader), jwtSigningFunc); err == nil {
		t.Errorf("expected validation error but got none")
	}
}

func TestSignWithClaimOverrides(t *testing.T) {
	signer := &Signer{
		Key: []byte("secret_key"),
		DefaultClaims: Claims{
			Issuer:   "eng",
			Audience: "qualtrics",
			Custom: map[string]interface{}{
				"race":   "human",
				"planet": "Earth",
			},
		},
	}

	claims := Claims{
		Audience: "statwing",
		Custom: map[string]interface{}{
			"planet": "Mars",
		},
	}

	r, _ := http.NewRequest("POST", "/some/url", nil)

	if err := signer.Sign(r, claims); err != nil {
		t.Fatalf("unexpected signing error: %s", err)
	}

	token, err := jwt.Parse(r.Header.Get(XJWTHeader), jwtSigningFunc)
	if err != nil {
		t.Fatalf("failed parsing the header: %s, JWT: %s, from: %s", XJWTHeader, err, r.Header.Get(XJWTHeader))
	}

	tokenClaims := token.Claims.(jwt.MapClaims)

	// verify expected overrides happened
	expected := map[string]interface{}{
		"iss":    "eng",
		"aud":    "statwing",
		"race":   "human",
		"planet": "Mars",
	}
	for claim, expectedValue := range expected {
		if actual := tokenClaims[claim]; !reflect.DeepEqual(actual, expectedValue) {
			t.Logf("unexpected claim: expected '%s'='%#v' but got '%s'='%#v'\n", claim, expectedValue, claim, actual)
		}
	}
}

func jwtSigningFunc(t *jwt.Token) (interface{}, error) {
	return []byte("secret_key"), nil
}

func jwtBase64Encode(data [32]byte) string {
	b64 := base64.URLEncoding.EncodeToString(data[:]) // Encode using Base64URL
	return strings.Replace(b64, "=", "", -1)          // strip "=" per JWT spec
}
