package jwt

// Headers allows callers to provide optional JWT headers described in the
// 'Qualtrics Internal API Authentication' https://docs.google.com/document/d/1nBwOQf8GT26x5IhaUXcg6I2zuMKA_pSz1V8RqGN-syA/edit#heading=h.ac4h48x4ag3w
type Headers struct {
	KeyID string // See https://www.rfc-editor.org/rfc/rfc7515#section-4.1.4
}
