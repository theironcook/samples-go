package jwt

import (
	"bytes"
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"net/http"
	"reflect"
	"testing"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

var expectedClaims = Claims{
	Issuer:   "eng",
	Audience: "qualtrics",
	UserID:   "qcorp",
	BrandID:  "qualtrics",
	Custom: map[string]interface{}{
		"userType": "UT_BRANDADMIN",
		"product":  "ControlPanel",
	},
}

var (
	Key = []byte("secret_key")

	verifier = Verifier{
		Key: Key,
	}
)

func TestVerify(t *testing.T) {
	bodyContents := []byte("Some random string of data")
	body := bytes.NewReader(bodyContents)
	url := "/some/url"
	urlHash := sha256.Sum256([]byte(url))

	jwt := createValidJWTFromPieces(
		time.Now().Add(defaultTimeout).Unix(),
		http.MethodPost,
		base64.RawURLEncoding.EncodeToString(urlHash[:]),
		"eng",
		"qualtrics",
		"qcorp",
		"qualtrics",
		map[string]interface{}{
			"userType": "UT_BRANDADMIN",
			"product":  "ControlPanel",
		},
	)

	r, _ := http.NewRequest(http.MethodPost, url, body)
	r.Header.Add(authorizationHeader, authorizationScheme+jwt)

	parsedClaims, err := verifier.Verify(r)
	if err != nil {
		t.Errorf("unexpected error parsing: %s", err)
	}

	if !reflect.DeepEqual(expectedClaims, parsedClaims) {
		t.Errorf("Parsed claims: %+v did not match expected Claims %+v", parsedClaims, expectedClaims)
	}
}

func TestVerifyWhenMissingAuthorizationScheme(t *testing.T) {
	bodyContents := []byte("Some random string of data")
	body := bytes.NewReader(bodyContents)
	url := "/some/url"
	urlHash := sha256.Sum256([]byte(url))

	jwt := createValidJWTFromPieces(
		time.Now().Add(defaultTimeout).Unix(),
		http.MethodPost,
		base64.RawURLEncoding.EncodeToString(urlHash[:]),
		"eng",
		"qualtrics",
		"qcorp",
		"qualtrics",
		map[string]interface{}{
			"userType": "UT_BRANDADMIN",
			"product":  "ControlPanel",
		},
	)

	r, _ := http.NewRequest(http.MethodPost, url, body)
	r.Header.Add(authorizationHeader, jwt) // Purposefully not prefixing with the Authorization Scheme (e.g. "Bearer ")

	parsedClaims, err := verifier.Verify(r)
	if err != nil {
		t.Errorf("unexpected error parsing: %s", err)
	}

	if !reflect.DeepEqual(expectedClaims, parsedClaims) {
		t.Errorf("Parsed claims: %+v did not match expected Claims %+v", parsedClaims, expectedClaims)
	}
}

// Should fail on account of wrong key
func TestWrongKey(t *testing.T) {
	bodyContents := []byte("Some random string of data")
	body := bytes.NewReader(bodyContents)
	url := "/some/url"
	urlHash := sha256.Sum256([]byte(url))

	jwt := createValidJWTFromPieces(
		time.Now().Add(defaultTimeout).Unix(),
		http.MethodPost,
		base64.RawURLEncoding.EncodeToString(urlHash[:]),
		"eng",
		"qualtrics",
		"qcorp",
		"qualtrics",
		map[string]interface{}{
			"userType": "UT_BRANDADMIN",
			"product":  "ControlPanel",
		},
	)

	r, _ := http.NewRequest(http.MethodPost, url, body)
	r.Header.Add(authorizationHeader, authorizationScheme+jwt)

	verifier := Verifier{
		Key: []byte("other_key"),
	}

	_, err := verifier.Verify(r)
	if err == nil {
		t.Error("unexpected positive verification")
	}
}

// Should fail on account of wrong time
func TestWrongTime(t *testing.T) {
	bodyContents := []byte("Some random string of data")
	body := bytes.NewReader(bodyContents)
	url := "/some/url"
	urlHash := sha256.Sum256([]byte(url))

	jwt := createValidJWTFromPieces(
		time.Now().Add(-defaultTimeout).Unix(), // time expired defaultTimeout seconds ago
		http.MethodPost,
		base64.RawURLEncoding.EncodeToString(urlHash[:]),
		"eng",
		"qualtrics",
		"qcorp",
		"qualtrics",
		map[string]interface{}{
			"userType": "UT_BRANDADMIN",
			"product":  "ControlPanel",
		},
	)

	r, _ := http.NewRequest(http.MethodPost, url, body)
	r.Header.Add(authorizationHeader, authorizationScheme+jwt)

	_, err := verifier.Verify(r)
	if !errors.Is(err, ErrExpiredJWT) {
		t.Errorf("expected error to be ErrExpiredJWT, but was %s", err)
	}
}

// Should fail on account of wrong method
func TestWrongMethod(t *testing.T) {
	bodyContents := []byte("Some random string of data")
	body := bytes.NewReader(bodyContents)
	url := "/some/url"
	urlHash := sha256.Sum256([]byte(url))

	jwt := createValidJWTFromPieces(
		time.Now().Add(defaultTimeout).Unix(),
		http.MethodGet, // get instead of post
		base64.RawURLEncoding.EncodeToString(urlHash[:]),
		"eng",
		"qualtrics",
		"qcorp",
		"qualtrics",
		map[string]interface{}{
			"userType": "UT_BRANDADMIN",
			"product":  "ControlPanel",
		},
	)

	r, _ := http.NewRequest(http.MethodPost, url, body)
	r.Header.Add(authorizationHeader, authorizationScheme+jwt)

	_, err := verifier.Verify(r)
	if !errors.Is(err, ErrUnexpectedMethod) {
		t.Error("unexpected positive verification", err)
	}
}

// Should fail on account of wrong urlHash
func TestWrongUrlHash(t *testing.T) {
	bodyContents := []byte("Some random string of data")
	body := bytes.NewReader(bodyContents)
	url := "/some/url"
	urlHash := sha256.Sum256([]byte(url))

	jwt := createValidJWTFromPieces(
		time.Now().Add(defaultTimeout).Unix(),
		http.MethodPost,
		base64.RawURLEncoding.EncodeToString(urlHash[:]),
		"eng",
		"qualtrics",
		"qcorp",
		"qualtrics",
		map[string]interface{}{
			"userType": "UT_BRANDADMIN",
			"product":  "ControlPanel",
		},
	)

	r, _ := http.NewRequest(http.MethodPost, url+"/malicous/endpoint", body) // bad url
	r.Header.Add(authorizationHeader, authorizationScheme+jwt)

	_, err := verifier.Verify(r)
	if !errors.Is(err, ErrUnexpectedURI) {
		t.Error("unexpected positive verification", err)
	}
}

// Should fail on account of wrong bodyHash
func TestWrongBodyHash(t *testing.T) {
	t.Skip("Skipping due to no implementation") // TODO: Remove when bodyHash verification is written

	bodyContents := []byte("Some random string of data")
	malicousBodyContents := []byte("You've been hacked")
	malicousBody := bytes.NewReader(malicousBodyContents)
	url := "/some/url"
	urlHash := sha256.Sum256([]byte(url))

	_ = bodyContents

	jwt := createValidJWTFromPieces(
		time.Now().Add(defaultTimeout).Unix(),
		http.MethodPost,
		base64.RawURLEncoding.EncodeToString(urlHash[:]),
		"eng",
		"qualtrics",
		"qcorp",
		"qualtrics",
		map[string]interface{}{
			"userType": "UT_BRANDADMIN",
			"product":  "ControlPanel",
		},
	)

	r, _ := http.NewRequest(http.MethodPost, url, malicousBody) // bad body :P
	r.Header.Add(authorizationHeader, authorizationScheme+jwt)

	_, err := verifier.Verify(r)
	if err != nil {
		t.Error("unexpected positive verification")
	}
}

// Should fail on account of blank issuer
func TestMissingIssuer(t *testing.T) {
	bodyContents := []byte("Some random string of data")
	body := bytes.NewReader(bodyContents)
	url := "/some/url"
	urlHash := sha256.Sum256([]byte(url))

	jwt := createValidJWTFromPieces(
		time.Now().Add(defaultTimeout).Unix(),
		http.MethodPost,
		base64.RawURLEncoding.EncodeToString(urlHash[:]),
		"", // blank issuer
		"qualtrics",
		"qcorp",
		"qualtrics",
		map[string]interface{}{
			"userType": "UT_BRANDADMIN",
			"product":  "ControlPanel",
		},
	)

	r, _ := http.NewRequest(http.MethodPost, url, body)
	r.Header.Add(authorizationHeader, authorizationScheme+jwt)

	_, err := verifier.Verify(r)
	if !errors.Is(err, ErrIncompleteClaims) {
		t.Error("unexpected positive verification")
	}
}

// Should fail on account of blank audience
func TestMissingAudience(t *testing.T) {
	bodyContents := []byte("Some random string of data")
	body := bytes.NewReader(bodyContents)
	url := "/some/url"
	urlHash := sha256.Sum256([]byte(url))

	jwt := createValidJWTFromPieces(
		time.Now().Add(defaultTimeout).Unix(),
		http.MethodPost,
		base64.RawURLEncoding.EncodeToString(urlHash[:]),
		"eng",
		"", // blank audience
		"qcorp",
		"qualtrics",
		map[string]interface{}{
			"userType": "UT_BRANDADMIN",
			"product":  "ControlPanel",
		},
	)

	r, _ := http.NewRequest(http.MethodPost, url, body)
	r.Header.Add(authorizationHeader, authorizationScheme+jwt)

	_, err := verifier.Verify(r)
	if !errors.Is(err, ErrIncompleteClaims) {
		t.Error("unexpected positive verification", err)
	}
}

// Should fail on account of missing optional payload
// but NOT because of parsing error
func TestMissingExpectedOptionalPayload(t *testing.T) {
	bodyContents := []byte("Some random string of data")
	body := bytes.NewReader(bodyContents)
	url := "/some/url"
	urlHash := sha256.Sum256([]byte(url))

	jwt := createValidJWTFromPieces(
		time.Now().Add(defaultTimeout).Unix(),
		http.MethodPost,
		base64.RawURLEncoding.EncodeToString(urlHash[:]),
		"eng",
		"qualtrics",
		"",                       // blank userID
		"",                       // blank brandID
		map[string]interface{}{}, // blank custom
	)

	r, _ := http.NewRequest(http.MethodPost, url, body)
	r.Header.Add(authorizationHeader, authorizationScheme+jwt)

	parsedClaims, err := verifier.Verify(r)
	if err != nil {
		t.Errorf("unexpected error parsing: %s", err)
	}

	if reflect.DeepEqual(expectedClaims, parsedClaims) {
		t.Error("unexpected positive verification of parsedClaims")
	}
}

func TestVerifyWithLegacyJwtHeader(t *testing.T) {
	bodyContents := []byte("Some random string of data")
	body := bytes.NewReader(bodyContents)
	url := "/some/url"
	urlHash := sha256.Sum256([]byte(url))

	jwt := createValidJWTFromPieces(
		time.Now().Add(defaultTimeout).Unix(),
		http.MethodPost,
		base64.RawURLEncoding.EncodeToString(urlHash[:]),
		"eng",
		"qualtrics",
		"qcorp",
		"qualtrics",
		map[string]interface{}{
			"userType": "UT_BRANDADMIN",
			"product":  "ControlPanel",
		},
	)

	r, _ := http.NewRequest(http.MethodPost, url, body)
	r.Header.Add(XJWTHeader, jwt)

	parsedClaims, err := verifier.Verify(r)
	if err != nil {
		t.Errorf("unexpected error parsing: %s", err)
	}

	if !reflect.DeepEqual(expectedClaims, parsedClaims) {
		t.Errorf("Parsed claims: %+v did not match expected Claims %+v", parsedClaims, expectedClaims)
	}
}

func TestVerifyWithBadExpiration(t *testing.T) {
	bodyContents := []byte("Some random string of data")
	body := bytes.NewReader(bodyContents)
	url := "/some/url"
	urlHash := sha256.Sum256([]byte(url))

	jwt := createValidJWTFromPieces(
		time.Now().Add(defaultTimeout).Unix(),
		http.MethodPost,
		base64.RawURLEncoding.EncodeToString(urlHash[:]),
		"eng",
		"qualtrics",
		"qcorp",
		"qualtrics",
		map[string]interface{}{
			"userType": "UT_BRANDADMIN",
			"product":  "ControlPanel",
			"exp":      "123",
		},
	)

	r, _ := http.NewRequest(http.MethodPost, url, body)
	r.Header.Add(authorizationHeader, authorizationScheme+jwt)

	_, err := verifier.Verify(r)
	if !errors.Is(err, ErrExpiredJWT) {
		t.Errorf("unexpected error parsing: %s", err)
	}
}

// makes it easy to create test jwts independently of signer.go
func createValidJWTFromPieces(expiration interface{},
	method interface{},
	urlHash interface{},
	iss interface{},
	aud interface{},
	userID interface{},
	brandID interface{},
	custom map[string]interface{}) string {

	tokenClaims := jwt.MapClaims{
		"exp":     expiration,
		"urlHash": urlHash,
		"iss":     iss,
		"aud":     aud,
		"brandId": brandID,
		"userId":  userID,
		"method":  method,
	}

	for k, v := range custom {
		tokenClaims[k] = v
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, tokenClaims)
	tokenString, err := token.SignedString(Key)
	if err == nil {
		return tokenString
	}

	panic("failed to create JWT properly: " + err.Error())
}
