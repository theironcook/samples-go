author: wesb@qualtrics.com

# Configuring JWT verification with qtoken secrets using `golang/jwt` and `golang/qtoken`

This guide will walk you through how to verify JWT requests with the qtoken secrets according to [the qtoken rotation specifiation](https://docs.google.com/document/d/1weipSHRwuoyN43tWZRjcDK62Je8osQgiHYxPQmSwP9Y/edit#).

Below are links to full documentation.

<a href="http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/qtoken"><img src="http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/qtoken?status.svg" alt="qtoken GoDoc"></a>

<a href="http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/jwt"><img src="http://godoc-app.eng.qops.net/gitlab-app.eng.qops.net/golang/jwt?status.svg" alt="jwt GoDoc"></a>

## Configuring Hiera

Configure Vault to inject the correct qtoken secrets.

```yaml
docker::apps:
  app:
      ...
      vault_secrets: >
        secret/shared/qtoken/%{::environment}
```

## Configuring Nomad with Howdah

```yaml
service:
  vault:
    policies:
      - "qtoken-%{environment}"
    secrets:
      QTOKEN: secret/shared/qtoken/%{environment}/QTOKEN
      QTOKEN_ROTATED: secret/shared/qtoken/%{environment}/QTOKEN_ROTATED
      QTOKEN_CHECKSUM: secret/shared/qtoken/%{environment}/QTOKEN_CHECKSUM
```

!!! warning "BEFORE RELEASING"
	Before releasing any changes it is important to verify that the `QTOKEN`, `QTOKEN_ROTATED`, and `QTOKEN_CHECKSUM` environment variables are available for your service. This likely means doing a service restart/release (and possibly a puppet run for Hiera-configured hosts).

## Sign

Signing your requests using `QTOKEN` is no different than signing any other JWT request. See the documentation for `golang/jwt` for full details.

You can use the `qtoken.MustKeysFromEnv()` func to help pull the correct values from environment variables.

```go
verifier := &jwt.Signer{
	Key: qtoken.MustKeysFromEnv().Primary
}
```

## Verify

Rather than creating a `jwt.Verifier` that has a hardcoded single key, you will define a `Keyfunc` function that will return the correct key. The `golang/jwt` and `golang/qtoken` packages provide helper functions for correctly setting up a `jwt.Verifier` that will work with qtoken rotation logic. The `qtoken.MustKeysFromEnv` will read the `QTOKEN`, `QTOKEN_ROTATED`, `QTOKEN_CHECKSUM` environment variables and the `jwt.KeyfuncFromQTokenKeys` will configure the correct Keyfunc.

```go
// QTOKEN, QTOKEN_ROTATED, QTOKEN_CHECKSUM are expected to be set in the environment

// Create a verifier to be used with qtoken rotation logic
verifier := &jwt.Verifier{
	Keyfunc: jwt.KeyfuncFromQTokenKeys(
		qtoken.MustKeysFromEnv(),
		metrics.DefaultReporter,
	),
}

claims, err := verifier.Verify(r)
if err != nil {
	fmt.Printf("unexpected verifying error for qtoken JWT: %v\n", err)
}
```

!!! warning "STAGED ROLLOUT"
	It is important to verify that that your application is configured correctly before rolling out to all datacenters. Please start with alpha, beta, and gamma before doing production. Please test in one produciton datacetner before releasing to others.


## Experimental code modification automation

There is an optional cli tool to help migrate your applications. The tool will traverse your code and attempt to updates usages of the `jwt.Verifier` type. Install the tool via homebrew by running the following commands.


```sh
brew tap --force-auto-update golang/homebrew https://gitlab-app.eng.qops.net/golang/homebrew
brew install jwtqtokenupgrade
```

To audit your code run

```sh
jwtqtokenupgrade <go file matcher>
example
jwtqtokenupgrade ./...
or
jwtqtokenupgrade ./cmd
```

This will output any found files. To modify the files run the same command with `--fix`

```sh
jwtqtokenupgrade --fix ./...
```

!!! info
	The `jwtqtokenupgrade` cli tool will not distinguish between `jwt.Verifier` instances using qtoken and instances using your own secrets. Only run `jwtqtokenupgrade` on files that use `jwt.Verifier` instances using qtoken.	Also, be sure to review all changes and test compiling your code before committing and releasing.
