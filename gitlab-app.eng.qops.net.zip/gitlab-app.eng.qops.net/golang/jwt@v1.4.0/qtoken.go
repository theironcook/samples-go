package jwt

import (
	"errors"
	"fmt"

	"github.com/golang-jwt/jwt/v5"
	"gitlab-app.eng.qops.net/golang/metrics/v2"
	"gitlab-app.eng.qops.net/golang/qtoken"
)

const (
	MetricName       = "jwt_pre_verify"
	MetricTagIssuer  = "iss"
	MetricTagKeyName = "key_name"
)

// KeyfuncFromQTokenKeys returns a Keyfunc which determines the most
// appropriate key within keys to use.
func KeyfuncFromQTokenKeys(keys qtoken.Keys, reporter metrics.Reporter) Keyfunc {

	return func(tokenString string) (interface{}, error) {

		var key []byte
		claims := jwt.MapClaims{}

		key = keys.Primary
		_, err := jwt.ParseWithClaims(tokenString, &claims, func(t *jwt.Token) (interface{}, error) {
			return key, nil
		})

		if errors.Is(err, jwt.ErrSignatureInvalid) {
			key = keys.Rotated
			_, err = jwt.ParseWithClaims(tokenString, &claims, func(t *jwt.Token) (interface{}, error) {
				return key, nil
			})
		}

		if err != nil {
			// Both candidate keys produced errors, so the provided token was signed with an invalid key.
			// Set the key to nil, and wrap the error, but don't return until we increment the counter.
			key = nil
			err = fmt.Errorf("error determining which key to use: %w", err)
		}

		name, _ := keys.Name(key)
		issuer, _ := claims["iss"].(string)
		reporter.IncCounter(
			MetricName,
			metrics.Tag(MetricTagIssuer, issuer),
			metrics.Tag(MetricTagKeyName, name),
		)

		return key, err
	}
}
