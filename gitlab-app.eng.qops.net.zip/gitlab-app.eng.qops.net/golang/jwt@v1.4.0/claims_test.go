package jwt

import (
	"errors"
	"reflect"
	"testing"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

func TestClaims_GetIssuer(t *testing.T) {
	c := Claims{Issuer: "tylerc"}
	if v, _ := c.GetIssuer(); v != "tylerc" {
		t.Errorf("unexpected issuer: expected 'tylerc' but got '%s'", v)
	}
}

func TestClaims_GetAudience(t *testing.T) {
	c := Claims{Audience: "jaredr"}
	if v, _ := c.GetAudience(); v[0] != "jaredr" {
		t.Errorf("unexpected audience: expected 'jaredr' but got '%s'", v)
	}
}

func TestClaims_GetExpirationTime(t *testing.T) {
	testNumericDateClaim(t, "exp", (*Claims).GetExpirationTime)
}

func TestClaims_GetIssuedAt(t *testing.T) {
	testNumericDateClaim(t, "iat", (*Claims).GetIssuedAt)
}

func TestClaims_GetNotBefore(t *testing.T) {
	testNumericDateClaim(t, "nbf", (*Claims).GetNotBefore)
}

func testNumericDateClaim(t *testing.T, key string, f func(c *Claims) (*jwt.NumericDate, error)) {
	expected := time.Now().UTC().Round(time.Second)

	c := &Claims{Custom: map[string]interface{}{
		key: expected.Unix(),
	}}
	if numericDate, _ := f(c); numericDate.Time.UTC() != expected {
		t.Errorf("unexpected expiration time: expected %v but got %v", expected, numericDate)
	}

	// for backwards compatibility, errors parsing numeric dates are ignored
	invalidClaims := &Claims{Custom: map[string]interface{}{
		key: "not a number",
	}}
	if _, err := f(invalidClaims); err != nil {
		t.Errorf("unexpected error: expected nil but got '%s'", err)
	}
}

func TestClaims_GetSubject(t *testing.T) {
	c := Claims{
		Custom: map[string]interface{}{
			"sub": "tylerc",
		},
	}
	if v, _ := c.GetSubject(); v != "tylerc" {
		t.Errorf("unexpected audience: expected 'tylerc' but got '%s'", v)
	}
}

func TestValidateClaims(t *testing.T) {
	cases := []struct {
		Claims        Claims
		ExpectedError error
	}{
		{
			Claims:        Claims{Issuer: "tylerc", Audience: "jaredr"},
			ExpectedError: nil,
		},
		{
			Claims:        Claims{Issuer: "", Audience: "jaredr"},
			ExpectedError: ErrIncompleteClaims,
		},
		{
			Claims:        Claims{Issuer: "tylerc", Audience: ""},
			ExpectedError: ErrIncompleteClaims,
		},
	}

	for i, c := range cases {
		if err := c.Claims.Valid(); !errors.Is(err, c.ExpectedError) {
			t.Errorf("[case %d] unexpected error: expected '%s' but got '%s'\n", i, c.ExpectedError, err)
		}
	}
}

func TestCombineClaims(t *testing.T) {
	cases := []struct {
		ClaimsA, ClaimsB Claims
		Expected         Claims
	}{
		{
			ClaimsA:  Claims{},
			ClaimsB:  Claims{},
			Expected: Claims{},
		},
		{
			ClaimsA:  Claims{Issuer: "tylerc", Audience: "jaredr"},
			ClaimsB:  Claims{UserID: "tylerc", BrandID: "tylerc"},
			Expected: Claims{Issuer: "tylerc", Audience: "jaredr", UserID: "tylerc", BrandID: "tylerc"},
		},
		{
			ClaimsA:  Claims{Issuer: "tylerc", Audience: "responseengine"},
			ClaimsB:  Claims{Audience: "olympus"},
			Expected: Claims{Issuer: "tylerc", Audience: "olympus"},
		},
		{
			ClaimsA: Claims{Issuer: "tylerc", Custom: map[string]interface{}{
				"color":  "blue",
				"planet": "Mars",
			}},
			ClaimsB: Claims{Audience: "jaredr", Custom: map[string]interface{}{
				"color": "red",
			}},
			Expected: Claims{Issuer: "tylerc", Audience: "jaredr", Custom: map[string]interface{}{
				"planet": "Mars",
				"color":  "red",
			}},
		},
	}

	for i, c := range cases {
		if claims := c.ClaimsA.combine(c.ClaimsB); !reflect.DeepEqual(c.Expected, claims) {
			t.Errorf("[case %d] unexpected error: expected '%#v' but got '%#v'\n", i, c.Expected, claims)
		}
	}
}
